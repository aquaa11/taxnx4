import React from 'react';
import { Routes, Route } from 'react-router-dom';

// Feature routes
import Home from '@/pages/home/Home'
import Bases from '@/pages/base/Bases'
import Base from '@/pages/base/Base'
import BaseScan from '@/pages/base/BaseScan'
import BaseEdit from '@/pages/base/BaseEdit'
import SignIn from '@/pages/auth/SignIn'
import SignUp from '@/pages/auth/SignUp';

import { AuthProvider } from '@/context/AuthProvider';
import PrivateRoute from './PrivateRoute';

const AppRouter = () => {
    return (
        <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/sign-in" element={<SignIn />} />
            <Route path="/sign-up" element={<SignUp />} />
            <Route element={<PrivateRoute />}>
                <Route path="/base" element={<Bases />} />
                <Route path="/base/:id" element={<Base />} />
                <Route path="/base/:id/scan" element={<BaseScan />} />
                <Route path="/base/:id/edit" element={<BaseEdit />} />
            </Route>
        </Routes>
    );
};

export default AppRouter;