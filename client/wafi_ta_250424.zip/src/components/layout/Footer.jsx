import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faDiscord, faInstagram, faTwitter } from '@fortawesome/free-brands-svg-icons';
const Footer = () => {
    return (
        <footer id="footer" className="relative z-10 bg-black/20 border-t border-white/10">
            <div className="container mx-auto px-4 py-8">
                <div className="grid md:grid-cols-4 gap-8">
                    <div className="text-white">
                        <h4 className="font-bold mb-4">Tentang Kami</h4>
                        <p className="text-sm text-white/70">COC Tracker adalah alat tidak resmi untuk membantu pemain Clash of Clans melacak dan mengoptimalkan perkembangan permainan mereka.</p>
                    </div>
                    <div className="text-white">
                        <h4 className="font-bold mb-4">Tautan</h4>
                        <ul className="space-y-2 text-white/70">
                            <li><span className="hover:text-yellow-400 transition-colors cursor-pointer">Beranda</span></li>
                            <li><span className="hover:text-yellow-400 transition-colors cursor-pointer">Fitur</span></li>
                            <li><span className="hover:text-yellow-400 transition-colors cursor-pointer">FAQ</span></li>
                        </ul>
                    </div>
                    <div className="text-white">
                        <h4 className="font-bold mb-4">Legal</h4>
                        <ul className="space-y-2 text-white/70">
                            <li><span className="hover:text-yellow-400 transition-colors cursor-pointer">Kebijakan Privasi</span></li>
                            <li><span className="hover:text-yellow-400 transition-colors cursor-pointer">Syarat &amp; Ketentuan</span></li>
                        </ul>
                    </div>
                    <div className="text-white">
                        <h4 className="font-bold mb-4">Sosial Media</h4>
                        <div className="flex space-x-4 text-2xl">
                            <a href="#" className="text-white hover:text-yellow-400 transition-colors">
                                <FontAwesomeIcon icon={faTwitter} />
                            </a>
                            <a href="#" className="text-white hover:text-yellow-400 transition-colors">
                                <FontAwesomeIcon icon={faInstagram} />
                            </a>
                            <a href="#" className="text-white hover:text-yellow-400 transition-colors">
                                <FontAwesomeIcon icon={faDiscord} />
                            </a>
                        </div>
                    </div>
                </div>
                <div className="mt-8 pt-8 border-t border-white/10 text-center text-white/60">
                    <p>© 2025 COC Tracker. Bukan afiliasi resmi Supercell.</p>
                </div>
            </div>
        </footer>
    );
};

export default Footer;