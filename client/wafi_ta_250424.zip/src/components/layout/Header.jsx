import React, { useState, useEffect } from "react";
// Import useLocation
import { Link, useNavigate, useLocation } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
// Import new icons
import { faBars, faShieldHalved, faRightToBracket, faUserPlus, faHome, faSignOutAlt, faUser, faTimes, faListCheck, faBookOpen, faChessBoard } from "@fortawesome/free-solid-svg-icons";
import { useAuth } from '@/hooks/useAuth';

const Header = () => {
  const navigate = useNavigate();
  const location = useLocation(); // Get location object
  const currentPath = location.pathname; // Get current path
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false); // State for scroll detection

  // Safely access the auth context
  const auth = useAuth();
  const user = auth?.user;
  const isSignedIn = !!user;

  // Effect to handle scroll detection
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10); // Change state if scrolled more than 10px
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll); // Cleanup listener
  }, []);

  const handleSignOut = async () => {
    if (auth?.logout) {
      await auth.logout();
      navigate('/');
    }
  };

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  // Close mobile menu when a link is clicked
  const closeMobileMenu = () => {
    setMobileMenuOpen(false);
  };

  return (
    // Updated header classes for floating, transparency, blur, and scroll effect
    <header
      id="header"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ease-in-out ${
        isScrolled ? 'py-2 bg-blue-950/80 backdrop-blur-lg shadow-lg' : 'py-4 bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4 sm:px-8">
        <nav className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Link to="/" className="flex items-center gap-2">
              <FontAwesomeIcon
                icon={faShieldHalved}
                className="text-3xl text-yellow-400"
              />
              <span className="text-2xl font-bold text-white">COC Tracker</span>
            </Link>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-6 text-white">
            {/* Conditional rendering for Home link */}
            {currentPath !== '/' && (
              <Link
                to="/"
                className="hover:text-yellow-400 transition-colors cursor-pointer font-medium flex items-center gap-1.5" // Added flex and gap
              >
                <FontAwesomeIcon icon={faHome} /> {/* Added Home icon */}
                Home
              </Link>
            )}
            {/* Conditional rendering for Fitur and Panduan */}
            {currentPath === '/' && (
              <>
                <a
                  href="#features"
                  className="hover:text-yellow-400 transition-colors cursor-pointer flex items-center gap-1.5" // Added flex and gap
                >
                  <FontAwesomeIcon icon={faListCheck} /> {/* Added Fitur icon */}
                  Fitur
                </a>
                <a
                  href="#guides"
                  className="hover:text-yellow-400 transition-colors cursor-pointer flex items-center gap-1.5" // Added flex and gap
                >
                  <FontAwesomeIcon icon={faBookOpen} /> {/* Added Panduan icon */}
                  Panduan
                </a>
              </>
            )}

            {user && (
              <Link
                to="/base"
                className="hover:text-yellow-400 transition-colors cursor-pointer font-medium flex items-center gap-1.5" // Added flex and gap
              >
                <FontAwesomeIcon icon={faChessBoard} /> {/* Added My Base icon */}
                My Base
              </Link>
            )}

            {isSignedIn ? (
              <div className="flex items-center gap-3 ml-4">
                <div className="relative group">
                  {/* Updated User Button Styling to Yellow */}
                  <button className="flex items-center gap-2 px-4 py-2 rounded-full bg-yellow-400 hover:bg-yellow-500 transition-colors text-gray-900"> {/* Changed bg and text color */}
                    <FontAwesomeIcon icon={faUser} /> {/* Removed text-yellow-400 as background is yellow */}
                    <span className="font-medium">{user?.username || 'User'}</span>
                  </button>
                  {/* Updated User Dropdown Menu Styling for smooth transition */}
                  <div className="absolute right-0 top-full mt-1 w-48 origin-top-right rounded-md shadow-lg bg-blue-900/90 backdrop-blur-md border border-white/10 p-2 ring-1 ring-black ring-opacity-5 focus:outline-none transform opacity-0 scale-95 transition-all duration-200 ease-out group-hover:opacity-100 group-hover:scale-100 invisible group-hover:visible min-w-[160px] overflow-hidden">
                    <button
                      onClick={handleSignOut}
                      // Updated hover style for Sign Out button
                      className="w-full text-left flex items-center gap-3 px-4 py-2 text-white rounded-md hover:bg-yellow-500 hover:text-gray-900 transition-colors"
                    >
                      <FontAwesomeIcon icon={faSignOutAlt} className="w-4" /> {/* Keep icon color consistent or change on hover too */}
                      <span className="font-medium">Sign Out</span>
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-3 ml-4">
                {/* Updated Sign In Button Styling to Yellow */}
                <Link
                  to="/sign-in"
                  className="flex items-center gap-2 px-4 py-2 rounded-full text-gray-900 bg-yellow-400 hover:bg-yellow-500 transition-colors" // Changed bg and text color
                >
                  <FontAwesomeIcon icon={faRightToBracket} /> {/* Removed text-yellow-400 */}
                  <span className="font-medium">Masuk</span>
                </Link>
                <Link
                  to="/sign-up"
                  className="flex items-center gap-2 px-4 py-2 bg-yellow-400 text-gray-900 font-semibold rounded-full hover:bg-yellow-500 transition-colors"
                >
                  <FontAwesomeIcon icon={faUserPlus} />
                  <span>Daftar</span>
                </Link>
              </div>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-white text-2xl p-2" // Added padding for easier tapping
            onClick={toggleMobileMenu}
            aria-label="Toggle menu" // Added aria-label for accessibility
          >
            {/* Toggle between Bars and Times icon */}
            <FontAwesomeIcon icon={mobileMenuOpen ? faTimes : faBars} />
          </button>
        </nav>
      </div>

      {/* Mobile Menu - Updated Styling */}
      <div
        className={`md:hidden fixed inset-0 top-[${isScrolled ? '56px' : '72px'}] bg-blue-950/95 backdrop-blur-xl transition-transform duration-300 ease-in-out ${
          mobileMenuOpen ? 'translate-x-0' : 'translate-x-full' // Slide in/out effect
        } p-6`} // Adjusted padding and positioning
      >
        <div className="flex flex-col space-y-4 text-white text-lg">
          {/* Conditional rendering for Home link */}
          {currentPath !== '/' && (
            <Link to="/" onClick={closeMobileMenu} className="hover:text-yellow-400 transition-colors py-2 font-medium flex items-center gap-2">
              <FontAwesomeIcon icon={faHome} className="w-5" />
              Home
            </Link>
          )}
          {/* Conditional rendering for Fitur and Panduan */}
          {currentPath === '/' && (
            <>
              <a href="#features" onClick={closeMobileMenu} className="hover:text-yellow-400 transition-colors py-2 font-medium flex items-center gap-2"> {/* Added flex and gap */}
                <FontAwesomeIcon icon={faListCheck} className="w-5" /> {/* Added Fitur icon */}
                Fitur
              </a>
              <a href="#guides" onClick={closeMobileMenu} className="hover:text-yellow-400 transition-colors py-2 font-medium flex items-center gap-2"> {/* Added flex and gap */}
                <FontAwesomeIcon icon={faBookOpen} className="w-5" /> {/* Added Panduan icon */}
                Panduan
              </a>
            </>
          )}

          {user && (
            <Link to="/base" onClick={closeMobileMenu} className="hover:text-yellow-400 transition-colors py-2 font-medium flex items-center gap-2">
              <FontAwesomeIcon icon={faChessBoard} className="w-5" /> {/* Changed icon to faChessBoard */}
              My Base
            </Link>
          )}

          <div className="border-t border-white/20 my-3"></div>

          {isSignedIn ? (
            <div className="flex flex-col gap-3">
              <div className="flex items-center gap-3 py-2 text-xl"> {/* Increased text size */}
                <FontAwesomeIcon icon={faUser} className="text-yellow-400" />
                <span className="font-semibold">{user?.username || 'User'}</span>
              </div>
              <button
                onClick={() => { handleSignOut(); closeMobileMenu(); }} // Close menu on sign out
                className="flex items-center gap-3 py-2 text-white hover:text-yellow-400 transition-colors font-medium"
              >
                <FontAwesomeIcon icon={faSignOutAlt} className="text-yellow-400 w-5" />
                <span>Sign Out</span>
              </button>
            </div>
          ) : (
            <>
              {/* Updated Mobile Sign In Button Styling to Yellow */}
              <Link to="/sign-in" onClick={closeMobileMenu} className="flex items-center justify-center gap-3 py-2 bg-yellow-400 text-gray-900 font-semibold rounded-full hover:bg-yellow-500 transition-colors px-5"> {/* Changed bg, text, added justify-center */}
                <FontAwesomeIcon icon={faRightToBracket} /> {/* Removed text-yellow-400 */}
                <span>Masuk</span>
              </Link>
              <Link to="/sign-up" onClick={closeMobileMenu} className="flex items-center gap-3 py-2 bg-yellow-400 text-gray-900 font-semibold rounded-full hover:bg-yellow-500 transition-colors">
                <FontAwesomeIcon icon={faUserPlus} />
                <span>Daftar</span>
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;