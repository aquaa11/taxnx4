import React from 'react';
import Header from './Header';
import Footer from './Footer';

const Layout = ({ children }) => {
    return (
        <div className="min-h-screen bg-gradient-to-b from-blue-400 to-blue-600 relative overflow-hidden">
            <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
            <div className="absolute inset-0 overflow-hidden">
                <img
                    className="absolute bottom-0 w-full h-48 object-cover opacity-30"
                    src="https://storage.googleapis.com/uxpilot-auth.appspot.com/ec636b7f48-f1f07384ed4149965c9b.png"
                    alt="green grass texture, cartoon style, game art"
                />
                <img
                    className="absolute w-full h-full object-cover mix-blend-soft-light opacity-20"
                    src="https://storage.googleapis.com/uxpilot-auth.appspot.com/fa037bc8d8-c5b45e463c29d7977afc.png"
                    alt="cartoon clouds pattern on blue sky, game art style"
                />
            </div>
            <Header />
            <main className='relative z-10 container mx-auto px-4 sm:px-8 py-46'>{children}</main>
            <Footer />
        </div>
    );
};

export default Layout;