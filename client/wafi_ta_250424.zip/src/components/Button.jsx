import { useNavigate } from "react-router";
const Button = ({
  text = "Button",
  type = "button",
  className = "",
  disabled = false,
  href = "",
}) => {
  let navigate = useNavigate();
  return (
    <button
      onClick={() => {
        navigate(href);
      }}
      type={type}
      disabled={disabled}
      className={`${className} btn`}
    >
      {text}
    </button>
  );
};
export default Button;
