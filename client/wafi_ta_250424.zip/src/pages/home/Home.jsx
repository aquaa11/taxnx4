import React from "react";
import HeroSection from "./components/HeroSection";
import FeatureSection from "./components/FeatureSection";
import GuideSection from "./components/GuideSection";
import SearchPlayer from "./components/SearchPlayer";

const Home = () => {
    return (
        <div>
            <HeroSection />
            <SearchPlayer />
            <FeatureSection />
            <GuideSection />
        </div>
    );
};

export default Home;