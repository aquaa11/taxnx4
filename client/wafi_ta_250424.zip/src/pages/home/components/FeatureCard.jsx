import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

const FeatureCard = ({ icon, title, description }) => {
    return (
        <div className="feature">
            <div className="text-yellow-400 text-4xl mb-4">
                <FontAwesomeIcon icon={icon} />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">{title}</h3>
            <p className="text-white/80">{description}</p>
        </div>
    );
};

export default FeatureCard;