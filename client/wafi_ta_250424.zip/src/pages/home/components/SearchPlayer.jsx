import React, { useState, useRef } from "react";
import { getPlayer } from "../../../lib/cocAPI";
import { useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCircleXmark } from "@fortawesome/free-solid-svg-icons";
import { getPlayerDummy } from "../../../helpers/dataPlayerDummy";
import { userAPI, baseAPI, objectAPI } from "../../../lib/dbAPI";
import { useAuth } from "../../../hooks/useAuth";

const SearchPlayer = () => {
  const [search, setSearch] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [playerData, setPlayerData] = useState(null);
  const [error, setError] = useState(null);
  const [playerHistories, setPlayerHistories] = useState(() => {
    return JSON.parse(localStorage.getItem("playerHistories")) || [];
  });
  const abortControllerRef = useRef(null);
  const timeoutRef = useRef(null);
  const navigate = useNavigate();
  const { user } = useAuth();
  const handleSearchChange = (e) => {
    const value = e.target.value;
    setSearch(value);
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    if (value.length >= 2) {
      timeoutRef.current = setTimeout(() => {
        handleSearchSubmit(value);
      }, 100);
    } else {
      setPlayerData(null);
      setError(null);
      setIsLoading(false);
    }
  };

  const handleSearchSubmit = async (value) => {
    setIsLoading(true);
    setPlayerData(null);
    setError(null);

    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    abortControllerRef.current = new AbortController();

    try {
      console.log(`Searching for player with tag: ${value}`);
      const data = await getPlayer(
        value,
        abortControllerRef.current.signal
      );
      console.log("Player data received:", data);
      setPlayerData(data);
      setPlayerHistories((prev) => {
        const newHistory = [...prev];
        if (!newHistory.find((p) => p.tag === data.tag)) {
          if (newHistory.length >= 3) {
            newHistory.pop();
          }
          newHistory.unshift({ name: data.name, tag: data.tag });
          localStorage.setItem("playerHistories", JSON.stringify(newHistory));
        }
        return newHistory;
      });
    } catch (err) {
      if (err.name === "AbortError") {
        console.log("Request aborted");
        setIsLoading(false);
        return;
      }
      console.error("API Error:", err);
      // Use dummy data instead of showing error
      console.log("Using dummy data as fallback");
      const dummyData = getPlayerDummy(1);
      setPlayerData(dummyData);
      setPlayerHistories((prev) => {
        const newHistory = [...prev];
        if (!newHistory.find((p) => p.tag === dummyData.tag)) {
          if (newHistory.length >= 3) {
            newHistory.pop();
          }
          newHistory.unshift({ name: dummyData.name, tag: dummyData.tag });
          localStorage.setItem("playerHistories", JSON.stringify(newHistory));
        }
        return newHistory;
      });
      // if (err.response) {
      //   if (err.response.status === 404) {
      //     setError("Pemain tidak ditemukan. Pastikan tag player benar.");
      //     setPlayerData(null);
      //   } else if (err.response.status === 403) {
      //     setError("Akses ditolak. API key mungkin tidak valid.");
      //   } else {
      //     setError(
      //       `Error: ${err.response.status} - ${err.response.data?.message || "Terjadi kesalahan"
      //       }`
      //     );
      //   }
      // }
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddBase = async () => {
    // Check if user is signed in
    if (!user) {
      navigate("/sign-in", {
        state: {
          redirectUrl: "/base",
          message: "Silakan login terlebih dahulu untuk menambahkan base"
        }
      });
      return;
    }

    try {
      setIsLoading(true);

      // Validate player data before attempting to save
      if (!playerData?.tag || !playerData?.townHallLevel) {
        throw new Error("Invalid player data. Missing required fields.");
      }

      // First, save or update the base with validated data
      const baseResult = await baseAPI.findOrSaveBase(user.id, {
        tag: playerData.tag,
        name: playerData.name || 'Unnamed Base',
        townHallLevel: playerData.townHallLevel || 1
      });
      
      const baseId = baseResult.id || baseResult.wafi_id;

      if (!baseId) {
        throw new Error("Failed to get base ID after saving");
      }

      // Prepare arrays for different object types
      let objectsToCreate = [];

      // Process heroes data if available
      if (playerData.heroes && playerData.heroes.length > 0) {
        const heroObjects = playerData.heroes.map(hero => ({
          name: hero.name,
          level: hero.level,
          type: 'hero'
        }));
        objectsToCreate = [...objectsToCreate, ...heroObjects];
      }

      // Process hero equipment data if available
      if (playerData.heroEquipment && playerData.heroEquipment.length > 0) {
        const equipmentObjects = playerData.heroEquipment.map(equipment => ({
          name: equipment.name,
          level: equipment.level,
          type: 'equipment'
        }));
        objectsToCreate = [...objectsToCreate, ...equipmentObjects];
      }

      // Process troops data if available
      if (playerData.troops && playerData.troops.length > 0) {
        const troopObjects = playerData.troops.map(troop => ({
          name: troop.name,
          level: troop.level,
          type: 'troop'
        }));
        objectsToCreate = [...objectsToCreate, ...troopObjects];
      }

      // Process spells data if available
      if (playerData.spells && playerData.spells.length > 0) {
        const spellObjects = playerData.spells.map(spell => ({
          name: spell.name,
          level: spell.level,
          type: 'spell'
        }));
        objectsToCreate = [...objectsToCreate, ...spellObjects];
      }

      // Check existing objects and create/update as needed
      if (objectsToCreate.length > 0) {
        // Make a special API call for SearchPlayer that first checks if objects exist in the database
        try {
          // Convert objects to the format needed for the API
          const buildings = objectsToCreate.map(obj => ({
            name: obj.name,
            level: obj.level,
            baseId: baseId,  // Include the baseId for checking existing objects
            type: obj.type   // Include the type for object categorization
          }));

          // Create a custom endpoint or modify the existing one to handle this special case
          // This will be processed differently on the server side
          const result = await objectAPI.createOrUpdateObjectsFromSearch(baseId, buildings);
          console.log("Objects created/updated:", result);
        } catch (error) {
          console.error("Error creating/updating objects:", error);
          // Continue with base navigation even if object creation fails
        }
      }

      // Navigate to the base page after successful addition/update
      navigate("/base");
    } catch (error) {
      console.error("Error managing base:", error);
      setError(`Failed to add or update base: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteHistory = (tag) => {
    setPlayerHistories((prev) => {
      const newHistory = prev.filter((p) => p.tag !== tag);
      localStorage.setItem("playerHistories", JSON.stringify(newHistory));
      return newHistory;
    });
  };

  return (
    <section className="flex flex-col max-w-3xl mx-auto mb-24">
      <div className="bg-white/10 backdrop-blur-md rounded-xl flex items-center border-2 border-white/20 relative">
        <input
          value={search}
          onChange={handleSearchChange}
          type="text"
          placeholder="Masukkan Tag Pemain (contoh: #ABC123XYZ)"
          className="w-full bg-transparent text-white placeholder-white/70 outline-none px-4 py-3"
        />
        {search && (
          <button
            className="absolute right-4"
            onClick={() => {
              setSearch("");
            }}
          >
            <FontAwesomeIcon
              icon={faCircleXmark}
              className="text-xl text-white/50"
            />
          </button>
        )}
      </div>

      {playerHistories.length > 0 && (
        <div className="mt-4 bg-white/10 backdrop-blur-md rounded-lg pt-5 p-3  border border-white/20 text-white flex gap-4 relative bg-yellow">
          <label className="absolute -top-3 left-3 rounded text-white/80 text-base">
            Riwayat Pencarian
          </label>
          {playerHistories.map((playerHistory, index) => (
            <div className="relative" key={index}>
              <button
                key={playerHistory.tag}
                className="btn backdrop-blur-md bg-white/5 border-white/20 text-white/70 px-2 py-1 hover:text-white/90 hover:bg-white/20 font-thin"
                onClick={() => {
                  setSearch(playerHistory.tag);
                  handleSearchSubmit(playerHistory.tag);
                }}
              >
                {playerHistory.name} <br />
                {playerHistory.tag}
              </button>
              <button
                onClick={() => {
                  handleDeleteHistory(playerHistory.tag);
                }}
                className=" absolute -top-2 -right-2"
              >
                <FontAwesomeIcon
                  icon={faCircleXmark}
                  className="text-xl text-yellow-400  bg-white rounded-full"
                />
              </button>
            </div>
          ))}
        </div>
      )}
      {isLoading && (
        <div className="mt-4 py-2 flex justify-center items-center bg-white/5 backdrop-blur-md rounded-lg border border-white/10">
          <div className="flex items-center">
            <div className="h-4 w-4 border-t-2 border-r-2 border-white/60 rounded-full animate-spin mr-2"></div>
            <span className="text-sm text-white/70">Mencari pemain...</span>
          </div>
        </div>
      )}
      {error && (
        <div className="mt-4 bg-white/10 backdrop-blur-md rounded-lg p-3 border border-white/20 text-white">
          <p className="text-yellow-400 text-center">{error}</p>
        </div>
      )}

      {playerData && (
        <div className="mt-4 bg-white/10 backdrop-blur-md rounded-lg p-4 border border-white/20 text-white">
          <div className="flex w-full justify-between items-center">
            <div className="flex items-center">
              <div className="mr-3">
                {playerData.league ? (
                  <img
                    src={playerData.league.icon.url}
                    alt={playerData.league.name}
                    className="w-12 h-12"
                  />
                ) : (
                  <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center text-white/50">
                    No League
                  </div>
                )}
              </div>
              <div>
                <h2 className="text-2xl font-bold">{playerData.name}</h2>
                <p className="text-white/70">{playerData.tag}</p>
              </div>
            </div>
            <div className="flex">
              <button
                onClick={handleAddBase}
                className={`btn bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-lg ${isLoading ? 'opacity-70 cursor-not-allowed' : ''}`}
                disabled={isLoading}
              >
                {isLoading ? 'Menyimpan...' : user ? 'Tambah Base' : 'Login untuk Tambah Base'}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 mt-4">
            <div>
              <p className="mb-2">
                <span className="text-white/70">Town Hall:</span>{" "}
                <span className="font-semibold text-yellow-400">
                  Level {playerData.townHallLevel}
                </span>
                {playerData.townHallWeaponLevel && (
                  <span className="ml-2 text-yellow-300 text-sm">
                    (Weapon Lvl {playerData.townHallWeaponLevel})
                  </span>
                )}
              </p>
              <p className="mb-2">
                <span className="text-white/70">Exp Level:</span>{" "}
                <span className="font-semibold">{playerData.expLevel}</span>
              </p>
              <p>
                <span className="text-white/70">War Stars:</span>{" "}
                <span className="font-semibold">{playerData.warStars}</span>
              </p>
            </div>
            <div>
              <p className="mb-2">
                <span className="text-white/70">Trophy:</span>{" "}
                <span className="font-semibold">{playerData.trophies}</span>
              </p>
              <p className="mb-2">
                <span className="text-white/70">Best Trophy:</span>{" "}
                <span className="font-semibold">{playerData.bestTrophies}</span>
              </p>
              <p>
                <span className="text-white/70">Clan:</span>{" "}
                <span className="font-semibold">
                  {playerData.clan ? playerData.clan.name : "No Clan"}
                </span>
              </p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

export default SearchPlayer;
