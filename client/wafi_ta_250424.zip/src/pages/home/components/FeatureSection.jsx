import React from "react";
import {
    faChartSimple,
    faTowerObservation,
    faHourglass,
} from "@fortawesome/free-solid-svg-icons";
import FeatureCard from "./FeatureCard";

const FeatureSection = () => {
    const features = [
        {
            icon: faChartSimple,
            title: "Cek Statistik",
            description: "Analisis tentang base, pasukan, dan pertahanan yang kamu miliki",
        },
        {
            icon: faTowerObservation,
            title: "Lacak Progress",
            description: "Pantau perkembangan peningkatan bangunan dan pasukan.",
        },
        {
            icon: faHourglass,
            title: "Perkiraan Waktu",
            description: "Kalkulasi waktu upgrade dan sumber daya yang diperlukan.",
        },
    ];

    return (
        <section id="features" className="grid md:grid-cols-3 gap-8 mb-16">
            {features.map((feature, index) => (
                <FeatureCard
                    key={index}
                    icon={feature.icon}
                    title={feature.title}
                    description={feature.description}
                />
            ))}
        </section>
    );
};
export default FeatureSection;