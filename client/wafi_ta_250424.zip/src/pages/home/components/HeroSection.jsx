import React from 'react'

const HeroSection = () => {
    return (
        <section id="hero" className="text-center mb-16">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
                Pantau Progress
                <br />
                Clash of Clans Kamu!
            </h1>
            <p className="text-lg text-white/90 mb-12">
                Lacak perkembangan, analisis statistik, dan optimalkan strategi
                permainanmu
            </p>
        </section>
    )
}

export default HeroSection