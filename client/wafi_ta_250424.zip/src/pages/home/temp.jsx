import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faChartSimple,
  faTowerObservation,
  faHourglass,
  faInfoCircle,
  faArrowRight,
  faCamera,
  faExclamationTriangle,
  faLink,
  faCheckCircle,
} from "@fortawesome/free-solid-svg-icons";
import SearchPlayer from "../../components/SearchPlayer";

const Home = () => {
  return (
    <div>
      <section id="hero" className="text-center mb-16">
        <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
          Pantau Progress
          <br />
          Clash of Clans Kamu!
        </h1>
        <p className="text-lg text-white/90 mb-12">
          Lacak perkembangan, analisis statistik, dan optimalkan strategi
          permainanmu
        </p>
      </section>
      
      <section id="search" className="max-w-2xl mx-auto mb-16">
        <SearchPlayer />
      </section>
      
      <section id="features" className="grid md:grid-cols-3 gap-8 mb-16">
        <div className="feature">
          <div className="text-yellow-400 text-4xl mb-4">
            <FontAwesomeIcon icon={faChartSimple} />
          </div>
          <h3 className="text-xl font-bold text-white mb-2">Cek Statistik</h3>
          <p className="text-white/80">
            Analisis tentang base, pasukan, dan pertahanan yang kamu{" "}
          </p>
        </div>
        <div className="feature">
          <div className="text-yellow-400 text-4xl mb-4">
            <FontAwesomeIcon icon={faTowerObservation} />
          </div>
          <h3 className="text-xl font-bold text-white mb-2">Lacak Progress</h3>
          <p className="text-white/80">
            Pantau perkembangan peningkatan bangunan dan pasukan.
          </p>
        </div>
        <div className="feature">
          <div className="text-yellow-400 text-4xl mb-4">
            <FontAwesomeIcon icon={faHourglass} />
          </div>
          <h3 className="text-xl font-bold text-white mb-2">Perkiraan Waktu</h3>
          <p className="text-white/80">
            Kalkulasi waktu upgrade dan sumber daya yang diperlukan.
          </p>
        </div>
      </section>
      
      <section id="guides" className="mb-16">
        <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
          Panduan Penggunaan
        </h2>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border-2 border-white/20 text-white">
            <h3 className="text-xl font-bold mb-4 flex items-center">
              <FontAwesomeIcon icon={faInfoCircle} className="mr-2 text-yellow-400" />
              Cara Track Progress
            </h3>
            
            <ol className="list-decimal list-inside space-y-4">
              <li>
                <span className="font-bold">Cari Pemain:</span>
                <p className="text-white/80">
                  Masukkan tag pemain (contoh: #P2QJQYV89) di kolom pencarian di
                  atas, lalu tekan Enter.
                </p>
              </li>
              <li>
                <span className="font-bold">Lihat Profil:</span>
                <p className="text-white/80">
                  Setelah hasil pencarian muncul, Anda akan melihat informasi
                  pemain seperti level Town Hall, trofi, dan statistik lainnya.
                </p>
              </li>
              <li>
                <span className="font-bold">Gunakan Layout Khusus:</span>
                <p className="text-white/80">
                  <FontAwesomeIcon icon={faExclamationTriangle} className="text-yellow-400 mr-1" />
                  <strong>Penting!</strong> Klik tombol "Gunakan Layout Base" untuk mengimpor layout khusus ke game Anda.
                  Sistem kami memerlukan layout tertentu untuk analisis yang akurat.
                </p>
              </li>
              <li>
                <span className="font-bold">Ambil Screenshot:</span>
                <p className="text-white/80">
                  Setelah menggunakan layout khusus, ambil screenshot saat dalam mode Edit Layout.
                </p>
              </li>
              <li>
                <span className="font-bold">Unggah & Analisis:</span>
                <p className="text-white/80">
                  Klik tombol "Pilih Base" dan unggah screenshot Anda. Sistem kami akan menganalisis
                  dan memberikan hasil perkiraan upgrade.
                </p>
              </li>
            </ol>
          </div>
          
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border-2 border-white/20 text-white">
            <h3 className="text-xl font-bold mb-4 flex items-center">
              <FontAwesomeIcon icon={faCamera} className="mr-2 text-yellow-400" />
              Panduan Screenshot
            </h3>
            
            <div className="mb-5">
              <div className="bg-yellow-400/20 p-4 rounded-lg mb-4">
                <div className="flex items-center mb-2">
                  <FontAwesomeIcon icon={faExclamationTriangle} className="text-yellow-400 mr-2 text-xl" />
                  <span className="text-white font-bold">Perhatian!</span>
                </div>
                <p className="text-white/90">
                  Untuk hasil terbaik, <strong>gunakan layout khusus</strong> dari website ini. 
                  Proses pendeteksian otomatis memerlukan layout yang sesuai standar kami.
                </p>
              </div>
              
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="bg-white/10 p-3 rounded-lg">
                  <div className="flex items-center mb-2">
                    <FontAwesomeIcon icon={faCheckCircle} className="text-green-400 mr-2" />
                    <span className="text-white font-medium">Yang Benar:</span>
                  </div>
                  <ul className="list-disc list-inside text-white/80 text-sm space-y-1 ml-2">
                    <li>Menggunakan layout dari website ini</li>
                    <li>Screenshot dalam mode Edit Layout</li>
                    <li>Seluruh base terlihat jelas</li>
                    <li>Tidak ada menu/UI yang menutupi</li>
                  </ul>
                </div>
                <div className="bg-white/10 p-3 rounded-lg">
                  <div className="flex items-center mb-2">
                    <FontAwesomeIcon icon={faExclamationTriangle} className="text-red-400 mr-2" />
                    <span className="text-white font-medium">Yang Salah:</span>
                  </div>
                  <ul className="list-disc list-inside text-white/80 text-sm space-y-1 ml-2">
                    <li>Menggunakan layout sendiri</li>
                    <li>Screenshot dalam mode Main Village</li>
                    <li>Base terhalang oleh UI game</li>
                    <li>Screenshot terpotong/tidak lengkap</li>
                  </ul>
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="border-2 border-green-400/30 rounded-lg overflow-hidden">
                <div className="bg-green-400/20 px-3 py-1.5 text-sm font-medium text-white">
                  ✓ Screenshot Yang Benar
                </div>
                <div className="p-2">
                  <img 
                    src="/path/to/correct-screenshot.jpg" 
                    alt="Contoh Screenshot Benar"
                    className="w-full rounded"
                  />
                </div>
              </div>
              
              <div className="border-2 border-red-400/30 rounded-lg overflow-hidden">
                <div className="bg-red-400/20 px-3 py-1.5 text-sm font-medium text-white">
                  ✗ Screenshot Yang Salah
                </div>
                <div className="p-2">
                  <img 
                    src="/path/to/incorrect-screenshot.jpg" 
                    alt="Contoh Screenshot Salah"
                    className="w-full rounded"
                  />
                </div>
              </div>
            </div>
            
            <div className="mt-6 text-center">
              <a href="/track" className="bg-yellow-400 hover:bg-yellow-500 text-gray-900 py-3 px-6 rounded-lg font-medium inline-flex items-center">
                <FontAwesomeIcon icon={faLink} className="mr-2" />
                <span>Lihat Panduan Lengkap Youtube</span>
                <FontAwesomeIcon icon={faArrowRight} className="ml-2" />
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
