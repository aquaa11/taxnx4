import React from "react";
import { useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTrash } from "@fortawesome/free-solid-svg-icons";
import getTownhallIcon from "../../../../helpers/getTownhallIcon";
const BaseCard = ({ base, onDelete }) => {
    const navigate = useNavigate();

    const formatDate = (dateString) => {
        const date = new Date(dateString);
        return new Intl.DateTimeFormat('id-ID', {
            day: 'numeric',
            month: 'short',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        }).format(date);
    };

    const handleSelectBase = () => {
        navigate(`/base/${base.wafi_tag.replace('#', '')}`);
    };

    return (
        <div
            className="bg-white/10 backdrop-blur-md rounded-lg p-4 border border-white/20 text-white relative transition-all duration-300 hover:bg-white/20 hover:backdrop-blur-lg hover:shadow-lg"
        >
            <div className="flex justify-between items-start">
                <div>
                    <h2 className="text-xl font-bold">{base.wafi_name}</h2>
                    <p className="text-white/70">{base.wafi_tag}</p>
                    <p className="mt-2">
                        <span className="text-white/70">Town Hall:</span>{" "}
                        <span className="font-semibold text-yellow-400">
                            Level {base.wafi_th_level}
                        </span>
                    </p>
                    <p className="text-white/50 text-sm mt-2">
                        Ditambahkan: {base.wafi_created_at ? formatDate(base.wafi_created_at) : 'Unknown'}
                    </p>
                </div>
                <div className="flex flex-col items-end gap-2">
                    <img
                        src={getTownhallIcon(base.wafi_th_level)}
                        alt={`Townhall ${base.wafi_th_level} Clash Of Clans`}
                        className="w-10 h-10"
                    />
                    <button
                        onClick={(e) => {
                            e.stopPropagation();
                            onDelete(base.wafi_tag);
                        }}
                        className="text-red-400 hover:text-red-500"
                        title="Hapus base"
                    >
                        <FontAwesomeIcon icon={faTrash} />
                    </button>
                </div>
            </div>

            <div className="mt-4 flex justify-between">
                <button
                    onClick={handleSelectBase}
                    className="bg-green-500 hover:bg-green-600 text-white py-2 px-4 rounded-md transition-colors"
                >
                    Select
                </button>
            </div>
        </div>
    );
};

export default BaseCard;
