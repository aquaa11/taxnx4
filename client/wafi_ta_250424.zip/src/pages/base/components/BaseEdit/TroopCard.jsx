import React from 'react';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUnlock } from "@fortawesome/free-solid-svg-icons";

const TroopCard = ({ troop, changes, onLevelChange }) => {
  const urlAssets = import.meta.env.VITE_ASSETS_URL || 'http://localhost:3000/assets';
  
  // Get troop image URL
  const getTroopImageUrl = (troopName, level) => {
    // Normalize name for URL
    const normalizedName = troopName
      .toLowerCase()
      .replace(/['\.]/g, '')
      .replace(/\s+/g, '-');
    
    if (troop.type === 'Heroes') {
      return `${urlAssets}/hero/${normalizedName}.png`;
    }
    else if (troop.type === 'Pets') {
      return `${urlAssets}/pet/${normalizedName}.png`;
    } else if (troop.type === 'HeroEquipments') {
      return `${urlAssets}/he/${normalizedName}.png`;
    }
    
    // Use level 1 as a display level if current level is 0
    const displayLevel = level > 0 ? level : 1;
    return `${urlAssets}/troop/${normalizedName}-${displayLevel}.png`;
  };
  
  const currentLevel = changes[troop.instance_id] !== undefined 
    ? changes[troop.instance_id] 
    : troop.wafi_level;
    
  const troopImageSrc = getTroopImageUrl(troop.wafi_name, currentLevel);
  
  // Check if troop is active (level > 0)
  const isActive = currentLevel > 0;
  
  return (
    <div className="bg-white/5 rounded-lg border border-white/10 overflow-hidden">
      {/* Troop Header */}
      <div className="flex items-center justify-between bg-white/10 p-3">
        <div className="flex items-center gap-3">
          <img src={troopImageSrc} alt={troop.wafi_name} className="w-10 h-10 rounded-full" />
          <div>
            <h3 className="font-medium text-white">{troop.wafi_name}</h3>
            <div className="text-xs text-white/70">
              Max Level: {troop.wafi_max_level}
            </div>
          </div>
        </div>
        <div className="text-sm text-white/80">
          TH {troop.unlockTH}+
        </div>
      </div>
      
      {/* Troop Controls */}
      <div className="p-3">
        {isActive ? (
          <>
            <div className="flex items-center justify-between mb-2">
              <div className="text-sm">Current Level</div>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => onLevelChange(troop.instance_id, Math.max(0, currentLevel - 1))}
                  className="bg-red-600 text-white h-6 w-6 rounded-l flex items-center justify-center hover:bg-red-700 disabled:opacity-50"
                  disabled={currentLevel <= 0}
                >
                  -
                </button>
                <div className="bg-gray-800 h-6 w-10 flex items-center justify-center text-sm">
                  {currentLevel}
                </div>
                <button
                  onClick={() => onLevelChange(troop.instance_id, Math.min(troop.wafi_max_level, currentLevel + 1))}
                  className="bg-green-600 text-white h-6 w-6 rounded-r flex items-center justify-center hover:bg-green-700 disabled:opacity-50"
                  disabled={currentLevel >= troop.wafi_max_level}
                >
                  +
                </button>
              </div>
            </div>
            
            <div className="flex justify-between text-xs text-white/70">
              <span>Unlocks at TH {troop.unlockTH}</span>
              <span>{currentLevel}/{troop.wafi_max_level}</span>
            </div>
            
            {/* Level Progress Bar */}
            <div className="w-full bg-gray-700 rounded-full h-1.5 mt-2">
              <div
                className={`h-1.5 rounded-full ${
                  currentLevel === troop.wafi_max_level ? 'bg-green-500' : 
                  currentLevel > 0 ? 'bg-blue-500' : 'bg-gray-600'
                }`}
                style={{ width: `${(currentLevel / troop.wafi_max_level) * 100}%` }}
              ></div>
            </div>
          </>
        ) : (
          <div className="border-t border-white/10 pt-3 text-center">
            <p className="text-white/70 mb-3">Not unlocked yet.</p>
            <button
              className="mt-2 bg-blue-500 text-white py-2 px-4 rounded text-sm hover:bg-blue-600 transition-colors"
              onClick={() => onLevelChange(troop.instance_id, 1)}
            >
              <FontAwesomeIcon icon={faUnlock} className="mr-2" />
              Mark as Unlocked
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default TroopCard;
