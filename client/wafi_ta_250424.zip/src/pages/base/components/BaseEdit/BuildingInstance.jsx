import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowUp, faArrowDown, faDatabase, faExclamationTriangle } from '@fortawesome/free-solid-svg-icons';

const BuildingInstance = ({ instance, currentLevel, onLevelChange }) => {
    // Determine if this instance exists in the database and has a non-zero level
    const existsInDb = instance.exists_in_db;
    const isActive = currentLevel > 0;
    const urlAssets = import.meta.env.VITE_ASSETS_URL;
    // Create the building image URL based on building name and level
    const getBuildingImageUrl = () => {
        // Normalize building name (lowercase, remove spaces and special characters)
        const normalizedName = instance.wafi_name
            .toLowerCase()
            .replace(/[']/g, '')
            .replace(/\s+/g, '-');


        // Use level 1 as a fallback if current level is 0
        const displayLevel = isActive ? currentLevel : 1;

        return `${urlAssets}/${normalizedName}/${normalizedName}-${displayLevel}.png`;
    };

    return (
        <div className={`flex items-center gap-2 p-1 bg-white/5 rounded ${!isActive ? 'opacity-60' : ''}`}>
            <span className="text-xs text-white/70 w-5 text-center">#{instance.wafi_instance}</span>

            {/* Building image instead of status icon */}
            <div className={`w-8 h-8 flex-shrink-0 ${!isActive ? 'opacity-50' : ''}`}>
                <img
                    src={getBuildingImageUrl()}
                    alt={`${instance.wafi_name} Level ${currentLevel}`}
                    className="w-full h-full object-contain"
                />
            </div>

            {/* Database status indicator (small badge) */}
            {existsInDb && (
                <span className="text-xs text-green-400 absolute -mt-6 ml-6" title="Saved in database">
                    <FontAwesomeIcon icon={faDatabase} className="text-[10px]" />
                </span>
            )}

            {/* Level slider */}
            <div className="flex-grow">
                <input
                    type="range"
                    min="0"
                    max={instance.wafi_max_level}
                    value={currentLevel}
                    onChange={(e) => onLevelChange(instance.instance_id, parseInt(e.target.value))}
                    className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer accent-yellow-400"
                />
            </div>

            {/* Level display */}
            <span className="text-xs font-medium w-12 text-right">
                {currentLevel}/{instance.wafi_max_level}
            </span>

            {/* Level control buttons */}
            <div className="flex items-center gap-1">
                <button
                    className="bg-red-500 text-white h-5 w-5 rounded flex items-center justify-center hover:bg-red-600 disabled:opacity-50"
                    onClick={() => onLevelChange(instance.instance_id, Math.max(0, currentLevel - 1))}
                    disabled={currentLevel === 0}
                >
                    <FontAwesomeIcon icon={faArrowDown} className="text-xs" />
                </button>

                <button
                    className="bg-green-500 text-white h-5 w-5 rounded flex items-center justify-center hover:bg-green-600 disabled:opacity-50"
                    onClick={() => onLevelChange(instance.instance_id, Math.min(instance.wafi_max_level, currentLevel + 1))}
                    disabled={currentLevel === instance.wafi_max_level}
                >
                    <FontAwesomeIcon icon={faArrowUp} className="text-xs" />
                </button>
            </div>
        </div>
    );
};

export default BuildingInstance;
