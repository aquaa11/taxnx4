import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faLevelDown, faWrench, faLevelUp, faGlobeAmericas } from '@fortawesome/free-solid-svg-icons';

const TabControls = ({ onSetAllTabLevels, townHallLevel, onSetAllCategoriesLevels }) => {
    return (
        <div className="mb-6 p-3 bg-white/5 rounded-lg border border-white/10">
            <h3 className="text-lg font-medium text-white mb-3">Bulk Level Controls</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {/* Current tab controls */}
                <div className="flex flex-wrap gap-2">
                    <h4 className="w-full text-sm text-white/70 mb-1">Current Category:</h4>
                    <button
                        className="bg-red-500 text-white px-3 py-1.5 text-sm rounded hover:bg-red-600"
                        onClick={() => onSetAllTabLevels(0)}
                    >
                        <FontAwesomeIcon icon={faLevelDown} className="mr-2" />
                        Set Tab to Level 0
                    </button>
                    <button
                        className="bg-yellow-500 text-gray-900 px-3 py-1.5 text-sm rounded hover:bg-yellow-600"
                        onClick={() => onSetAllTabLevels(null, true)}
                    >
                        <FontAwesomeIcon icon={faWrench} className="mr-2" />
                        Set Tab to TH{townHallLevel - 1} Max
                    </button>
                    <button
                        className="bg-green-500 text-white px-3 py-1.5 text-sm rounded hover:bg-green-600"
                        onClick={() => onSetAllTabLevels('max')}
                    >
                        <FontAwesomeIcon icon={faLevelUp} className="mr-2" />
                        Set Tab to Max Level
                    </button>
                </div>
                
                {/* Global controls for all categories */}
                <div className="flex flex-wrap gap-2">
                    <h4 className="w-full text-sm text-white/70 mb-1">All Categories:</h4>
                    <button
                        className="bg-red-700 text-white px-3 py-1.5 text-sm rounded hover:bg-red-800"
                        onClick={() => onSetAllCategoriesLevels(0)}
                    >
                        <FontAwesomeIcon icon={faGlobeAmericas} className="mr-2" />
                        Set ALL to Level 0
                    </button>
                    <button
                        className="bg-yellow-700 text-white px-3 py-1.5 text-sm rounded hover:bg-yellow-800"
                        onClick={() => onSetAllCategoriesLevels(null, true)}
                    >
                        <FontAwesomeIcon icon={faGlobeAmericas} className="mr-2" />
                        Set ALL to TH{townHallLevel - 1} Max
                    </button>
                    <button
                        className="bg-green-700 text-white px-3 py-1.5 text-sm rounded hover:bg-green-800"
                        onClick={() => onSetAllCategoriesLevels('max')}
                    >
                        <FontAwesomeIcon icon={faGlobeAmericas} className="mr-2" />
                        Set ALL to Max Level
                    </button>
                </div>
            </div>
        </div>
    );
};

export default TabControls;
