import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowUp, faArrowDown, faDatabase } from '@fortawesome/free-solid-svg-icons';
import BuildingInstance from './BuildingInstance';

const BuildingCard = ({ buildingGroup, changes, onLevelChange, onSetAllBuildingLevels }) => {
    // Skip rendering the Wall building
    if (buildingGroup.wafi_name === "Wall") {
        return null;
    }

    // Create a truly unique ID for this building group
    const uniqueBuildingId = `${buildingGroup.wafi_name.replace(/\s+/g, '_')}_${buildingGroup.wafi_type_id}`;

    // Calculate active buildings (level > 0)
    const activeBuildingsCount = buildingGroup.instances.reduce((count, instance) => {
        // Check if there's a pending change for this instance
        const currentLevel = changes[instance.instance_id] !== undefined 
            ? changes[instance.instance_id] 
            : instance.wafi_level;
        
        // Count the instance if its level is greater than 0
        return currentLevel > 0 ? count + 1 : count;
    }, 0);

    // Generate quick level buttons from 0 to max level
    const quickLevelButtons = [];
    for (let level = 0; level <= buildingGroup.wafi_max_level; level++) {
        quickLevelButtons.push(
            <button
                key={`${uniqueBuildingId}_level_${level}`}
                className="bg-blue-500/70 text-white px-2 py-0.5 text-xs rounded hover:bg-blue-600"
                onClick={() => onSetAllBuildingLevels(buildingGroup, level)}
                title={`Set all to level ${level}`}
            >
                {level}
            </button>
        );
    }

    return (
        <div className="bg-white/5 p-3 rounded-lg border border-white/10">
            {/* Building header with group-level controls */}
            <div className="mb-3 pb-2 border-b border-white/10">
                <div className="flex justify-between items-center mb-2">
                    <h3 className="text-base font-medium text-white">
                        {buildingGroup.wafi_name}
                        <span className="ml-2 text-xs text-white/70">
                            ({buildingGroup.wafi_count})
                        </span>
                    </h3>

                    {/* Dynamic count indicator showing active buildings */}
                    <span className="text-xs px-2 py-1 rounded-md bg-white/10 flex items-center gap-1"
                        title={`${activeBuildingsCount} of ${buildingGroup.wafi_count} buildings have a level greater than 0`}>
                        <FontAwesomeIcon icon={faDatabase} className="text-green-400" />
                        <span>{activeBuildingsCount}/{buildingGroup.wafi_count}</span>
                    </span>
                </div>

                {/* Building type level controls */}
                <div className="flex flex-wrap gap-1 mt-2">
                    {quickLevelButtons}
                </div>
            </div>

            {/* Building instances grid */}
            <div className="grid grid-cols-1 gap-2">
                {buildingGroup.instances.map((instance) => (
                    <BuildingInstance
                        key={instance.instance_id}
                        instance={instance}
                        currentLevel={changes[instance.instance_id] !== undefined
                            ? changes[instance.instance_id]
                            : instance.wafi_level}
                        onLevelChange={onLevelChange}
                    />
                ))}
            </div>
        </div>
    );
};

export default BuildingCard;
