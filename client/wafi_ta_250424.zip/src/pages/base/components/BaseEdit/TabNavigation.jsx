import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBuilding, faBomb, faHammer, faDragon } from '@fortawesome/free-solid-svg-icons';

const TabNavigation = ({ activeTab, onTabChange }) => {
    return (
        <div className="flex space-x-1 mb-6 bg-white/5 p-1 rounded-lg overflow-x-auto">
            <button
                onClick={() => onTabChange("Defenses")}
                className={`flex items-center justify-center px-3 sm:px-4 py-2 rounded-md transition-all ${
                    activeTab === "Defenses"
                    ? "bg-yellow-400 text-gray-900 font-medium"
                    : "hover:bg-white/10 text-white/70 hover:text-white"
                }`}
            >
                <FontAwesomeIcon icon={faBuilding} className="text-lg sm:mr-2" />
                <span className="hidden sm:inline">Defenses</span>
            </button>
            
            <button
                onClick={() => onTabChange("Traps")}
                className={`flex items-center justify-center px-3 sm:px-4 py-2 rounded-md transition-all ${
                    activeTab === "Traps"
                    ? "bg-yellow-400 text-gray-900 font-medium"
                    : "hover:bg-white/10 text-white/70 hover:text-white"
                }`}
            >
                <FontAwesomeIcon icon={faBomb} className="text-lg sm:mr-2" />
                <span className="hidden sm:inline">Traps</span>
            </button>
            
            <button
                onClick={() => onTabChange("Resources")}
                className={`flex items-center justify-center px-3 sm:px-4 py-2 rounded-md transition-all ${
                    activeTab === "Resources"
                    ? "bg-yellow-400 text-gray-900 font-medium"
                    : "hover:bg-white/10 text-white/70 hover:text-white"
                }`}
            >
                <FontAwesomeIcon icon={faHammer} className="text-lg sm:mr-2" />
                <span className="hidden sm:inline">Resources</span>
            </button>
            
            <button
                onClick={() => onTabChange("Army")}
                className={`flex items-center justify-center px-3 sm:px-4 py-2 rounded-md transition-all ${
                    activeTab === "Army"
                    ? "bg-yellow-400 text-gray-900 font-medium"
                    : "hover:bg-white/10 text-white/70 hover:text-white"
                }`}
            >
                <FontAwesomeIcon icon={faDragon} className="text-lg sm:mr-2" />
                <span className="hidden sm:inline">Army</span>
            </button>
        </div>
    );
};

export default TabNavigation;
