import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowLeft, faSave, faSpinner } from '@fortawesome/free-solid-svg-icons';

const HeaderSection = ({ base, onNavigateBack, onSaveChanges, hasChanges, isSaving }) => {
    return (
        <>
            <div className="flex items-center justify-between mb-6">
                <button
                    onClick={onNavigateBack}
                    className="flex items-center gap-2 text-white/70 hover:text-white"
                >
                    <FontAwesomeIcon icon={faArrowLeft} />
                    <span>Kembali</span>
                </button>
                
                <button
                    onClick={onSaveChanges}
                    disabled={!hasChanges || isSaving}
                    className={`flex items-center gap-2 py-2 px-4 rounded-md ${
                        !hasChanges || isSaving 
                        ? 'bg-gray-500 text-white/50' 
                        : 'bg-green-600 text-white hover:bg-green-700'
                    }`}
                >
                    {isSaving ? (
                        <FontAwesomeIcon icon={faSpinner} spin />
                    ) : (
                        <FontAwesomeIcon icon={faSave} />
                    )}
                    <span>Save Changes</span>
                </button>
            </div>

            {/* Base info */}
            {base && (
                <div className="mb-6 p-4 bg-white/5 rounded-lg border border-white/10">
                    <h1 className="text-2xl font-bold">{base.wafi_name}</h1>
                    <p className="text-white/70">
                        TH Level: {base.wafi_th_level || "N/A"} • Tag: {base.wafi_tag}
                    </p>
                </div>
            )}
        </>
    );
};

export default HeaderSection;
