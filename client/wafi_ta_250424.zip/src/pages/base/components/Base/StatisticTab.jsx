import React from 'react';
import BaseStatistic from './BaseStatistic';

const StatisticTab = ({ playerData }) => {
  return (
    <div className="w-full">
      <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
        <span>Player Statistics</span>
      </h2>
      
      <BaseStatistic playerData={playerData} />
    </div>
  );
};

export default StatisticTab;
