import React, { useMemo } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
    faCoins, faDroplet, faClock, faHammer, faFlask,
    faHorse, faChartBar, faBuilding, faShield, faBomb,
    faDragon, faHome, faMoon, faTruck, faCrown, faStar, faMeteor,
    faXmarksLines
} from '@fortawesome/free-solid-svg-icons';
import dataBuildings from '../../dataBuildings';
import dataTroops from '../../dataTroops';

// Helper functions for formatting
const formatCost = (cost) => {
    if (cost >= 1000000000) return `${(cost / 1000000000).toFixed(cost % 1000000000 === 0 ? 0 : 2)}B`;
    if (cost >= 1000000) return `${(cost / 1000000).toFixed(cost % 1000000 === 0 ? 0 : 2)}M`;
    if (cost >= 1000) return `${(cost / 1000).toFixed(cost % 1000 === 0 ? 0 : 1)}K`;
    return cost.toString();
};

const formatTime = (seconds) => {
    if (seconds === 0) return 'Instant';

    const months = Math.floor(seconds / 2592000); // 30 days in seconds
    const days = Math.floor((seconds % 2592000) / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);

    let result = '';
    if (months > 0) result += `${months}mo `;
    if (days > 0 || months > 0) result += `${days}d `;
    if (hours > 0 || days > 0 || months > 0) result += `${hours}h`;
    if (minutes > 0 && days === 0 && months === 0) result += ` ${minutes}m`;

    return result.trim();
};

// Add resource icon for equipment resources
const ResourceIcon = ({ type }) => {
    switch (type.toLowerCase()) {
        case 'gold':
            return <FontAwesomeIcon icon={faCoins} className="text-yellow-400" />;
        case 'elixir':
            return <FontAwesomeIcon icon={faDroplet} className="text-pink-400" />;
        case 'dark elixir':
            return <FontAwesomeIcon icon={faDroplet} className="text-purple-900" />;
        case 'shiny':
            return <FontAwesomeIcon icon={faStar} className="text-blue-400" />;
        case 'glowy':
            return <FontAwesomeIcon icon={faStar} className="text-purple-600" />;
        case 'starry':
            return <FontAwesomeIcon icon={faStar} className="text-yellow-300" />;
        case 'mixed':
            return (
                <div className="flex items-center">
                    <FontAwesomeIcon icon={faCoins} className="text-yellow-400 mr-1" />
                    <FontAwesomeIcon icon={faDroplet} className="text-pink-400" />
                </div>
            );
        default:
            return <FontAwesomeIcon icon={faCoins} className="text-yellow-400" />;
    }
};

// Summary Card Component
const SummaryCard = ({ title, icon, children, className = "" }) => (
    <div className={`bg-white/5 rounded-lg border border-white/10 p-4 ${className}`}>
        <h3 className="text-lg font-medium mb-3 text-white flex items-center gap-2">
            <FontAwesomeIcon icon={icon} />
            {title}
        </h3>
        <div className="space-y-3">
            {children}
        </div>
    </div>
);

// ResourceCost Component
const ResourceCost = ({ type, amount, className = "" }) => (
    <div className={`flex justify-between items-center ${className}`}>
        <div className="flex items-center gap-2">
            <ResourceIcon type={type} />
            <span className="text-white/80">{type}</span>
        </div>
        <span className={`font-medium ${type.toLowerCase() === 'gold' ? 'text-yellow-400' :
            type.toLowerCase() === 'elixir' ? 'text-pink-400' :
                type.toLowerCase() === 'dark elixir' ? 'text-purple-900' :
                    'text-white/90'
            }`}>
            {formatCost(amount)}
        </span>
    </div>
);

// TimeDisplay Component
const TimeDisplay = ({ label, time, builders = null, className = "" }) => (
    <div className={`flex justify-between items-center ${className}`}>
        <div className="flex items-center gap-2">
            <FontAwesomeIcon icon={faClock} className="text-blue-400" />
            <span className="text-white/80">{label}</span>
        </div>
        <span className="text-blue-400 font-medium">{formatTime(time)}</span>
    </div>
);

// Add Wall specific helper functions
const getWallUpgradeCost = (level) => {
    const wallData = dataBuildings.find(b => b.name === "Wall");
    if (!wallData) return 0;

    const levelInfo = wallData.lvls.find(l => l.lv === level);
    return levelInfo ? levelInfo.cost : 0;
};

const getWallUpgradeCostRange = (fromLevel, toLevel) => {
    const wallData = dataBuildings.find(b => b.name === "Wall");
    if (!wallData || fromLevel >= toLevel) return 0;

    let totalCost = 0;
    // Sum up the costs for each level increment
    for (let level = fromLevel + 1; level <= toLevel; level++) {
        const levelInfo = wallData.lvls.find(l => l.lv === level);
        if (levelInfo) {
            totalCost += levelInfo.cost;
        }
    }
    return totalCost;
};

// Add a new component for wall costs
const WallsCard = ({ wallData }) => {
    // Calculate total cost to max all walls
    const wallCostData = useMemo(() => {
        if (!wallData || !wallData.instances) return { cost: 0, remaining: 0, complete: 0 };

        let totalCost = 0;
        let totalWallsPlaced = 0;
        let totalComplete = 0;
        let totalRemaining = 0;

        // 1. Calculate cost to upgrade existing walls to max
        wallData.instances.forEach(instance => {
            if (instance.wafi_wall_count > 0) {
                totalWallsPlaced += instance.wafi_wall_count;

                if (instance.wafi_level === wallData.maxWallLevel) {
                    totalComplete += instance.wafi_wall_count;
                } else {
                    totalRemaining += instance.wafi_wall_count;
                    // Calculate cost to upgrade these walls to max level
                    const costToMax = getWallUpgradeCostRange(instance.wafi_level, wallData.maxWallLevel);
                    totalCost += costToMax * instance.wafi_wall_count;
                }
            }
        });

        // 2. Calculate cost for remaining walls that need to be built and upgraded
        const remainingWalls = Math.max(0, wallData.totalWallPieces - totalWallsPlaced);
        if (remainingWalls > 0) {
            totalRemaining += remainingWalls;
            // Cost to build and upgrade walls from level 1 to max
            const costFromLevel1 = getWallUpgradeCostRange(1, wallData.maxWallLevel);
            totalCost += costFromLevel1 * remainingWalls;
        }

        return {
            cost: totalCost,
            complete: totalComplete,
            remaining: totalRemaining,
            total: wallData.totalWallPieces,
            placed: totalWallsPlaced
        };
    }, [wallData]);

    // Skip rendering if there's no wall data
    if (!wallData) {
        return null;
    }

    return (
        <SummaryCard title="Walls" icon={faXmarksLines}>
            <div className="flex justify-between items-center mb-2">
                <span className="text-white/80">Walls Placed</span>
                <span className="font-medium text-white">
                    {wallCostData.placed} / {wallCostData.total}
                </span>
            </div>

            <div className="flex justify-between items-center mb-2">
                <span className="text-white/80">Complete (Max Level)</span>
                <span className="font-medium text-green-400">
                    {wallCostData.complete} / {wallCostData.total}
                </span>
            </div>

            <div className="flex justify-between items-center mb-2">
                <span className="text-white/80">Need Upgrading</span>
                <span className="font-medium text-yellow-400">
                    {wallCostData.remaining}
                </span>
            </div>

            <div className="pt-2 border-t border-white/10">
                <ResourceCost type="Mixed" amount={wallCostData.cost} />
                <div className="text-xs text-white/60 mt-1">
                    Wall upgrades use Gold or Elixir and are instant (no builder time).
                </div>
            </div>
        </SummaryCard>
    );
};

// Add a new component for hero equipment costs
const EquipmentCard = ({ processedTroopData }) => {
    // Calculate equipment costs
    const equipmentCosts = useMemo(() => {
        if (!processedTroopData?.HeroEquipments) return { shiny: 0, glowy: 0, starry: 0 };

        let totalShiny = 0;
        let totalGlowy = 0;
        let totalStarry = 0;

        processedTroopData.HeroEquipments.forEach(equipment => {
            // Skip if level is 0 or already maxed
            if (equipment.currentLevel === 0 || equipment.currentLevel >= equipment.availableMaxLevel) {
                return;
            }

            // Calculate upgrade costs for each level
            for (let level = equipment.currentLevel + 1; level <= equipment.availableMaxLevel; level++) {
                const levelData = equipment.levels.find(l => l.lv === level);
                if (!levelData) continue;

                totalShiny += (levelData.s || 0);
                totalGlowy += (levelData.g || 0);
                totalStarry += (levelData.st || 0);
            }
        });

        return { shiny: totalShiny, glowy: totalGlowy, starry: totalStarry };
    }, [processedTroopData]);

    // Skip rendering if there are no equipment costs
    if (equipmentCosts.shiny === 0 && equipmentCosts.glowy === 0 && equipmentCosts.starry === 0) {
        return null;
    }

    return (
        <SummaryCard title="Hero Equipment" icon={faMeteor}>
            {equipmentCosts.shiny > 0 && (
                <ResourceCost
                    type="Shiny"
                    amount={equipmentCosts.shiny}
                    className={equipmentCosts.glowy > 0 || equipmentCosts.starry > 0 ? "mb-1" : ""}
                />
            )}
            {equipmentCosts.glowy > 0 && (
                <ResourceCost
                    type="Glowy"
                    amount={equipmentCosts.glowy}
                    className={equipmentCosts.starry > 0 ? "mb-1" : ""}
                />
            )}
            {equipmentCosts.starry > 0 && (
                <ResourceCost type="Starry" amount={equipmentCosts.starry} />
            )}
        </SummaryCard>
    );
};

const ProgressTab = ({ processedObjectData, processedTroopData, playerData, base, wallData }) => {
    // Calculate builder time (buildings that require builders)
    const builderTimeData = useMemo(() => {
        if (!processedObjectData) return { time: 0, gold: 0, elixir: 0, darkElixir: 0, mixed: 0 };

        let totalTime = 0;
        let totalGold = 0;
        let totalElixir = 0;
        let totalDarkElixir = 0;
        let totalMixed = 0;

        // Process all building categories
        Object.keys(processedObjectData).forEach(category => {
            Object.keys(processedObjectData[category]).forEach(buildingName => {
                const buildings = processedObjectData[category][buildingName];
                const buildingData = dataBuildings.find(b => b.name === buildingName);
                const costType = buildingData?.ct || 'gold';

                buildings.forEach(building => {
                    // Skip buildings with level 0 or already maxed
                    if (building.wafi_level === 0 || building.wafi_level >= building.wafi_max_level) {
                        return;
                    }

                    // Calculate upgrade costs for each level
                    for (let level = building.wafi_level + 1; level <= building.wafi_max_level; level++) {
                        const levelData = buildingData?.lvls.find(l => l.lv === level);
                        if (!levelData) continue;

                        totalTime += levelData.time;

                        // Add cost to appropriate resource type
                        if (costType === 'gold') {
                            totalGold += levelData.cost;
                        } else if (costType === 'elixir') {
                            totalElixir += levelData.cost;
                        } else if (costType === 'dark elixir') {
                            totalDarkElixir += levelData.cost;
                        } else if (costType === 'gold/elixir') {
                            totalMixed += levelData.cost;
                        }
                    }

                    // Add town hall weapon upgrade time and cost
                    if (building.has_weapon && building.wafi_weapon_level < building.wafi_max_weapon_level) {
                        for (let level = building.wafi_weapon_level + 1; level <= building.wafi_max_weapon_level; level++) {
                            totalTime += 432000; // 5 days per level
                            totalGold += 3000000 + ((level - 1) * 1000000); // Estimated cost
                        }
                    }
                });
            });
        });

        return {
            time: totalTime,
            gold: totalGold,
            elixir: totalElixir,
            darkElixir: totalDarkElixir,
            mixed: totalMixed
        };
    }, [processedObjectData]);

    // Calculate laboratory time (troops, spells, sieges)
    const labTimeData = useMemo(() => {
        if (!processedTroopData) return { time: 0, elixir: 0, darkElixir: 0 };

        let totalTime = 0;
        let totalElixir = 0;
        let totalDarkElixir = 0;

        // Categories that use the lab
        const labCategories = ['Troops', 'DarkTroops', 'Spells', 'DarkSpells', 'Sieges'];

        labCategories.forEach(category => {
            if (!processedTroopData[category]) return;

            processedTroopData[category].forEach(troop => {
                // Skip if level is 0 or already maxed
                if (troop.currentLevel === 0 || troop.currentLevel >= troop.availableMaxLevel) {
                    return;
                }

                // Calculate upgrade costs for each level
                for (let level = troop.currentLevel + 1; level <= troop.availableMaxLevel; level++) {
                    const levelData = troop.levels.find(l => l.lv === level);
                    if (!levelData) continue;

                    totalTime += levelData.time;

                    // Add cost to appropriate resource type
                    if (troop.costType === 'elixir') {
                        totalElixir += levelData.cost;
                    } else if (troop.costType === 'dark elixir') {
                        totalDarkElixir += levelData.cost;
                    }
                }
            });
        });

        return { time: totalTime, elixir: totalElixir, darkElixir: totalDarkElixir };
    }, [processedTroopData]);

    // Calculate hero upgrade time and costs
    const heroTimeData = useMemo(() => {
        if (!processedTroopData?.Heroes) return { time: 0, darkElixir: 0, elixir: 0 };

        let totalTime = 0;
        let totalDarkElixir = 0;
        let totalElixir = 0;

        processedTroopData.Heroes.forEach(hero => {
            // Skip if level is 0 or already maxed
            if (hero.currentLevel === 0 || hero.currentLevel >= hero.availableMaxLevel) {
                return;
            }

            // Calculate upgrade costs for each level
            for (let level = hero.currentLevel + 1; level <= hero.availableMaxLevel; level++) {
                const levelData = hero.levels.find(l => l.lv === level);
                if (!levelData) continue;

                totalTime += levelData.time;

                // Add cost to appropriate resource type
                if (hero.costType === 'dark elixir') {
                    totalDarkElixir += levelData.cost;
                } else if (hero.costType === 'elixir') {
                    totalElixir += levelData.cost;
                }
            }
        });

        return { time: totalTime, darkElixir: totalDarkElixir, elixir: totalElixir };
    }, [processedTroopData]);

    // Calculate pet upgrade time and costs
    const petTimeData = useMemo(() => {
        if (!processedTroopData?.Pets) return { time: 0, darkElixir: 0 };

        let totalTime = 0;
        let totalDarkElixir = 0;

        processedTroopData.Pets.forEach(pet => {
            // Skip if level is 0 or already maxed
            if (pet.currentLevel === 0 || pet.currentLevel >= pet.availableMaxLevel) {
                return;
            }

            // Calculate upgrade costs for each level
            for (let level = pet.currentLevel + 1; level <= pet.availableMaxLevel; level++) {
                const levelData = pet.levels.find(l => l.lv === level);
                if (!levelData) continue;

                totalTime += levelData.time;
                totalDarkElixir += levelData.cost;
            }
        });

        return { time: totalTime, darkElixir: totalDarkElixir };
    }, [processedTroopData]);

    // Calculate total upgrade costs by resource type - now include wall costs
    const totalResources = useMemo(() => {
        const wallCost = wallData ?
            wallData.instances?.reduce((total, instance) => {
                if (instance.wafi_level === wallData.maxWallLevel) return total;
                return total + getWallUpgradeCostRange(instance.wafi_level, wallData.maxWallLevel) * instance.wafi_wall_count;
            }, 0) : 0;

        // Also add cost for walls that haven't been placed yet
        const missingWalls = wallData ?
            Math.max(0, wallData.totalWallPieces - wallData.currentTotalCount) : 0;
        const missingWallCost = missingWalls > 0 && wallData ?
            getWallUpgradeCostRange(1, wallData.maxWallLevel) * missingWalls : 0;

        return {
            gold: builderTimeData.gold,
            elixir: builderTimeData.elixir + labTimeData.elixir + heroTimeData.elixir,
            darkElixir: builderTimeData.darkElixir + labTimeData.darkElixir + heroTimeData.darkElixir + petTimeData.darkElixir,
            mixed: builderTimeData.mixed + wallCost + missingWallCost,
            shiny: 0,
            glowy: 0,
            starry: 0
        };
    }, [builderTimeData, labTimeData, heroTimeData, petTimeData, wallData]);

    // Get number of available builders (default to 6 if unknown)
    const availableBuilders = 6;

    return (
        <div className="progress-tab">
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                <FontAwesomeIcon icon={faChartBar} />
                Upgrade Progress Summary
            </h2>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-8">
                {/* Structures/Buildings Summary */}
                <SummaryCard title="Structures" icon={faBuilding}>
                    <ResourceCost type="Gold" amount={builderTimeData.gold} />
                    {builderTimeData.elixir > 0 && (
                        <ResourceCost type="Elixir" amount={builderTimeData.elixir} />
                    )}
                    {builderTimeData.darkElixir > 0 && (
                        <ResourceCost type="Dark Elixir" amount={builderTimeData.darkElixir} />
                    )}
                    {builderTimeData.mixed > 0 && (
                        <ResourceCost type="Mixed" amount={builderTimeData.mixed} />
                    )}
                    <div className="pt-2 border-t border-white/10">
                        <TimeDisplay label="Total:" time={builderTimeData.time} />
                        <div className="text-sm text-white/60 mt-1 flex justify-between">
                            <span>With {availableBuilders} builders:</span>
                            <span className="text-blue-400/70">{formatTime(Math.ceil(builderTimeData.time / availableBuilders))}</span>
                        </div>
                    </div>
                </SummaryCard>

                {/* Laboratory Summary */}
                <SummaryCard title="Laboratory" icon={faFlask}>
                    <ResourceCost type="Elixir" amount={labTimeData.elixir} />
                    {labTimeData.darkElixir > 0 && (
                        <ResourceCost type="Dark Elixir" amount={labTimeData.darkElixir} />
                    )}
                    <div className="pt-2 border-t border-white/10">
                        <TimeDisplay label="Total:" time={labTimeData.time} />
                    </div>
                </SummaryCard>

                {/* Heroes Summary */}
                <SummaryCard title="Heroes" icon={faCrown}>
                    <ResourceCost type="Dark Elixir" amount={heroTimeData.darkElixir} />
                    {heroTimeData.elixir > 0 && (
                        <ResourceCost type="Elixir" amount={heroTimeData.elixir} />
                    )}
                    <div className="pt-2 border-t border-white/10">
                        <TimeDisplay label="Total:" time={heroTimeData.time} />
                    </div>
                </SummaryCard>

                {/* Pets Summary */}
                <SummaryCard title="Pets" icon={faHorse}>
                    <ResourceCost type="Dark Elixir" amount={petTimeData.darkElixir} />
                    <div className="pt-2 border-t border-white/10">
                        <TimeDisplay label="Total:" time={petTimeData.time} />
                    </div>
                </SummaryCard>
                {/* Add Walls Card */}
                {wallData && <WallsCard wallData={wallData} />}

                {/* Add Hero Equipment card if there are equipment costs */}
                <EquipmentCard processedTroopData={processedTroopData} />

                <SummaryCard title="Total Resources Required" icon={faCoins} className="mb-4">
                    <ResourceCost type="Gold" amount={totalResources.gold} className="mb-1" />
                    <ResourceCost type="Elixir" amount={totalResources.elixir} className="mb-1" />
                    {totalResources.mixed > 0 && (
                        <ResourceCost type="Mixed" amount={totalResources.mixed} className="mb-1" />
                    )}
                    <ResourceCost type="Dark Elixir" amount={totalResources.darkElixir} className="mb-1" />

                    {/* Display equipment resources if present */}
                    {totalResources.shiny > 0 && (
                        <ResourceCost type="Shiny" amount={totalResources.shiny} className="mb-1" />
                    )}
                    {totalResources.glowy > 0 && (
                        <ResourceCost type="Glowy" amount={totalResources.glowy} className="mb-1" />
                    )}
                    {totalResources.starry > 0 && (
                        <ResourceCost type="Starry" amount={totalResources.starry} className="mb-1" />
                    )}
                </SummaryCard>

                {/* Total Time Summary */}
                <SummaryCard title="Total Upgrade Times" icon={faClock}>
                    <TimeDisplay
                        label="Builder Time (Standard Upgrades):"
                        time={builderTimeData.time}
                        className="mb-1"
                    />
                    <div className="text-sm text-white/60 mb-3 flex justify-between pl-6">
                        <span>With {availableBuilders} builders:</span>
                        <span className="text-blue-400/70">{formatTime(Math.ceil(builderTimeData.time / availableBuilders))}</span>
                    </div>

                    <TimeDisplay label="Lab Time:" time={labTimeData.time} className="mb-1" />
                    <TimeDisplay label="Heroes Time:" time={heroTimeData.time} className="mb-1" />
                    <TimeDisplay label="Pet Time:" time={petTimeData.time} className="mb-1" />

                    <div className="pt-3 mt-3 border-t border-white/10"></div>
                    <div className="text-sm text-white/60 italic">
                        Please note: All times are based on your builders and lab being constantly upgrading.
                        The actual time will vary based on how efficiently you can keep your builders and
                        research lab busy.
                    </div>
                </SummaryCard>
            </div >
            );
        </div >
    );
};

export default ProgressTab;