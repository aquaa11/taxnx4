import React, { useState, useEffect, useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
    faDragon, faFlask, faMoon, faHorse, faTruck, faExclamationTriangle,
    faEdit, faCamera, faArrowUp, faArrowDown, faClock, faCoins, faDroplet,
    faGem, faPlus, faMinus, faDatabase, faLock, faUnlock,
    faStar
} from '@fortawesome/free-solid-svg-icons';

// Helper functions for formatting
const formatCost = (cost) => {
    if (cost >= 1000000) return `${(cost / 1000000).toFixed(cost % 1000000 === 0 ? 0 : 1)}M`;
    if (cost >= 1000) return `${(cost / 1000).toFixed(cost % 1000 === 0 ? 0 : 1)}K`;
    return cost.toString();
};

const formatTime = (seconds) => {
    if (seconds === 0) return 'Instant';

    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);

    let result = '';
    if (days > 0) result += `${days}d `;
    if (hours > 0 || days > 0) result += `${hours}h`;
    if (minutes > 0 && days === 0) result += ` ${minutes}m`;

    return result.trim();
};

// Get resource icon based on cost type
const ResourceIcon = ({ costType }) => {
    switch (costType) {
        case 'elixir':
            return <FontAwesomeIcon icon={faDroplet} className="text-pink-400" />;
        case 'dark elixir':
            return <FontAwesomeIcon icon={faDroplet} className="text-purple-900" />;
        case 'shiny':
            return <FontAwesomeIcon icon={faStar} className="text-blue-400" />;
        case 'glowy':
            return <FontAwesomeIcon icon={faStar} className="text-purple-600" />;
        case 'starry':
            return <FontAwesomeIcon icon={faStar} className="text-yellow-300" />;
        default: // gold
            return <FontAwesomeIcon icon={faCoins} className="text-yellow-400" />;
    }
};

// Empty State component
const EmptyState = ({ id, tabTitle }) => (
    <div className="bg-white/5 rounded-lg border border-white/10 p-6 mb-2 w-full text-center">
        <div className="flex flex-col items-center justify-center gap-4">
            <FontAwesomeIcon icon={faExclamationTriangle} className="text-yellow-500 text-4xl mb-2" />
            <h3 className="text-xl font-semibold text-white">No {tabTitle} data available</h3>
            <p className="text-white/70 mb-4">Please add your troop data first to track your progress.</p>

            <div className="flex flex-col sm:flex-row gap-4 mt-2">
                <Link
                    to={`/base/${id}/edit`}
                    className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-6 rounded-lg flex items-center justify-center gap-2 transition-colors"
                >
                    <FontAwesomeIcon icon={faEdit} />
                    <span>Edit Troops</span>
                </Link>
            </div>
        </div>
    </div>
);

// Troop Card Component
const TroopCard = ({ troop, onLevelChange, onToggleCollapse, isCollapsed, base }) => {

    const urlAssets = import.meta.env.VITE_ASSETS_URL || 'http://localhost:3000/assets';
    // Get the image URL for the troop based on its level
    const getTroopImageUrl = (troopName, level) => {
        // Normalize name for URL
        const normalizedName = troopName
            .toLowerCase()
            .replace(/['\.]/g, '')
            .replace(/\s+/g, '-');
        if (troop.type === 'Heroes') {
            return `${urlAssets}/hero/${normalizedName}.png`;
        }
        else if (troop.type === 'Pets') {
            return `${urlAssets}/pet/${normalizedName}.png`;
        } else if (troop.type === 'HeroEquipments') {
            return `${urlAssets}/he/${normalizedName}.png`;
        }
        // Use level 1 as a display level if current level is 0
        const displayLevel = level > 0 ? level : 1;

        return `${urlAssets}/hero/${normalizedName}-${displayLevel}.png`;
    };

    // Get upgrade costs and time for next level
    const getUpgradeCostAndTime = (currentLevel) => {
        const nextLevel = currentLevel + 1;
        const levelData = troop.levels.find(lvl => lvl.lv === nextLevel);
        
        if (troop.type === "HeroEquipments") {
            return levelData ? {
                shiny: levelData.s || 0,
                glowy: levelData.g || 0,
                starry: levelData.st || 0,
                time: 0 // No time for hero equipment upgrades
            } : {
                shiny: 0,
                glowy: 0,
                starry: 0,
                time: 0
            };
        } else {
            return levelData ? {
                cost: levelData.cost,
                time: levelData.time
            } : {
                cost: 0,
                time: 0
            };
        }
    };

    // Calculate costs to max level
    const getCostAndTimeToMax = (currentLevel) => {
        let costToMax = 0;
        let timeToMax = 0;
        let equipmentCostToMax = {
            shiny: 0,
            glowy: 0,
            starry: 0
        };
        
        for (let i = currentLevel + 1; i <= troop.availableMaxLevel; i++) {
            const levelData = troop.levels.find(lvl => lvl.lv === i);
            if (levelData) {
                if (troop.type === "HeroEquipments") {
                    equipmentCostToMax.shiny += (levelData.s || 0);
                    equipmentCostToMax.glowy += (levelData.g || 0);
                    equipmentCostToMax.starry += (levelData.st || 0);
                } else {
                    costToMax += levelData.cost;
                }
                
                // Add time only for non-equipment items
                if (troop.type !== "HeroEquipments") {
                    timeToMax += levelData.time;
                }
            }
        }

        return {
            costToMax: troop.type === "HeroEquipments" ? equipmentCostToMax : costToMax,
            timeToMax
        };
    };
    // Determine if the troop is maxed for the current TH level
    const isMaxed = troop.currentLevel >= troop.availableMaxLevel;

    // Calculate total upgrade costs
    const totalUpgrades = isMaxed ? { cost: 0, time: 0 } : getCostAndTimeToMax(troop.currentLevel);

    // Determine if troop exists in database
    const existsInDb = troop.exists_in_db;

    // Determine if troop is active (level > 0)
    const isActive = troop.currentLevel > 0;

    return (
        <div className={`bg-white/5 rounded-lg border border-white/10 mb-4 overflow-hidden ${!isActive ? 'opacity-70' : ''}`}>
            {/* Troop Header */}
            <div className="flex items-center justify-between bg-white/10 p-3">
                <div className="flex items-center gap-3">
                    <img
                        src={getTroopImageUrl(troop.name, troop.currentLevel)}
                        alt={troop.name}
                        className='w-12 h-12 rounded-full'
                    />
                    <div>
                        <div className="flex items-center gap-2">
                            <h3 className="font-medium text-white">{troop.name}</h3>
                        </div>
                        <div className="text-xs text-white/70">
                            {isActive
                                ? (isMaxed
                                    ? 'Maxed for TH level'
                                    : `${troop.availableMaxLevel - troop.currentLevel} upgrades remaining`)
                                : `Unlocks at TH ${troop.unlockTH}`
                            }
                        </div>
                    </div>
                </div>

                <div className="flex items-center gap-2">
                    <span className="text-sm text-white/80">Lv. {troop.currentLevel}/{troop.availableMaxLevel}</span>
                    <button
                        onClick={onToggleCollapse}
                        className="bg-white/10 hover:bg-white/20 p-1.5 rounded transition-colors"
                    >
                        <FontAwesomeIcon
                            icon={isCollapsed ? faPlus : faMinus}
                            className="text-white/70 hover:text-white"
                        />
                    </button>
                </div>
            </div>

            {/* Collapsed Summary */}
            {isCollapsed && (
                <div className="p-3 flex justify-between items-center">
                    <div className="text-sm text-white/80">
                        Unlocks at TH {troop.unlockTH}
                    </div>
                    {isMaxed ? (
                        <p className="text-green-500 font-medium text-sm">Fully Upgraded</p>
                    ) : isActive ? (
                        <div className="text-sm flex items-center gap-2">
                            <ResourceIcon costType={troop.costType} />
                            <span className={troop.costType === 'dark elixir' ? "text-purple-900" : "text-pink-400"}>
                                {formatCost(totalUpgrades.costToMax)}
                            </span>
                            <FontAwesomeIcon icon={faClock} className="text-blue-400 ml-2" />
                            <span className="text-white/70">{formatTime(totalUpgrades.timeToMax)}</span>
                        </div>
                    ) : (
                        <p className="text-yellow-500 font-medium text-sm">Not Unlocked</p>
                    )}
                </div>
            )}

            {/* Expanded Details - Upgrades and Level Controls */}
            {!isCollapsed && (
                <div className="p-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-3">
                        <div className="flex items-center gap-4 mb-2 sm:mb-0">
                            <div className="flex items-center">
                                <button
                                    className="bg-red-500 text-white h-7 w-7 rounded-l flex items-center justify-center hover:bg-red-600 disabled:opacity-50"
                                    onClick={() => onLevelChange(troop, -1)}
                                    disabled={troop.currentLevel <= 0}
                                >
                                    <FontAwesomeIcon icon={faArrowDown} />
                                </button>
                                <button
                                    className="bg-green-500 text-white h-7 w-7 rounded-r flex items-center justify-center hover:bg-green-600 disabled:opacity-50"
                                    onClick={() => onLevelChange(troop, 1)}
                                    disabled={troop.currentLevel >= troop.availableMaxLevel}
                                >
                                    <FontAwesomeIcon icon={faArrowUp} />
                                </button>
                            </div>
                            <div className="text-sm text-white/80">
                                Level {troop.currentLevel} of {troop.availableMaxLevel}
                            </div>
                        </div>
                    </div>

                    {/* Level Progress Bar */}
                    <div className="w-full bg-gray-700 rounded-full h-2 mb-4">
                        <div
                            className={`h-2 rounded-full ${isMaxed ? 'bg-green-500' : isActive ? 'bg-blue-500' : 'bg-gray-600'}`}
                            style={{ width: `${(troop.currentLevel / troop.availableMaxLevel) * 100}%` }}
                        ></div>
                    </div>

                    {/* Upgrade Costs - Modified to handle hero equipment */}
                    {!isMaxed && isActive && (
                        <div className="border-t border-white/10 pt-3">
                            <h4 className="text-sm font-medium text-white mb-2">Upgrade Costs</h4>
                            <div className="flex flex-col gap-2">
                                {/* Next Level Upgrade */}
                                <div className="flex justify-between text-sm">
                                    <span>Level {troop.currentLevel} → {troop.currentLevel + 1}</span>
                                    {troop.type !== "HeroEquipments" ? (
                                        <div className="flex items-center gap-2">
                                            <ResourceIcon costType={troop.costType} />
                                            <span className={troop.costType === 'dark elixir' ? "text-purple-900" : "text-pink-400"}>
                                                {formatCost(getUpgradeCostAndTime(troop.currentLevel).cost)}
                                            </span>
                                            <FontAwesomeIcon icon={faClock} className="text-blue-400 ml-2" />
                                            <span className="text-white/70">
                                                {formatTime(getUpgradeCostAndTime(troop.currentLevel).time)}
                                            </span>
                                        </div>) : (
                                        <div className="flex items-center gap-2">
                                            {getUpgradeCostAndTime(troop.currentLevel).shiny > 0 && (
                                                <>
                                                    <ResourceIcon costType="shiny" />
                                                    <span className="text-blue-400">
                                                        {formatCost(getUpgradeCostAndTime(troop.currentLevel).shiny)}
                                                    </span>
                                                </>
                                            )}
                                            
                                            {getUpgradeCostAndTime(troop.currentLevel).glowy > 0 && (
                                                <>
                                                    <ResourceIcon costType="glowy" className="ml-2" />
                                                    <span className="text-purple-600">
                                                        {formatCost(getUpgradeCostAndTime(troop.currentLevel).glowy)}
                                                    </span>
                                                </>
                                            )}
                                            
                                            {getUpgradeCostAndTime(troop.currentLevel).starry > 0 && (
                                                <>
                                                    <ResourceIcon costType="starry" className="ml-2" />
                                                    <span className="text-yellow-300">
                                                        {formatCost(getUpgradeCostAndTime(troop.currentLevel).starry)}
                                                    </span>
                                                </>
                                            )}
                                        </div>
                                    )}
                                </div>

                                {/* To Max Upgrade */}
                                {troop.availableMaxLevel - troop.currentLevel > 1 && (
                                    <div className="flex justify-between text-sm">
                                        <span>Level {troop.currentLevel} → {troop.availableMaxLevel} (Max)</span>
                                        {troop.type !== "HeroEquipments" ? (<div className="flex items-center gap-2">
                                            <ResourceIcon costType={troop.costType} />
                                            <span className={troop.costType === 'dark elixir' ? "text-purple-900" : "text-pink-400"}>
                                                {formatCost(totalUpgrades.costToMax)}
                                            </span>
                                            <FontAwesomeIcon icon={faClock} className="text-blue-400 ml-2" />
                                            <span className="text-white/70">
                                                {formatTime(totalUpgrades.timeToMax)}
                                            </span>
                                        </div>) : (<div className="flex items-center gap-2">
                                            {totalUpgrades.costToMax.shiny > 0 && (
                                                <>
                                                    <ResourceIcon costType="shiny" />
                                                    <span className="text-blue-400">
                                                        {formatCost(totalUpgrades.costToMax.shiny)}
                                                    </span>
                                                </>
                                            )}
                                            
                                            {totalUpgrades.costToMax.glowy > 0 && (
                                                <>
                                                    <ResourceIcon costType="glowy" className="ml-2" />
                                                    <span className="text-purple-600">
                                                        {formatCost(totalUpgrades.costToMax.glowy)}
                                                    </span>
                                                </>
                                            )}
                                            
                                            {totalUpgrades.costToMax.starry > 0 && (
                                                <>
                                                    <ResourceIcon costType="starry" className="ml-2" />
                                                    <span className="text-yellow-300">
                                                        {formatCost(totalUpgrades.costToMax.starry)}
                                                    </span>
                                                </>
                                            )}
                                        </div>)}
                                    </div>
                                )}
                            </div>
                        </div>
                    )}

                    {/* Not Unlocked Message */}
                    {!isActive && (
                        <div className="border-t border-white/10 pt-3 text-center">
                            <p className="text-white/70 mb-3">Not unlocked yet.</p>
                            <button
                                className="mt-2 bg-blue-500 text-white py-2 px-4 rounded text-sm hover:bg-blue-600 transition-colors"
                                onClick={() => onLevelChange(troop, 1)}
                            >
                                <FontAwesomeIcon icon={faUnlock} className="mr-2" />
                                Mark as Unlocked
                            </button>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

// Summary component to display total resource costs
const SummaryPanel = ({ totals }) => (
    <div className="bg-white/5 rounded-lg border border-white/10 p-4 mb-4">
        <h3 className="text-lg font-medium mb-3 text-white">Upgrade Summary</h3>

        <div className="space-y-3">
            {/* Regular Elixir Section */}
            {totals.elixir > 0 && (
                <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                        <FontAwesomeIcon icon={faDroplet} className="text-pink-400" />
                        <span className="text-white/80">Elixir</span>
                    </div>
                    <span className="text-pink-400 font-medium">{formatCost(totals.elixir)}</span>
                </div>
            )}

            {/* Dark Elixir Section */}
            {totals['dark elixir'] > 0 && (
                <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                        <FontAwesomeIcon icon={faDroplet} className="text-purple-900" />
                        <span className="text-white/80">Dark Elixir</span>
                    </div>
                    <span className="text-purple-900 font-medium">{formatCost(totals['dark elixir'])}</span>
                </div>
            )}

            {/* Shiny resources */}
            {totals.shiny > 0 && (
                <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                        <FontAwesomeIcon icon={faStar} className="text-blue-400" />
                        <span className="text-white/80">Shiny</span>
                    </div>
                    <span className="text-blue-400 font-medium">{formatCost(totals.shiny)}</span>
                </div>
            )}

            {/* Glowy resources */}
            {totals.glowy > 0 && (
                <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                        <FontAwesomeIcon icon={faStar} className="text-purple-600" />
                        <span className="text-white/80">Glowy</span>
                    </div>
                    <span className="text-purple-600 font-medium">{formatCost(totals.glowy)}</span>
                </div>
            )}

            {/* Starry resources */}
            {totals.starry > 0 && (
                <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                        <FontAwesomeIcon icon={faStar} className="text-yellow-300" />
                        <span className="text-white/80">Starry</span>
                    </div>
                    <span className="text-yellow-300 font-medium">{formatCost(totals.starry)}</span>
                </div>
            )}

            {/* Time Section - Only if there are time-based upgrades */}
            {totals.time > 0 && (
                <div className="flex justify-between items-center pt-2 border-t border-white/10">
                    <div className="flex items-center gap-2">
                        <FontAwesomeIcon icon={faClock} className="text-blue-400" />
                        <span className="text-white/80">Total Time</span>
                    </div>
                    <span className="text-blue-400 font-medium">{formatTime(totals.time)}</span>
                </div>
            )}
        </div>
    </div>
);

// Main TroopsTab Component
const TroopsTab = ({ troopData, playerData, onUpdateLevel, tabTitle, base, icon }) => {
    // console.log(playerData)x
    troopData.forEach(troop => { // Iterate over troopData to set availableMaxLevel
        if (troop.type === 'Heroes') {
            troop.availableMaxLevel = troop.levels.filter(lv => lv.lab <= base.wafi_hhLevel).length; // Set max level for heroes
        } else if (troop.type === 'Pets') {
            troop.availableMaxLevel = troop.levels.filter(lv => lv.lab <= base.wafi_phLevel).length; // Set max level for pets
        } else if (troop.type === 'HeroEquipments') {
            troop.availableMaxLevel = troop.levels.filter(lv => lv.bs <= base.wafi_bsLevel).length || 1; // Set max level for pets
        } else {
            troop.availableMaxLevel = troop.levels.filter(lv => lv.lab <= base.wafi_labLevel).length; // Set max level for sieges
        }
    });

    // console.log('Troop Data:', troopData);
    // console.log('Base Data:', base);
    // console.log('Troop Data:', troopData.filter(troop => troop.levels. != base.wafi_hhLevel));
    const { id } = useParams();
    const [collapsedItems, setCollapsedItems] = useState({});
    // Toggle collapsed state for a troop
    const toggleCollapse = (troopName) => {
        setCollapsedItems(prev => ({
            ...prev,
            [troopName]: !prev[troopName]
        }));
    };

    // Handle level changes for troops
    const handleLevelChange = (troop, change) => {
        const newLevel = troop.currentLevel + change;

        // Don't go below 0 or above max level
        if (newLevel < 0 || newLevel > troop.availableMaxLevel) return;

        if (onUpdateLevel) {
            if (troop.exists_in_db) {
                // If the troop is in the database, update or delete it
                if (newLevel === 0) {
                    // If new level is 0, delete the object from database
                    onUpdateLevel(troop.wafi_id, 0);
                } else {
                    // Otherwise update the level
                    onUpdateLevel(troop.wafi_id, newLevel);
                }
            } else if (newLevel > 0) {
                // If not in database and new level > 0, create it
                // We're using the name directly for creation
                console.log('Troop:', troop, newLevel);

                onUpdateLevel(troop.name, newLevel);
            }
        }
    };

    // Check if data is empty
    const isEmpty = !troopData || troopData.length === 0;

    // Calculate progress
    const calculateProgress = () => {
        if (isEmpty) return { maxed: 0, total: 0, percent: 0, active: 0 };

        const maxed = troopData.filter(troop =>
            troop.currentLevel >= troop.availableMaxLevel
        ).length;

        const active = troopData.filter(troop => troop.currentLevel > 0).length;
        const total = troopData.length;
        const percent = total > 0 ? Math.round((maxed / total) * 100) : 0;

        return { maxed, total, percent, active };
    };

    const progress = calculateProgress();

    // Calculate total upgrade costs
    const calculateTotalUpgrades = useMemo(() => {
        if (isEmpty) return { elixir: 0, 'dark elixir': 0, time: 0, shiny: 0, glowy: 0, starry: 0 };

        let totalElixir = 0;
        let totalDarkElixir = 0;
        let totalTime = 0;
        let totalShiny = 0;
        let totalGlowy = 0;
        let totalStarry = 0;

        troopData.forEach(troop => {
            if (troop.currentLevel > 0 && troop.currentLevel < troop.availableMaxLevel) {
                // Calculate remaining upgrades
                for (let i = troop.currentLevel + 1; i <= troop.availableMaxLevel; i++) {
                    const levelData = troop.levels.find(lvl => lvl.lv === i);
                    if (levelData) {
                        if (troop.type === "HeroEquipments") {
                            totalShiny += (levelData.s || 0);
                            totalGlowy += (levelData.g || 0);
                            totalStarry += (levelData.st || 0);
                        } else {
                            if (troop.costType === 'elixir') {
                                totalElixir += levelData.cost;
                            } else if (troop.costType === 'dark elixir') {
                                totalDarkElixir += levelData.cost;
                            }
                            totalTime += levelData.time;
                        }
                    }
                }
            }
        });

        return {
            elixir: totalElixir,
            'dark elixir': totalDarkElixir,
            time: totalTime,
            shiny: totalShiny,
            glowy: totalGlowy,
            starry: totalStarry
        };
    }, [troopData, isEmpty]);

    return (
        <div className="troops-tab">
            {/* Header with title and progress */}
            <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold flex items-center gap-2">
                    <FontAwesomeIcon icon={icon} />
                    {tabTitle}
                </h2>

                <div className="flex items-center gap-3">
                    {!isEmpty && (
                        <div className="flex items-center">
                            Maxed {troopData.type}
                            <div className="ml-2 bg-gray-700 rounded-full h-1.5 w-24 overflow-hidden">
                                <div
                                    className="bg-blue-500 h-1.5 rounded-full"
                                    style={{ width: `${progress.percent}%` }}
                                ></div>
                            </div>
                            <span className="text-xs ml-2">
                                {progress.maxed}/{progress.total}
                            </span>
                        </div>
                    )}

                    <Link
                        to={`/base/${id}/edit`}
                        className="bg-blue-600 hover:bg-blue-700 text-white py-1.5 px-3 rounded-lg flex items-center justify-center gap-1 text-sm transition-colors"
                    >
                        <FontAwesomeIcon icon={faEdit} />
                        <span>Edit All</span>
                    </Link>
                </div>
            </div>

            <div className="lg:grid lg:grid-cols-3 gap-4">
                {/* Troop Cards - Takes 2/3 of the space */}
                <div className="lg:col-span-2">
                    {isEmpty ? (
                        <EmptyState id={id} tabTitle={tabTitle} />
                    ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {troopData.map((troop, index) => (
                                <TroopCard
                                    key={index}
                                    troop={troop}
                                    onLevelChange={handleLevelChange}
                                    isCollapsed={!!collapsedItems[troop.name]}
                                    onToggleCollapse={() => toggleCollapse(troop.name)}
                                    base={base}
                                />
                            ))}
                        </div>
                    )}
                </div>

                {/* Summary Panel - Takes 1/3 of the space */}
                <div className="mt-4 lg:mt-0">
                    <SummaryPanel totals={calculateTotalUpgrades} />
                </div>
            </div>
        </div>
    );
};

export default TroopsTab;