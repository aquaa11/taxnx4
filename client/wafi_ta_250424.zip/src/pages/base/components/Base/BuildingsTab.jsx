import React, { useState, useMemo } from 'react';
import { Link, useParams } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
    faShield, faArrowUp, faArrowDown, faEdit, faCamera, faExclamationTriangle,
    faBomb, faHome, faBuilding, faClock, faCoins, faPlus, faMinus, faDroplet, faGem
} from '@fortawesome/free-solid-svg-icons';
import dataBuildings from '../../dataBuildings';

// Helper functions for formatting
const formatCost = (cost) => {
    if (cost >= 1000000) return `${(cost / 1000000).toFixed(cost % 1000000 === 0 ? 0 : 1)}M`;
    if (cost >= 1000) return `${(cost / 1000).toFixed(cost % 1000 === 0 ? 0 : 1)}K`;
    return cost.toString();
};

const formatTime = (seconds) => {
    if (seconds === 0) return 'Instant';

    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);

    let result = '';
    if (days > 0) result += `${days}d `;
    if (hours > 0 || days > 0) result += `${hours}h`;
    if (minutes > 0 && days === 0) result += ` ${minutes}m`;

    return result.trim();
};

// Enhanced function to get upgrade costs and time for next level
const getUpgradeCostAndTime = (buildingName, currentLevel) => {
    const building = dataBuildings.find(b => b.name === buildingName);
    if (!building) return { cost: 0, time: 0, costType: 'gold' };

    const nextLevel = currentLevel + 1;
    const levelData = building.lvls.find(lvl => lvl.lv === nextLevel);
    const costType = building.ct || 'gold'; // Get cost type from building data

    return levelData ? { cost: levelData.cost, time: levelData.time, costType } : { cost: 0, time: 0, costType };
};

// Enhanced function to calculate costs to max level
const getCostAndTimeToMax = (buildingName, currentLevel, maxLevel) => {
    const building = dataBuildings.find(b => b.name === buildingName);
    if (!building) return { costToMax: 0, timeToMax: 0, costType: 'gold' };

    let costToMax = 0;
    let timeToMax = 0;
    const costType = building.ct || 'gold'; // Get cost type from building data

    for (let i = currentLevel + 1; i <= maxLevel; i++) {
        const levelData = building.lvls.find(lvl => lvl.lv === i);
        if (levelData) {
            costToMax += levelData.cost;
            timeToMax += levelData.time;
        }
    }

    return { costToMax, timeToMax, costType };
};

// Get resource icon based on cost type
const ResourceIcon = ({ costType }) => {
    switch (costType) {
        case 'elixir':
            return <FontAwesomeIcon icon={faDroplet} className="text-pink-400" />;
        case 'dark elixir':
            return <FontAwesomeIcon icon={faDroplet} className="text-purple-900" />;
        case 'gold/elixir':
            return (
                <div className="flex -space-x-1">
                    <FontAwesomeIcon icon={faCoins} className="text-yellow-400" />
                    <FontAwesomeIcon icon={faDroplet} className="text-pink-400 -ml-1" />
                </div>
            );
        default: // gold
            return <FontAwesomeIcon icon={faCoins} className="text-yellow-400" />;
    }
};

// Building Image component
const BuildingImage = ({ src, alt, size = "w-8 h-8" }) => (
    <img
        src={src}
        alt={alt}
        className={`${size} object-contain`}
        onError={(e) => {
            e.target.onerror = null;
            e.target.style.display = 'none';
        }}
    />
);

// Level Controls component
const LevelControls = ({ building, onLevelChange }) => (
    <div className="flex gap-1">
        <button
            className="bg-green-500 text-white text-xs px-2 py-1 rounded hover:bg-green-600 disabled:opacity-50"
            onClick={() => onLevelChange(building, 1)}
            disabled={building.wafi_level === building.wafi_max_level}
        >
            <FontAwesomeIcon icon={faArrowUp} />
        </button>
        <button
            className="bg-red-500 text-white text-xs px-2 py-1 rounded hover:bg-red-600 disabled:opacity-50"
            onClick={() => onLevelChange(building, -1)}
            disabled={building.wafi_level === 0}
        >
            <FontAwesomeIcon icon={faArrowDown} />
        </button>
    </div>
);

// Special Town Hall component for buildings with weapons
const TownHallControls = ({ building, onLevelChange }) => (
    <div className="flex gap-1">
        <button
            className="bg-purple-500 text-white text-xs px-2 py-1 rounded hover:bg-purple-600 disabled:opacity-50"
            onClick={() => onLevelChange(building, 1, true)}
            disabled={building.wafi_weapon_level === building.wafi_max_weapon_level}
            title="Upgrade Weapon"
        >
            <FontAwesomeIcon icon={faArrowUp} />
            <span className="ml-1">Weapon</span>
        </button>
    </div>
);

// Empty State component
const EmptyState = ({ id, tabTitle }) => (
    <div className="bg-white/5 rounded-lg border border-white/10 p-6 mb-2 w-full text-center">
        <div className="flex flex-col items-center justify-center gap-4">
            <FontAwesomeIcon icon={faExclamationTriangle} className="text-yellow-500 text-4xl mb-2" />
            <h3 className="text-xl font-semibold text-white">No {tabTitle} data available</h3>
            <p className="text-white/70 mb-4">Please add your buildings data first to track your base progress.</p>

            <div className="flex flex-col sm:flex-row gap-4 mt-2">
                <Link
                    to={`/base/${id}/edit`}
                    className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-6 rounded-lg flex items-center justify-center gap-2 transition-colors"
                >
                    <FontAwesomeIcon icon={faEdit} />
                    <span>Edit Base Building</span>
                </Link>

                <Link
                    to={`/base/${id}/scan`}
                    className="bg-green-600 hover:bg-green-700 text-white py-2 px-6 rounded-lg flex items-center justify-center gap-2 transition-colors"
                >
                    <FontAwesomeIcon icon={faCamera} />
                    <span>Scan Building</span>
                </Link>
            </div>
        </div>
    </div>
);

// Summary component to display total resource costs
const SummaryPanel = ({ totals }) => (
    <div className="bg-white/5 rounded-lg border border-white/10 p-4 mb-4">
        <h3 className="text-lg font-medium mb-3 text-white">Upgrade Summary</h3>

        <div className="space-y-3">
            {/* Gold Section */}
            {totals.gold > 0 && (
                <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                        <FontAwesomeIcon icon={faCoins} className="text-yellow-400" />
                        <span className="text-white/80">Gold</span>
                    </div>
                    <span className="text-yellow-400 font-medium">{formatCost(totals.gold)}</span>
                </div>
            )}

            {/* Elixir Section */}
            {totals.elixir > 0 && (
                <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                        <FontAwesomeIcon icon={faDroplet} className="text-pink-400" />
                        <span className="text-white/80">Elixir</span>
                    </div>
                    <span className="text-pink-400 font-medium">{formatCost(totals.elixir)}</span>
                </div>
            )}

            {/* Dark Elixir Section */}
            {totals['dark elixir'] > 0 && (
                <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                        <FontAwesomeIcon icon={faDroplet} className="text-purple-900" />
                        <span className="text-white/80">Dark Elixir</span>
                    </div>
                    <span className="text-purple-900 font-medium">{formatCost(totals['dark elixir'])}</span>
                </div>
            )}

            {/* Time Section */}
            <div className="flex justify-between items-center pt-2 border-t border-white/10">
                <div className="flex items-center gap-2">
                    <FontAwesomeIcon icon={faClock} className="text-blue-400" />
                    <span className="text-white/80">Total Time</span>
                </div>
                <span className="text-blue-400 font-medium">{formatTime(totals.time)}</span>
            </div>

            {/* Estimated time with 5 builders */}
            <div className="flex justify-between items-center text-sm">
                <div className="flex items-center gap-2">
                    <span className="text-white/60">With 5 Builders</span>
                </div>
                <span className="text-white/80">{formatTime(Math.ceil(totals.time / 5))}</span>
            </div>
        </div>
    </div>
);

// Building Card component (collapsed or expanded)
const BuildingCard = ({
    buildingName,
    buildings,
    buildingImageSrc,
    upgradesRemaining,
    isCollapsed,
    onToggleCollapse,
    onLevelChange,
    getBuildingImageUrl
}) => {
    // Calculate active buildings (level > 0)
    const activeBuildingsCount = buildings.filter(b => b.wafi_level > 0).length;
    const totalBuildingsCount = buildings.length;

    const allMaxed = upgradesRemaining === 0;

    // Calculate total costs by resource type
    const getTotalUpgradeCosts = (buildings) => {
        let totalGold = 0;
        let totalElixir = 0;
        let totalDarkElixir = 0;
        let totalTime = 0;

        buildings.forEach(building => {
            if (building.wafi_level < building.wafi_max_level && building.wafi_level > 0) {
                const { costToMax, timeToMax, costType } = getCostAndTimeToMax(
                    building.wafi_name,
                    building.wafi_level,
                    building.wafi_max_level
                );

                // Assign cost to appropriate resource type
                if (costType === 'gold') {
                    totalGold += costToMax;
                } else if (costType === 'elixir') {
                    totalElixir += costToMax;
                } else if (costType === 'dark elixir') {
                    totalDarkElixir += costToMax;
                } else if (costType === 'gold/elixir') {
                    // For resources that can use either gold or elixir, add to gold for simplicity
                    totalGold += costToMax;
                }

                totalTime += timeToMax;
            }
        });

        return {
            gold: totalGold,
            elixir: totalElixir,
            'dark elixir': totalDarkElixir,
            time: totalTime
        };
    };

    const totals = isCollapsed ? getTotalUpgradeCosts(buildings) : { gold: 0, elixir: 0, 'dark elixir': 0, time: 0 };

    // Get cost type for this building
    const building = dataBuildings.find(b => b.name === buildingName);
    const costType = building?.ct || 'gold';

    return (
        <div className="bg-white/5 rounded-lg border border-white/10 mb-4 overflow-hidden">
            {/* Building Header */}
            <div className="flex items-center justify-between bg-white/10 p-3">
                <div className="flex items-center gap-3">
                    <BuildingImage src={buildingImageSrc} alt={buildingName} size="w-10 h-10" />
                    <div>
                        <div className="flex items-center gap-2">
                            <h3 className="font-medium text-white">{buildingName}</h3>
                            <ResourceIcon costType={costType} />
                            <span className="text-xs px-2 py-0.5 rounded-md bg-white/10"
                                title={`${activeBuildingsCount} of ${totalBuildingsCount} buildings active`}>
                                {activeBuildingsCount}/{totalBuildingsCount}
                            </span>
                        </div>
                        <div className="text-xs text-white/70">
                            {upgradesRemaining ? `${upgradesRemaining} upgrades remaining` : 'All maxed'}
                        </div>
                    </div>
                </div>

                <button
                    onClick={onToggleCollapse}
                    className="bg-white/10 hover:bg-white/20 p-1.5 rounded transition-colors"
                >
                    <FontAwesomeIcon
                        icon={isCollapsed ? faPlus : faMinus}
                        className="text-white/70 hover:text-white"
                    />
                </button>
            </div>

            {/* Collapsed Summary */}
            {isCollapsed && (
                <div className="p-3 flex justify-between items-center">
                    <div className="text-sm text-white/80">
                        {buildings.length} {buildingName}{buildings.length > 1 ? 's' : ''}
                    </div>
                    {allMaxed ? (
                        <p className="text-green-500 font-medium text-sm">All Fully Upgraded</p>
                    ) : (
                        <div className="text-sm flex items-center gap-2">
                            {totals.gold > 0 && (
                                <>
                                    <FontAwesomeIcon icon={faCoins} className="text-yellow-400" />
                                    <span className="text-yellow-400">{formatCost(totals.gold)}</span>
                                </>
                            )}
                            {totals.elixir > 0 && (
                                <>
                                    <FontAwesomeIcon icon={faDroplet} className="text-pink-400 ml-2" />
                                    <span className="text-pink-400">{formatCost(totals.elixir)}</span>
                                </>
                            )}
                            {totals['dark elixir'] > 0 && (
                                <>
                                    <FontAwesomeIcon icon={faDroplet} className="text-purple-900 ml-2" />
                                    <span className="text-purple-900">{formatCost(totals['dark elixir'])}</span>
                                </>
                            )}
                            <FontAwesomeIcon icon={faClock} className="text-blue-400 ml-2" />
                            <span className="text-white/70">{formatTime(totals.time)}</span>
                        </div>
                    )}
                </div>
            )}

            {/* Expanded Details */}
            {!isCollapsed && (
                <div className="p-3 divide-y divide-white/10">
                    {buildings.map((building, idx) => {
                        // Get cost type for this building
                        const buildingData = dataBuildings.find(b => b.name === building.wafi_name);
                        const buildingCostType = buildingData?.ct || 'gold';

                        // Check if this is a Town Hall with weapon
                        const isTownHallWithWeapon = building.has_weapon;

                        return (
                            <div key={idx} className={`py-2 flex flex-col md:flex-row md:items-center gap-2`}>
                                <div className="flex items-center justify-between gap-2 flex-1">
                                    <BuildingImage
                                        src={getBuildingImageUrl(buildingName, building.wafi_level || 1)}
                                        alt={`${buildingName} Lv.${building.wafi_level}`}
                                    />

                                    {isTownHallWithWeapon ? (
                                        <div className="flex flex-col items-center">
                                            <span className="text-sm text-white/80">
                                                TH {building.wafi_level}
                                            </span>
                                            <span className="text-xs text-yellow-400">
                                                Weapon Lv.{building.wafi_weapon_level}/{building.wafi_max_weapon_level}
                                            </span>
                                        </div>
                                    ) : (
                                        <span className="text-sm text-white/80">
                                            {building.wafi_level}/{building.wafi_max_level}
                                        </span>
                                    )}

                                    {isTownHallWithWeapon ? (
                                        <TownHallControls building={building} onLevelChange={onLevelChange} />
                                    ) : (
                                        <LevelControls building={building} onLevelChange={onLevelChange} />
                                    )}
                                </div>

                                {/* Upgrade costs */}
                                <div className="text-xs text-white/70 md:text-right flex-1">
                                    {/* Town Hall with Weapon Display */}
                                    {isTownHallWithWeapon ? (
                                        building.wafi_weapon_level === building.wafi_max_weapon_level ? (
                                            <p className="text-green-500 font-medium float-end">Fully Upgraded Weapon</p>
                                        ) : (
                                            <div className="flex flex-col gap-1">
                                                <div className="flex items-center gap-1 justify-end">
                                                    <span>Weapon Lv. {building.wafi_weapon_level + 1}: </span>
                                                    <ResourceIcon costType="gold" />
                                                    <span className="text-yellow-400">
                                                        {formatCost(3000000 + (building.wafi_weapon_level * 1000000))}
                                                    </span>
                                                    <span className="ml-1 text-white/50">
                                                        {formatTime(432000)} {/* 5 days */}
                                                    </span>
                                                </div>

                                                {(building.wafi_max_weapon_level - building.wafi_weapon_level) > 1 && (
                                                    <div className="flex items-center gap-1 justify-end">
                                                        <span>Weapon Lv. {building.wafi_weapon_level} → {building.wafi_max_weapon_level}: </span>
                                                        <ResourceIcon costType="gold" />
                                                        <span className="text-yellow-400">
                                                            {formatCost(
                                                                // Sum of all remaining upgrade costs
                                                                Array.from(
                                                                    { length: building.wafi_max_weapon_level - building.wafi_weapon_level },
                                                                    (_, i) => 3000000 + ((building.wafi_weapon_level + i) * 1000000)
                                                                ).reduce((sum, cost) => sum + cost, 0)
                                                            )}
                                                        </span>
                                                        <span className="ml-1 text-white/50">
                                                            {formatTime(432000 * (building.wafi_max_weapon_level - building.wafi_weapon_level))}
                                                        </span>
                                                    </div>
                                                )}
                                            </div>
                                        )
                                    ) : (
                                        // Regular building upgrade costs (existing code)
                                        building.wafi_level === building.wafi_max_level ? (
                                            <p className="text-green-500 font-medium float-end">Fully Upgraded</p>
                                        ) : (
                                            <div className="flex flex-col gap-1">
                                                <div className="flex items-center gap-1 justify-end">
                                                    <span>Lv. {building.wafi_level + 1}: </span>
                                                    <ResourceIcon costType={buildingCostType} />
                                                    <span className="text-yellow-400">
                                                        {formatCost(getUpgradeCostAndTime(building.wafi_name, building.wafi_level).cost)}
                                                    </span>
                                                    <span className="ml-1 text-white/50">
                                                        {formatTime(getUpgradeCostAndTime(building.wafi_name, building.wafi_level).time)}
                                                    </span>
                                                </div>

                                                {(building.wafi_max_level - building.wafi_level) > 1 && (
                                                    <div className="flex items-center gap-1 justify-end">
                                                        <span>Lv. {building.wafi_level} → {building.wafi_max_level}: </span>
                                                        <ResourceIcon costType={buildingCostType} />
                                                        <span className="text-yellow-400">
                                                            {formatCost(getCostAndTimeToMax(building.wafi_name, building.wafi_level, building.wafi_max_level).costToMax)}
                                                        </span>
                                                        <span className="ml-1 text-white/50">
                                                            {formatTime(getCostAndTimeToMax(building.wafi_name, building.wafi_level, building.wafi_max_level).timeToMax)}
                                                        </span>
                                                    </div>
                                                )}
                                            </div>
                                        )
                                    )}
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );
};

const BuildingsTab = ({ objectData, onUpdateLevel, playerData, tabTitle = "Buildings", icon = faBuilding }) => {
    const { id } = useParams();
    const urlAssets = import.meta.env.VITE_ASSETS_URL || 'http://localhost:3000/assets';
    const [collapsedBuildings, setCollapsedBuildings] = useState({});

    // Toggle collapsed state for a building
    const toggleCollapse = (buildingName) => {
        setCollapsedBuildings(prev => ({
            ...prev,
            [buildingName]: !prev[buildingName]
        }));
    };

    // Modified handler for level changes to handle Town Hall weapon upgrades
    const handleLevelChange = (defense, change, isWeaponUpgrade = false) => {
        if (isWeaponUpgrade) {
            // This is a weapon upgrade
            const newWeaponLevel = defense.wafi_weapon_level + change;
            // Make sure we don't go below 0 or above max
            if (newWeaponLevel < 0 || newWeaponLevel > defense.wafi_max_weapon_level) return;

            // Pass the weapon upgrade flag to the parent handler
            const objectIdToUpdate = defense.wafi_id;
            if (onUpdateLevel) {
                onUpdateLevel(objectIdToUpdate, newWeaponLevel, true);
            }
        } else {
            // Regular level upgrade
            const newLevel = defense.wafi_level + change;
            // Make sure we don't go below 0 or above max
            if (newLevel < 0 || newLevel > defense.wafi_max_level) return;

            // Either use wafi_id (for DB objects) or instance_id (for non-DB objects)
            const objectIdToUpdate = defense.wafi_id;
            if (onUpdateLevel) {
                onUpdateLevel(objectIdToUpdate, newLevel);
            }
        }
    };

    // Create building image URL
    const getBuildingImageUrl = (buildingName, level) => {
        const normalizedName = buildingName
            .toLowerCase()
            .replace(/[']/g, '')
            .replace(/\s+/g, '-');

        const displayLevel = level > 0 ? level : 1;
        return `${urlAssets}/${normalizedName}/${normalizedName}-${displayLevel}.png`;
    };

    // Count stats
    const countMaxedBuildings = () => {
        if (!objectData) return 0;

        let maxed = 0;
        Object.keys(objectData).forEach(buildingName => {
            objectData[buildingName].forEach(building => {
                if (building.wafi_level === building.wafi_max_level) maxed++;
            });
        });

        return maxed;
    };

    const countTotalBuildings = () => {
        if (!objectData) return 0;

        let total = 0;
        Object.keys(objectData).forEach(buildingName => {
            total += objectData[buildingName].length;
        });

        return total;
    };

    const totalBuildings = countTotalBuildings();
    const maxedBuildings = countMaxedBuildings();
    const progressPercent = totalBuildings > 0 ? Math.round((maxedBuildings / totalBuildings) * 100) : 0;

    // Calculate total upgrade costs and time - only include buildings with level > 0
    const calculateTotalUpgrades = useMemo(() => {
        if (!objectData) return { gold: 0, elixir: 0, 'dark elixir': 0, time: 0 };

        let totalGold = 0;
        let totalElixir = 0;
        let totalDarkElixir = 0;
        let totalTime = 0;

        Object.keys(objectData).forEach(buildingName => {
            const buildings = objectData[buildingName];
            const building = dataBuildings.find(b => b.name === buildingName);
            const costType = building?.ct || 'gold';

            buildings.forEach(building => {
                // Handle Town Hall weapon upgrades
                if (building.has_weapon && building.wafi_weapon_level < building.wafi_max_weapon_level) {
                    // Add remaining weapon upgrade costs (always gold)
                    for (let i = building.wafi_weapon_level; i < building.wafi_max_weapon_level; i++) {
                        totalGold += 3000000 + (i * 1000000); // Estimated cost formula
                        totalTime += 432000; // 5 days per upgrade
                    }
                }

                // Handle regular building upgrades
                else if (building.wafi_level < building.wafi_max_level && building.wafi_level > 0) {
                    const { costToMax, timeToMax } = getCostAndTimeToMax(
                        building.wafi_name,
                        building.wafi_level,
                        building.wafi_max_level
                    );

                    // Assign cost to appropriate resource type
                    if (costType === 'gold') {
                        totalGold += costToMax;
                    } else if (costType === 'elixir') {
                        totalElixir += costToMax;
                    } else if (costType === 'dark elixir') {
                        totalDarkElixir += costToMax;
                    } else if (costType === 'gold/elixir') {
                        // For resources that can use either gold or elixir, add to gold for simplicity
                        totalGold += costToMax;
                    }

                    totalTime += timeToMax;
                }
            });
        });

        return {
            gold: totalGold,
            elixir: totalElixir,
            'dark elixir': totalDarkElixir,
            time: totalTime
        };
    }, [objectData]);

    // Check if empty
    const isEmpty = !objectData || Object.keys(objectData).length === 0;

    return (
        <div className="buildings-tab">
            {/* Header with title and progress */}
            <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold flex items-center gap-2">
                    <FontAwesomeIcon icon={icon} />
                    {tabTitle}
                </h2>

                <div className="flex items-center gap-3">
                    {!isEmpty && (
                        <div className="flex items-center">
                            Maxed Buildings:
                            <div className="ml-2 bg-gray-700 rounded-full h-1.5 w-24 overflow-hidden">
                                <div className="bg-blue-500 h-1.5 rounded-full" style={{ width: `${progressPercent}%` }}></div>
                            </div>
                            <span className="text-xs ml-2">{maxedBuildings}/{totalBuildings}</span>
                        </div>
                    )}

                    <Link
                        to={`/base/${id}/edit`}
                        className="bg-blue-600 hover:bg-blue-700 text-white py-1.5 px-3 rounded-lg flex items-center justify-center gap-1 text-sm transition-colors"
                    >
                        <FontAwesomeIcon icon={faEdit} />
                        <span>Edit All</span>
                    </Link>
                </div>
            </div>

            {isEmpty ? (
                <EmptyState id={id} tabTitle={tabTitle} />
            ) : (
                <div className="lg:grid lg:grid-cols-3 gap-4">
                    {/* Building Cards - Takes 2/3 of the space */}
                    <div className="lg:col-span-2 space-y-4">
                        {Object.keys(objectData).map((buildingName, typeIdx) => {
                            const buildings = objectData[buildingName];
                            const upgradesRemaining = buildings.reduce((total, building) =>
                                total + (building.wafi_max_level - building.wafi_level), 0);

                            // Get the highest level instance for the building icon
                            const highestLevelInstance = [...buildings].sort((a, b) => b.wafi_level - a.wafi_level)[0];
                            const buildingImageSrc = getBuildingImageUrl(buildingName, highestLevelInstance?.wafi_level || 1);

                            return (
                                <BuildingCard
                                    key={typeIdx}
                                    buildingName={buildingName}
                                    buildings={buildings}
                                    buildingImageSrc={buildingImageSrc}
                                    upgradesRemaining={upgradesRemaining}
                                    isCollapsed={collapsedBuildings[buildingName]}
                                    onToggleCollapse={() => toggleCollapse(buildingName)}
                                    onLevelChange={handleLevelChange}
                                    getBuildingImageUrl={getBuildingImageUrl}
                                />
                            );
                        })}
                    </div>

                    {/* Summary Panel - Takes 1/3 of the space */}
                    <div className="mt-4 lg:mt-0">
                        <SummaryPanel totals={calculateTotalUpgrades} />
                    </div>
                </div>
            )}
        </div>
    );
};

export default BuildingsTab;
