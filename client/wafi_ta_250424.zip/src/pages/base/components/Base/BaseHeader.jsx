import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
    faStar, faChevronRight, faCrown, faArrowUp, faExclamationTriangle, faCheckCircle, faSpinner, faTimes,
    faShield, faHome, faBuilding, faBomb, faDragon, faMoon, faFlask, faTruck, faHorse, faMeteor, faXmarksLines // Added icons for categories
} from '@fortawesome/free-solid-svg-icons';
import { baseAPI, objectAPI } from '@/lib/dbAPI';
import dataBuildings from '../../dataBuildings';
// Assuming dataTroops might be needed for max levels, though calculation uses processedTroopData
// import dataTroops from '../../dataTroops';

// Helper function to calculate percentage
const calculatePercentage = (current, max) => {
    if (max === 0) return 100; // Avoid division by zero if nothing is required
    return Math.min(100, Math.max(0, Math.round((current / max) * 100)));
};

const BaseHeader = ({ playerData, base, processedObjectData, processedTroopData, wallData }) => {
    const { id } = useParams();
    const [upgradeLoading, setUpgradeLoading] = useState(false);
    const [showUpgradeModal, setShowUpgradeModal] = useState(false);
    const [errorMessage, setErrorMessage] = useState('');
    const [validationResults, setValidationResults] = useState(null); // For upgrade eligibility (placement)
    // Expanded state for detailed progress percentages (levels)
    const [progressStats, setProgressStats] = useState({
        // Building Categories
        defenses: { current: 0, max: 0, percentage: 0 },
        resources: { current: 0, max: 0, percentage: 0 },
        army: { current: 0, max: 0, percentage: 0 },
        traps: { current: 0, max: 0, percentage: 0 },
        // Troop Categories
        troops: { current: 0, max: 0, percentage: 0 },
        darkTroops: { current: 0, max: 0, percentage: 0 },
        spells: { current: 0, max: 0, percentage: 0 },
        darkSpells: { current: 0, max: 0, percentage: 0 },
        sieges: { current: 0, max: 0, percentage: 0 },
        pets: { current: 0, max: 0, percentage: 0 },
        heroes: { current: 0, max: 0, percentage: 0 },
        heroEquipments: { current: 0, max: 0, percentage: 0 },
        // Walls
        walls: { current: 0, max: 0, percentage: 0 },
        // Upgrade Eligibility (based on placement, not levels)
        canUpgrade: false,
        maxTHReached: false,
        // Placement stats (for modal)
        placementBuildingsComplete: 0,
        placementWallsComplete: 0,
        placementWeaponComplete: false,
    });

    const urlAssets = import.meta.env.VITE_ASSETS_URL || 'http://localhost:3000/assets';
    const thLevel = base?.wafi_th_level || playerData?.townHallLevel || 1;
    
    // Format name for TH image URL
    const normalizedTHName = "town-hall";
    
    // Generate TH image URL
    const thImageUrl = `${urlAssets}/th/th-${thLevel}.png`;
    
    // Calculate progress and completion percentages
    useEffect(() => {
        if (processedObjectData && processedTroopData && wallData) {
            calculateDetailedProgress(); // Calculate level-based progress
            validateTownHallPlacement(); // Validate placement for upgrade eligibility
        }
    }, [processedObjectData, processedTroopData, wallData, base, thLevel]);

    // New function to calculate detailed level-based progress
    const calculateDetailedProgress = () => {
        const newProgress = {
            defenses: { current: 0, max: 0 }, resources: { current: 0, max: 0 },
            army: { current: 0, max: 0 }, traps: { current: 0, max: 0 },
            troops: { current: 0, max: 0 }, darkTroops: { current: 0, max: 0 },
            spells: { current: 0, max: 0 }, darkSpells: { current: 0, max: 0 },
            sieges: { current: 0, max: 0 }, pets: { current: 0, max: 0 },
            heroes: { current: 0, max: 0 }, heroEquipments: { current: 0, max: 0 },
            walls: { current: 0, max: 0 },
        };

        // 1. Calculate Building Progress (based on levels)
        if (processedObjectData) {
            Object.keys(processedObjectData).forEach(categoryKey => {
                const categoryName = categoryKey.toLowerCase(); // e.g., 'defenses'
                if (newProgress[categoryName]) {
                    Object.values(processedObjectData[categoryKey]).forEach(buildingGroup => {
                        buildingGroup.forEach(instance => {
                            // Special handling for Town Hall weapon level
                            if (instance.has_weapon && instance.wafi_name === "Town Hall") {
                                newProgress[categoryName].current += instance.wafi_weapon_level || 0;
                                newProgress[categoryName].max += instance.wafi_max_weapon_level || 5; // Assume max 5 if not defined
                            } else if (!instance.has_weapon) { // Regular buildings/traps etc.
                                newProgress[categoryName].current += instance.wafi_level || 0;
                                newProgress[categoryName].max += instance.wafi_max_level || 1;
                            }
                        });
                    });
                }
            });
        }

        // 2. Calculate Troop Progress (based on levels)
        if (processedTroopData) {
            Object.keys(processedTroopData).forEach(categoryKey => {
                // Map processedTroopData keys (camelCase) to progressStats keys (lowercase)
                let progressKey = categoryKey.toLowerCase();
                if (categoryKey === 'DarkTroops') progressKey = 'darkTroops';
                if (categoryKey === 'DarkSpells') progressKey = 'darkSpells';
                if (categoryKey === 'HeroEquipments') progressKey = 'heroEquipments';

                if (newProgress[progressKey]) {
                    processedTroopData[categoryKey].forEach(troop => {
                        newProgress[progressKey].current += troop.currentLevel || 0;
                        newProgress[progressKey].max += troop.availableMaxLevel || 1;
                    });
                }
            });
        }

        // 3. Calculate Wall Progress (based on levels/count)
        if (wallData && wallData.instances) {
            // Max progress is total pieces * max level for TH
            newProgress.walls.max = (wallData.totalWallPieces || 0) * (wallData.maxWallLevel || 1);
            wallData.instances.forEach(wallInstance => {
                // Current progress is sum of (count * level) for each level
                newProgress.walls.current += (wallInstance.wafi_wall_count || 0) * (wallInstance.wafi_level || 0);
            });
        }

        // Calculate percentages for each category
        Object.keys(newProgress).forEach(key => {
            newProgress[key].percentage = calculatePercentage(newProgress[key].current, newProgress[key].max);
        });

        // Update only the progress parts of the state
        setProgressStats(prev => ({
            ...prev,
            defenses: newProgress.defenses, resources: newProgress.resources,
            army: newProgress.army, traps: newProgress.traps,
            troops: newProgress.troops, darkTroops: newProgress.darkTroops,
            spells: newProgress.spells, darkSpells: newProgress.darkSpells,
            sieges: newProgress.sieges, pets: newProgress.pets,
            heroes: newProgress.heroes, heroEquipments: newProgress.heroEquipments,
            walls: newProgress.walls,
        }));
    };


    // Renamed: Validate if Town Hall *placement* allows upgrade
    const validateTownHallPlacement = () => {
        // Can't upgrade past TH15 (or whatever max TH is)
        if (thLevel >= 15) {
             setProgressStats(prev => ({
                ...prev,
                canUpgrade: false,
                maxTHReached: true,
                placementBuildingsComplete: 100, // Assume 100% placed if max TH
                placementWallsComplete: 100,
                placementWeaponComplete: true,
            }));
            return;
        }

        // Reset error message
        setErrorMessage('');

        // Get required building counts for current TH level
        const requiredBuildings = {};
        const buildingCounts = {};
        
        // Get building requirements from dataBuildings
        dataBuildings.forEach(building => {
            // Find availability at the current TH level
            const availableInfo = building.lvls
                .sort((a, b) => b.th - a.th)
                .find(level => level.th <= thLevel);
                
            if (availableInfo && availableInfo.n > 0) {
                requiredBuildings[building.name] = availableInfo.n;
                
                // Count actual buildings from processed data
                if (processedObjectData) {
                    const categoryForBuilding = Object.keys(processedObjectData).find(category => 
                        processedObjectData[category][building.name]);
                        
                    if (categoryForBuilding) {
                        const placedBuildingsList = processedObjectData[categoryForBuilding][building.name] || [];
                        // Count only buildings that have been placed (level > 0 or exist in DB)
                        buildingCounts[building.name] = placedBuildingsList.filter(b => b.wafi_level > 0 || b.exists_in_db).length;
                    } else {
                        buildingCounts[building.name] = 0;
                    }
                }
            }
        });

        // Check for Town Hall weapon completion (for TH12-15)
        let placementWeaponComplete = true;
        if (thLevel >= 12 && thLevel <= 14) {
            // Find Town Hall in defense category
            const townHall = processedObjectData?.Defenses?.["Town Hall"]?.[0];
            // Check if the *database* object for TH weapon exists and is level 5
             const townHallWeaponObject = base?.dbObjectData?.find(obj => obj.wafi_name === "Town Hall Weapon");
             placementWeaponComplete = townHallWeaponObject ? townHallWeaponObject.wafi_level >= 5 : false;
             // Fallback check if processedObjectData has it (less reliable for placement check)
             if (!townHallWeaponObject && townHall && townHall.has_weapon) {
                 placementWeaponComplete = townHall.wafi_weapon_level >= 5;
             }
        }

        // Check wall requirements
        const wallsPlaced = wallData?.currentTotalCount || 0;
        const wallsRequired = wallData?.totalWallPieces || 0;
        const placementWallsComplete = wallsPlaced >= wallsRequired;

        // Check building counts match requirements
        const missingBuildings = [];
        let totalRequiredBuildings = 0;
        let totalPlacedBuildings = 0;
        
        Object.keys(requiredBuildings).forEach(buildingName => {
            if (buildingName !== 'Wall') {  // Walls are handled separately
                const required = requiredBuildings[buildingName];
                const actual = buildingCounts[buildingName] || 0;
                totalRequiredBuildings += required;
                totalPlacedBuildings += Math.min(actual, required); // Count only up to the required amount
                
                if (actual < required) {
                    missingBuildings.push({
                        name: buildingName,
                        required,
                        actual,
                        missing: required - actual
                    });
                }
            }
        });

        // Calculate percentages
        const placementBuildingsCompletePercent = totalRequiredBuildings > 0 
            ? Math.round((totalPlacedBuildings / totalRequiredBuildings) * 100)
            : 0;
            
        const placementWallsCompletePercent = wallsRequired > 0
            ? Math.round((Math.min(wallsPlaced, wallsRequired) / wallsRequired) * 100)
            : 100;

        // Determine if upgrade is allowed
        const canUpgrade = missingBuildings.length === 0 && placementWallsComplete && placementWeaponComplete;

        setValidationResults({
            missingBuildings,
            wallsComplete: placementWallsComplete,
            weaponComplete: placementWeaponComplete
        });
        
        // Update only the placement/eligibility parts of the state
        setProgressStats(prev => ({
            ...prev,
            canUpgrade,
            maxTHReached: thLevel >= 15,
            placementBuildingsComplete: placementBuildingsCompletePercent,
            placementWallsComplete: placementWallsCompletePercent,
            placementWeaponComplete: placementWeaponComplete,
        }));
    };

    // Function to handle TH upgrade
    const handleTownHallUpgrade = async () => {
        // Use progressStats.canUpgrade which is based on placement validation
        if (!progressStats.canUpgrade) {
            setErrorMessage('Cannot upgrade Town Hall. Complete all placement requirements first.');
            return;
        }

        setUpgradeLoading(true);
        try {
            // 1. Update the TH level in the base table
            const newThLevel = thLevel + 1;
            await baseAPI.updateBase(base.wafi_id, {
                tag: base.wafi_tag,
                name: base.wafi_name,
                thLevel: newThLevel
            });

            // 2. Update the Town Hall object in the objects table
            const townHallObj = processedObjectData?.Defenses?.["Town Hall"]?.[0];
            if (townHallObj && townHallObj.wafi_id) {
                await objectAPI.updateObjectLevel(townHallObj.wafi_id, newThLevel);
            } else {
                // Create Town Hall object if it doesn't exist
                await objectAPI.createOrUpdateObjects(base.wafi_id, [{
                    name: "Town Hall",
                    level: newThLevel
                }]);
            }

            // 3. For TH12+, reset weapon level if moving to a new weapon-enabled TH
            if (newThLevel === 12 || newThLevel === 13 || newThLevel === 14 || newThLevel === 15) {
                await objectAPI.createOrUpdateObjects(base.wafi_id, [{
                    name: "Town Hall Weapon",
                    level: 0  // Reset weapon level for the new TH
                }]);
            }

            // Reload the page to show the upgraded TH
            window.location.reload();
        } catch (error) {
            console.error('Failed to upgrade Town Hall:', error);
            setErrorMessage('Failed to upgrade Town Hall. Please try again.');
        } finally {
            setUpgradeLoading(false);
            setShowUpgradeModal(false);
        }
    };

    // Town Hall Upgrade Modal - Updated to use placement stats
    const UpgradeModal = () => (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[60] p-4"> {/* Added background overlay and higher z-index */}
            <div className="bg-gray-800 rounded-lg p-6 max-w-md w-full border border-white/20 shadow-xl"> {/* Changed background */}
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-bold text-white">Upgrade Town Hall</h3>
                    <button
                        onClick={() => setShowUpgradeModal(false)}
                        className="text-white/70 hover:text-white"
                    >
                        <FontAwesomeIcon icon={faTimes} />
                    </button>
                </div>

                {errorMessage && (
                    <div className="bg-red-500/20 border border-red-500 rounded p-3 mb-4 text-white text-sm">
                        {errorMessage}
                    </div>
                )}

                <div className="space-y-4 mb-6">
                    <p className="text-white/80">
                        Upgrading from TH {thLevel} to TH {thLevel + 1}. Before upgrading, make sure:
                    </p>

                    <div className="space-y-2">
                        {/* Building Placement Requirement */}
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                                <FontAwesomeIcon
                                    icon={validationResults?.missingBuildings.length === 0 ? faCheckCircle : faExclamationTriangle}
                                    className={validationResults?.missingBuildings.length === 0 ? "text-green-500" : "text-yellow-500"}
                                />
                                <span>All buildings placed</span>
                            </div>
                            <span className={`${progressStats.placementBuildingsComplete === 100 ? "text-green-400" : "text-yellow-400"}`}>
                                {progressStats.placementBuildingsComplete}%
                            </span>
                        </div>

                        {/* Wall Placement Requirement */}
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                                <FontAwesomeIcon
                                    icon={validationResults?.wallsComplete ? faCheckCircle : faExclamationTriangle}
                                    className={validationResults?.wallsComplete ? "text-green-500" : "text-yellow-500"}
                                />
                                <span>All walls placed</span>
                            </div>
                            <span className={`${progressStats.placementWallsComplete === 100 ? "text-green-400" : "text-yellow-400"}`}>
                                {progressStats.placementWallsComplete}%
                            </span>
                        </div>

                        {/* Weapon Requirement (TH12-14) */}
                        {thLevel >= 12 && thLevel <= 14 && (
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                    <FontAwesomeIcon
                                        icon={validationResults?.weaponComplete ? faCheckCircle : faExclamationTriangle}
                                        className={validationResults?.weaponComplete ? "text-green-500" : "text-yellow-500"}
                                    />
                                    <span>Giga weapon maxed (Level 5)</span>
                                </div>
                                <span className={validationResults?.weaponComplete ? "text-green-400" : "text-yellow-400"}>
                                    {validationResults?.weaponComplete ? "Complete" : "Incomplete"}
                                </span>
                            </div>
                        )}
                    </div>

                    {/* Missing Buildings List */}
                    {validationResults?.missingBuildings.length > 0 && (
                        <div className="mt-4 bg-white/5 p-3 rounded-lg text-sm max-h-40 overflow-y-auto">
                            <p className="font-semibold mb-2">Missing buildings:</p>
                            <ul className="space-y-1">
                                {validationResults.missingBuildings.map((building, idx) => (
                                    <li key={idx} className="flex justify-between">
                                        <span>{building.name}</span>
                                        <span className="text-yellow-400">{building.actual}/{building.required}</span>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    )}
                </div>

                <div className="flex justify-end gap-3">
                    <button
                        onClick={() => setShowUpgradeModal(false)}
                        className="px-4 py-2 rounded-lg bg-gray-700 hover:bg-gray-600 text-white transition-colors"
                    >
                        Cancel
                    </button>
                    <button
                        onClick={handleTownHallUpgrade}
                        disabled={!progressStats.canUpgrade || upgradeLoading}
                        className={`px-4 py-2 rounded-lg flex items-center gap-2 transition-colors ${
                            progressStats.canUpgrade
                                ? "bg-yellow-500 hover:bg-yellow-600 text-white"
                                : "bg-gray-700 text-white/50 cursor-not-allowed"
                        }`}
                    >
                        {upgradeLoading ? (
                            <>
                                <FontAwesomeIcon icon={faSpinner} spin />
                                <span>Upgrading...</span>
                            </>
                        ) : (
                            <>
                                <FontAwesomeIcon icon={faArrowUp} />
                                <span>Upgrade</span>
                            </>
                        )}
                    </button>
                </div>
            </div>
        </div>
    );

    // Helper component for rendering progress bars
    const ProgressBar = ({ label, percentage, icon }) => (
        <div>
            <div className="flex justify-between items-center text-xs mb-1">
                <span className="flex items-center gap-1.5">
                    {icon && <FontAwesomeIcon icon={icon} className="w-3 h-3 text-white/60" />}
                    {label}
                </span>
                <span>{percentage}%</span>
            </div>
            <div className="h-1.5 bg-gray-700 rounded-full w-full overflow-hidden"> {/* Added overflow-hidden */}
                <div
                    className="h-1.5 bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full transition-all duration-300 ease-out" // Added gradient and transition
                    style={{ width: `${percentage}%` }}
                ></div>
            </div>
        </div>
    );


    return (
        <div className="bg-white/10 rounded-lg p-4 mb-6 border border-white/10">
            <div className="flex flex-col md:flex-row md:items-start gap-4"> {/* Changed items-center to items-start */}
                {/* TH Image */}
                <div className="relative min-w-20 min-h-20">
                    <img src={thImageUrl} alt={`Town Hall ${thLevel}`} className="w-20 h-20" />
                    <div className="absolute -bottom-1 -right-1 bg-yellow-500 text-gray-900 font-bold w-6 h-6 rounded-full flex items-center justify-center text-xs border-2 border-gray-800"> {/* Added border */}
                        {thLevel}
                    </div>
                </div>

                {/* Player Info */}
                <div className="flex-grow">
                    <h1 className="text-xl font-bold flex items-center gap-2">
                        {playerData?.name || base?.wafi_name || "Base"}
                        {/* Show verification icon if verified */}
                        {playerData?.verificationStatus === "verified" && (
                            <FontAwesomeIcon icon={faStar} className="text-yellow-400" />
                        )}
                    </h1>
                    <div className="text-white/70 text-sm mt-1">
                        <span>{base?.wafi_tag || playerData?.tag || id}</span>
                    </div>

                    {/* Updated Progress Bars Section */}
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-x-4 gap-y-3 mt-3">
                        {/* Building Categories */}
                        <ProgressBar label="Defenses" percentage={progressStats.defenses.percentage} icon={faShield} />
                        <ProgressBar label="Resources" percentage={progressStats.resources.percentage} icon={faHome} />
                        <ProgressBar label="Army" percentage={progressStats.army.percentage} icon={faBuilding} />
                        {thLevel >= 3 && <ProgressBar label="Traps" percentage={progressStats.traps.percentage} icon={faBomb} />} {/* Conditionally show Traps */}

                        {/* Troop Categories */}
                        <ProgressBar label="Troops" percentage={progressStats.troops.percentage} icon={faDragon} />
                        {thLevel >= 7 && <ProgressBar label="Dark Troops" percentage={progressStats.darkTroops.percentage} icon={faMoon} />}
                        <ProgressBar label="Spells" percentage={progressStats.spells.percentage} icon={faFlask} />
                        {thLevel >= 8 && <ProgressBar label="Dark Spells" percentage={progressStats.darkSpells.percentage} icon={faMoon} />} {/* TH8 for Dark Spells */}
                        {thLevel >= 12 && <ProgressBar label="Sieges" percentage={progressStats.sieges.percentage} icon={faTruck} />}
                        {thLevel >= 14 && <ProgressBar label="Pets" percentage={progressStats.pets.percentage} icon={faHorse} />}
                        {thLevel >= 7 && <ProgressBar label="Heroes" percentage={progressStats.heroes.percentage} icon={faCrown} />}
                        {thLevel >= 8 && <ProgressBar label="Equipment" percentage={progressStats.heroEquipments.percentage} icon={faMeteor} />} {/* TH8 for Blacksmith */}

                        {/* Walls */}
                        <ProgressBar label="Walls" percentage={progressStats.walls.percentage} icon={faXmarksLines} />
                    </div>
                </div>

                {/* Upgrade Button */}
                <div className="flex-shrink-0 mt-2 md:mt-0"> {/* Added flex-shrink-0 */}
                    <button
                        onClick={() => setShowUpgradeModal(true)}
                        disabled={progressStats.maxTHReached} // Use progressStats
                        className={`px-4 py-2 rounded-lg flex items-center gap-2 transition-colors w-full md:w-auto justify-center ${ // Make full width on mobile
                            progressStats.maxTHReached
                                ? "bg-gray-700 text-white/50 cursor-not-allowed"
                                : progressStats.canUpgrade
                                    ? "bg-yellow-500 hover:bg-yellow-600 text-white shadow-md shadow-yellow-500/30" // Added shadow
                                    : "bg-blue-600 hover:bg-blue-700 text-white"
                        }`}
                        title={progressStats.maxTHReached ? "Maximum Town Hall level reached" : ""}
                    >
                        <FontAwesomeIcon icon={faCrown} />
                        <span>
                            {progressStats.maxTHReached
                                ? "Max TH"
                                : `Upgrade to TH ${thLevel + 1}`}
                        </span>
                        {!progressStats.maxTHReached && <FontAwesomeIcon icon={faChevronRight} className="ml-1 text-xs" />} {/* Hide arrow if max TH */}
                    </button>
                </div>
            </div>

            {/* Show upgrade modal when requested */}
            {showUpgradeModal && <UpgradeModal />}
        </div>
    );
};

export default BaseHeader;
