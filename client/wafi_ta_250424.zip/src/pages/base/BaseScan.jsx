import React, { useState, useRef, useEffect, use } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faCloudUploadAlt,
  faSpinner,
  faExclamationTriangle,
  faInfoCircle,
  faHammer,
  faArrowLeft,
  faCamera,
  faLink,
  faSearch,
} from "@fortawesome/free-solid-svg-icons";
import PredictionAPI from "@/lib/predictionAPI";

const BaseScan = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const baseData = location.state?.baseData;

  const [image, setImage] = useState(null);
  const [preview, setPreview] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [results, setResults] = useState(null);
  const [error, setError] = useState(null);
  const fileInputRef = useRef(null);
  // useEffect(() => {
  //   if (!baseData) {
  //     navigate('/base');
  //   }
  // }, [baseData, navigate]);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file && file.type.startsWith("image/")) {
      setImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result);
      };
      reader.readAsDataURL(file);
      setError(null);
    } else if (file) {
      setError("File yang dipilih bukan gambar. Silahkan pilih file gambar.");
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    e.currentTarget.classList.add("border-yellow-400");
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    e.currentTarget.classList.remove("border-yellow-400");
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    e.currentTarget.classList.remove("border-yellow-400");

    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith("image/")) {
      setImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result);
      };
      reader.readAsDataURL(file);
      setError(null);
    } else if (file) {
      setError("File yang dipilih bukan gambar. Silahkan pilih file gambar.");
    }
  };

  const handleSubmit = async () => {
    if (!image) {
      setError("Silahkan pilih gambar terlebih dahulu");
      return;
    }

    setIsProcessing(true);
    setError(null);

    const formData = new FormData();
    formData.append('image', image);
    const response = await PredictionAPI.predict(formData).then((res) => res).catch((err) => {
      setError(err.response?.data?.error || "Terjadi kesalahan saat memproses gambar");
      return err;
    }).finally(() => setIsProcessing(false));
    setResults(response)
    console.log(response);
  };
  const handleSeeResults = () => {
    navigate('/track/result', {
      state: {
        results: results,
      }
    })
  }
  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-3xl md:text-4xl font-bold text-white">
          Update Your Base Progress
        </h1>
        <button
          onClick={() => navigate('/')}
          className="text-white/80 hover:text-white flex items-center"
        >
          <FontAwesomeIcon icon={faArrowLeft} className="mr-2" />
          Back to Search
        </button>
      </div>

      {baseData && (
        <div className="mb-6 bg-white/10 backdrop-blur-md rounded-lg p-4 border border-white/20 text-white">
          <div className="flex items-center">
            <div className="mr-3">
              <img
                src={`${import.meta.env.VITE_ASSETS_URL}/th/th-${baseData.wafi_th_level}.png`}
                alt={`Clash of clash TH-${baseData.wafi_th_level}`}
                className="w-10 h-10"
              />

            </div>
            <div>
              <h2 className="font-bold text-xl">{baseData.wafi_name}</h2>
              <p className="text-sm text-white/70">#{baseData.wafi_tag} • TH{baseData.wafi_th_level}</p>
            </div>
          </div>
        </div>
      )}

      <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border-2 border-white/20 mb-8">
        <h2 className="text-xl font-bold text-white mb-4 flex items-center">
          <FontAwesomeIcon icon={faInfoCircle} className="mr-2 text-yellow-400" />
          Cara Menggunakan Layout Base Khusus
        </h2>

        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <p className="text-white/90 mb-3">
              Untuk hasil terbaik, gunakan layout base khusus yang kami sediakan.
              Ini akan memudahkan sistem kami mendeteksi bangunan Anda dengan akurat.
            </p>

            <ol className="list-decimal list-inside space-y-2 text-white/80 mb-4">
              <li>Klik tombol "Gunakan Layout Base" di samping</li>
              <li>Buka aplikasi Clash of Clans</li>
              <li>Ikuti petunjuk untuk mengimpor layout</li>
              <li>Screenshot base Anda dalam mode edit layout</li>
              <li>Upload screenshot pada halaman ini</li>
            </ol>

            {baseData && (
              <a
                href={`clash://layout?id=${baseData.tag}-layout`}
                className="bg-yellow-400 hover:bg-yellow-500 text-gray-900 py-2 px-4 rounded-lg font-medium inline-flex items-center"
              >
                <FontAwesomeIcon icon={faLink} className="mr-2" />
                Gunakan Layout Base
              </a>
            )}
          </div>

          <div className="flex flex-col">
            <div className="flex items-center mb-3">
              <FontAwesomeIcon icon={faCamera} className="text-yellow-400 mr-2" />
              <h3 className="text-lg font-semibold text-white">Contoh Screenshot Yang Benar</h3>
            </div>

            <div className="border-2 border-dashed border-white/30 rounded-lg p-5 flex-1 flex items-center justify-center">
              <img
                src="example-ss-coc-layout.jpg"
                alt="Example Screenshot"
                className="rounded w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="upload-section">
          <h2 className="text-xl font-bold text-white mb-4">Upload Screenshot</h2>
          <div
            className={`border-2 border-dashed ${error ? "border-red-500" : "border-white/30"
              } rounded-xl p-8 text-center cursor-pointer transition-all hover:border-yellow-400 mb-6`}
            onClick={() => fileInputRef.current.click()}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            {preview ? (
              <div>
                <img
                  src={preview}
                  alt="Preview"
                  className="max-h-[300px] mx-auto rounded-lg mb-4"
                />
                <p className="text-white/80">
                  Click or drag to choose a different image
                </p>
              </div>
            ) : (
              <div className="py-8">
                <FontAwesomeIcon
                  icon={faCloudUploadAlt}
                  className="text-5xl text-white/60 mb-4"
                />
                <h3 className="text-xl font-bold text-white mb-2">
                  Upload Screenshot
                </h3>
                <p className="text-white/80 mb-4">
                  Drag & drop or click to select an image
                </p>
                <p className="text-white/60 text-sm">
                  Supported formats: JPG, PNG, WEBP (Max 10MB)
                </p>
              </div>
            )}
          </div>

          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            className="hidden"
            accept="image/*"
          />

          {error && (
            <div className="bg-red-500/20 text-red-400 p-4 rounded-lg mb-6 flex items-center">
              <FontAwesomeIcon
                icon={faExclamationTriangle}
                className="mr-2"
              />
              <span>{error}</span>
            </div>
          )}

          <button
            onClick={handleSubmit}
            disabled={!image || isProcessing}
            className={`w-full py-3 px-6 rounded-lg font-medium transition ${!image || isProcessing
              ? "bg-white/30 cursor-not-allowed"
              : "bg-yellow-400 hover:bg-yellow-500 text-gray-900"
              }`}
          >
            {isProcessing ? (
              <>
                <FontAwesomeIcon icon={faSpinner} spin className="mr-2" />
                Processing...
              </>
            ) : (
              <>
                <FontAwesomeIcon icon={faSearch} className="mr-2" />
                Analyze Base
              </>
            )}
          </button>
        </div>
        <div className="results-section">
          {isProcessing ? (
            <div className="bg-white/10 backdrop-blur-md rounded-xl p-8 border-2 border-white/20 flex flex-col items-center justify-center min-h-[400px]">
              <FontAwesomeIcon
                icon={faSpinner}
                spin
                className="text-5xl text-yellow-400 mb-4"
              />
              <h3 className="text-xl font-bold text-white mb-2">
                Analyzing Your Base
              </h3>
              <p className="text-white/80 text-center">
                Please wait while our AI detects buildings and calculates upgrade times...
              </p>
            </div>
          ) : results ? (
            <div className="bg-white/10 backdrop-blur-md rounded-xl border-2 border-white/20 overflow-hidden">
              <div className="bg-yellow-400 p-4">
                <h3 className="text-xl font-bold text-gray-900">Analysis Results</h3>
              </div>

              <div className="p-6">

                <div className="">
                  <div
                    className="bg-white/10 p-4 rounded-lg mb-4 flex items-center"
                  >
                    <h4 className="text-white font-semibold">
                      Number of Buildings Detected: <span className="text-lg">{results.length}</span>
                    </h4>
                  </div>
                  <button onClick={handleSeeResults} className="text-black bg-yellow-400 p-3 w-full rounded-md font-semibold hover:bg-yellow-500 transition-all">See Results</button>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white/10 backdrop-blur-md rounded-xl p-8 border-2 border-white/20 flex flex-col items-center justify-center min-h-[400px]">
              <FontAwesomeIcon
                icon={faHammer}
                className="text-5xl text-yellow-400 mb-4"
              />
              <h3 className="text-xl font-bold text-white mb-2">
                Ready to Analyze Your Base
              </h3>
              <p className="text-white/80 text-center mb-4">
                Upload a screenshot of your village to get detailed upgrade information
              </p>
              <div className="flex items-center text-white/60 text-sm">
                <FontAwesomeIcon icon={faInfoCircle} className="mr-2" />
                <span>Results will appear here after analysis</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BaseScan;