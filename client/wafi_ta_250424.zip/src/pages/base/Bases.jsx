import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import BaseCard from "./components/Bases/BaseCard";
import { userAPI, baseAPI } from "@/lib/dbAPI";
import { useAuth } from "@/hooks/useAuth";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPlus } from "@fortawesome/free-solid-svg-icons";

const Bases = () => {
    const [playerBases, setPlayerBases] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);
    const { user } = useAuth();
    const navigate = useNavigate();

    useEffect(() => {
        const fetchBases = async () => {
            try {
                const bases = await baseAPI.getUserBases(user.id);
                setPlayerBases(bases);
                console.log("Fetched bases:", bases);
            } catch (err) {
                console.error("Error fetching bases:", err);
                setError("Failed to load bases. Please try again later.");
            } finally {
                setIsLoading(false);
            }
        };

        fetchBases();
    }, []);

    // const handleDeleteBase = async (baseId) => {
    //     try {
    //         const userData = await userAPI.getUser(user.id);
    //         await baseAPI.deleteBase(baseId, userData.wafi_id);

    //         // Update the local state to remove the deleted base
    //         setPlayerBases(prevBases =>
    //             prevBases.filter(base => base.wafi_id !== baseId)
    //         );
    //     } catch (err) {
    //         console.error("Error deleting base:", err);
    //         setError("Failed to delete base. Please try again.");
    //     }
    // };

    const handleAddNewBase = () => {
        navigate('/');
    };

    if (isLoading) {
        return (
            <div className="flex justify-center items-center h-40">
                <div className="animate-spin h-8 w-8 border-t-2 border-b-2 border-white rounded-full"></div>
            </div>
        );
    }

    if (error) {
        return (
            <div className="bg-red-500/20 border border-red-500/50 rounded-lg p-4 text-white text-center">
                <p>{error}</p>
            </div>
        );
    }

    return (
        <>
            {/* Add New Base button */}
            <div className="mb-6 flex justify-between items-center">
                <h1 className="text-2xl font-bold text-white">My Bases</h1>
                <button
                    onClick={handleAddNewBase}
                    className="bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-lg flex items-center gap-2 transition-colors"
                >
                    <FontAwesomeIcon icon={faPlus} />
                    <span>Add New Base</span>
                </button>
            </div>

            {playerBases.length === 0 ? (
                <div className="bg-white/10 backdrop-blur-md rounded-lg p-8 border border-white/20 text-center">
                    <p className="text-white/70 mb-4">Belum ada base yang ditambahkan</p>
                    <button
                        onClick={handleAddNewBase}
                        className="bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-lg flex items-center gap-2 mx-auto transition-colors"
                    >
                        <FontAwesomeIcon icon={faPlus} />
                        <span>Add New Base</span>
                    </button>
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {playerBases.map((base) => (
                        <BaseCard
                            key={base.wafi_tag}
                            base={base}
                            onDelete={() => handleDeleteBase(base.wafi_id)}
                        />
                    ))}
                </div>
            )}
        </>
    );
};

export default Bases;
