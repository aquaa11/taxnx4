import { useLocation, useNavigate, useParams } from 'react-router-dom';
import React, { useState, useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faExclamationTriangle, faSpinner, faSave, faArrowLeft,
  faShield, faBomb, faHome, faBuilding, faDragon, faMoon,
  faFlask, faTruck, faHorse, faCrown, faMeteor, faXmarksLines,
  faPlus, faMinus, faUnlock // Add faUnlock icon
} from "@fortawesome/free-solid-svg-icons";
import { objectAPI, baseAPI } from "@/lib/dbAPI";
import dataBuildings from './dataBuildings';
import dataTroops from './dataTroops';

// Import components
import LoadingState from './components/BaseEdit/LoadingState';
import ErrorState from './components/BaseEdit/ErrorState';

const BaseEdit = () => {
  const { id } = useParams();
  const tag = id.startsWith('#') ? id : `#${id}`;
  const navigate = useNavigate();
  const location = useLocation();
  const [base, setBase] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState("Defenses");
  const [changes, setChanges] = useState({});
  const [isSaving, setIsSaving] = useState(false);
  const [playerData, setPlayerData] = useState(null);
  const [dbObjectData, setDbObjectData] = useState([]);

  // State for buildings
  const [availableBuildings, setAvailableBuildings] = useState({
    Defenses: [],
    Traps: [],
    Resources: [],
    Army: []
  });

  // New state for troops
  const [availableTroops, setAvailableTroops] = useState({
    Troops: [],
    DarkTroops: [],
    Spells: [],
    DarkSpells: [],
    Sieges: [],
    Pets: [],
    Heroes: [],
    HeroEquipments: []
  });

  // Define all possible tabs
  const allTabs = {
    // Building tabs
    'Defenses': { icon: faShield, type: 'building', minTH: 1 },
    'Traps': { icon: faBomb, type: 'building', minTH: 3 },
    'Resources': { icon: faHome, type: 'building', minTH: 1 },
    'Army': { icon: faBuilding, type: 'building', minTH: 1 },
    // Troop tabs
    'Troops': { icon: faDragon, type: 'troop', minTH: 1 },
    'DarkTroops': { icon: faMoon, type: 'troop', minTH: 7 },
    'Spells': { icon: faFlask, type: 'troop', minTH: 1 },
    'DarkSpells': { icon: faMoon, type: 'troop', minTH: 7 },
    'Sieges': { icon: faTruck, type: 'troop', minTH: 12 },
    'Pets': { icon: faHorse, type: 'troop', minTH: 14 },
    'Heroes': { icon: faCrown, type: 'troop', minTH: 7 },
    'HeroEquipments': { icon: faMeteor, type: 'troop', minTH: 7 },
    'Walls': { icon: faXmarksLines, type: 'building', minTH: 2 },
  };

  // Fetch base data and object data from database
  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        // Get base data
        const baseData = await baseAPI.getBaseByTag(tag);
        setBase(baseData);

        // If playerData was passed through state, use it
        if (location.state?.playerData) {
          setPlayerData(location.state.playerData);
        } else {
          // Fallback to getting player data from base TH level
          setPlayerData({
            townHallLevel: baseData.wafi_th_level || 15
          });
        }

        // Fetch object data if base exists
        if (baseData && baseData.wafi_id) {
          try {
            const objectsData = await objectAPI.getObject(baseData.wafi_id);
            setDbObjectData(objectsData);
          } catch (objErr) {
            console.error("Error fetching object data:", objErr);
            // Continue even if object data fetch fails
            setDbObjectData([]);
          }
        }

        setIsLoading(false);
      } catch (err) {
        console.error("Error fetching data:", err);
        setError("Failed to load base data");
        setIsLoading(false);
      }
    };

    fetchData();
  }, [tag, location.state]);

  // Process data from dataBuildings when playerData is available
  useEffect(() => {
    if (playerData && playerData.townHallLevel) {
      const thLevel = playerData.townHallLevel;

      // Group buildings by category
      const groupedByCategory = {
        Defenses: [],
        Traps: [],
        Resources: [],
        Army: []
      };

      // Process each building from dataBuildings
      dataBuildings.forEach((building, typeIndex) => {
        // Find the highest level available for this TH level
        const maxLevelForTh = building.lvls
          .filter(level => level.th <= thLevel)
          .sort((a, b) => b.lv - a.lv)[0];
        // Find the highest level available for the previous TH level
        const prevThLevel = thLevel > 1 ? thLevel - 1 : 1;
        const maxLevelForPrevTh = building.lvls
          .filter(level => level.th <= prevThLevel)
          .sort((a, b) => b.lv - a.lv)[0];

        const availableInfo = building.lvls
          .sort((a, b) => b.th - a.th)
          .find(level => level.th <= thLevel);
        const availableCount = availableInfo?.n || 0;
        if (availableCount <= 0) return;
        const listBuildingType = {
          Defenses: ["Cannon", "Archer Tower", "Mortar", "Air Defense", "Wizard Tower", "Air Sweeper", "Hidden Tesla", "Bomb Tower", "X-Bow", "Inferno Tower", "Eagle Artillery", "Scattershot", "Builder's Hut", "Spell Tower", "Monolith", "Multi-Archer Tower", "Ricochet Cannon", "Multi-Gear Tower", "Firespitter"],
          Traps: ["Bomb", "Spring Trap", "Giant Bomb", "Air Bomb", "Seeking Air Mine", "Skeleton Trap", "Tornado Trap", "Giga Bomb"],
          Resources: ["Gold Mine", "Elixir Collector", "Dark Elixir Drill", "Gold Storage", "Elixir Storage", "Dark Elixir Storage", "Helper Hut", "Town Hall"],
          Army: ["Army Camp", "Barracks", "Dark Barracks", "Clan Castle", "Spell Factory", "Dark Spell Factory", "Lab", "Hero Hall", "Blacksmith", "Workshop", "Pet House"]
        };

        let category = "Defenses";
        if (listBuildingType.Defenses.some(defense => building.name.includes(defense))) {
          category = "Defenses";
        } else if (listBuildingType.Traps.some(trap => building.name.includes(trap))) {
          category = "Traps";
        } else if (listBuildingType.Resources.some(resource => building.name.includes(resource))) {
          category = "Resources";
        } else if (listBuildingType.Army.some(armyBuilding => building.name.includes(armyBuilding))) {
          category = "Army";
        }

        // Find database objects that match this building name
        const dbObjects = dbObjectData.filter(obj => obj.wafi_name === building.name);

        // Create individual building instances
        const buildingInstances = [];
        for (let i = 0; i < availableCount; i++) {
          // Check if this instance exists in the database
          const dbObject = i < dbObjects.length ? dbObjects[i] : null;
          buildingInstances.push({
            instance_id: dbObject ? `db_${dbObject.wafi_id}` : `building_${typeIndex}_${i}`,
            building_id: `building_${typeIndex}`,
            wafi_type_id: dbObject ? dbObject.wafi_type_id : typeIndex,
            wafi_name: building.name,
            wafi_max_level: maxLevelForTh ? maxLevelForTh.lv : 1,
            wafi_prev_th_max_level: maxLevelForPrevTh ? maxLevelForPrevTh.lv : 1,
            wafi_level: dbObject ? dbObject.wafi_level : 0, // Use DB level or 0 if not in DB
            wafi_instance: i + 1,
            wafi_total_instances: availableCount,
            wafi_category_name: category,
            wafi_db_id: dbObject ? dbObject.wafi_id : null, // Store DB ID for updates
            exists_in_db: !!dbObject // Flag if exists in database
          });
        }

        // Group buildings by type for display
        const buildingGroup = {
          group_id: `group_${typeIndex}`,
          wafi_type_id: typeIndex,
          wafi_name: building.name,
          wafi_max_level: maxLevelForTh ? maxLevelForTh.lv : 1,
          wafi_prev_th_max_level: maxLevelForPrevTh ? maxLevelForPrevTh.lv : 1,
          wafi_count: availableCount,
          wafi_db_count: dbObjects.length, // Count how many exist in DB
          wafi_category_name: category,
          instances: buildingInstances
        };

        // Add to the appropriate category
        groupedByCategory[category].push(buildingGroup);
      });

      // Sort buildings within each category by wafi_type_id
      Object.keys(groupedByCategory).forEach(category => {
        groupedByCategory[category].sort((a, b) => a.wafi_type_id - b.wafi_type_id);
      });

      setAvailableBuildings(groupedByCategory);

      // Extract building levels to update base state
      const labLevel = groupedByCategory.Army.find(b => b.wafi_name === "Laboratory")?.instances[0]?.wafi_level || 0;
      const phLevel = groupedByCategory.Army.find(b => b.wafi_name === "Pet House")?.instances[0]?.wafi_level || 0;
      const hhLevel = groupedByCategory.Army.find(b => b.wafi_name === "Hero Hall")?.instances[0]?.wafi_level || 0;
      const brLevel = groupedByCategory.Army.find(b => b.wafi_name === "Barracks")?.instances[0]?.wafi_level || 0;
      const dbrLevel = groupedByCategory.Army.find(b => b.wafi_name === "Dark Barracks")?.instances[0]?.wafi_level || 0;
      const ftLevel = groupedByCategory.Army.find(b => b.wafi_name === "Spell Factory")?.instances[0]?.wafi_level || 0;
      const dftLevel = groupedByCategory.Army.find(b => b.wafi_name === "Dark Spell Factory")?.instances[0]?.wafi_level || 0;
      const bsLevel = groupedByCategory.Army.find(b => b.wafi_name === "Blacksmith")?.instances[0]?.wafi_level || 0;
      const wsLevel = groupedByCategory.Army.find(b => b.wafi_name === "Workshop")?.instances[0]?.wafi_level || 0;

      // Update base with building levels
      const newBase = {
        wafi_labLevel: labLevel,
        wafi_phLevel: phLevel,
        wafi_hhLevel: hhLevel,
        wafi_brLevel: brLevel,
        wafi_dbrLevel: dbrLevel,
        wafi_ftLevel: ftLevel,
        wafi_dftLevel: dftLevel,
        wafi_bsLevel: bsLevel,
        wafi_wsLevel: wsLevel
      };

      setBase(prevBase => ({
        ...prevBase,
        ...newBase
      }));
    }
  }, [playerData, dbObjectData]);

  // Process troop data when playerData is available
  useEffect(() => {
    if (playerData && playerData.townHallLevel && base) {
      const thLevel = playerData.townHallLevel;

      // Initialize troop categories
      const groupedTroopsByCategory = {
        Troops: [],
        DarkTroops: [],
        Spells: [],
        DarkSpells: [],
        Sieges: [],
        Pets: [],
        Heroes: [],
        HeroEquipments: [],
      };

      // Process each troop from dataTroops
      dataTroops.forEach((troop, index) => {
        // Skip troops that require a higher TH level than the player has
        if (troop.th > thLevel) {
          return;
        }

        // Determine the category based on the type indicators
        let category = "";
        if (troop.br) category = "Troops";
        else if (troop.dbr) category = "DarkTroops";
        else if (troop.ft) category = "Spells";
        else if (troop.dft) category = "DarkSpells";
        else if (troop.ws) category = "Sieges";
        else if (troop.ph) category = "Pets";
        else if (troop.hh) category = "Heroes";
        else if (troop.bs) category = "HeroEquipments";

        if (!category) return; // Skip if no category found

        // Find if this troop exists in the database
        const dbObject = dbObjectData.find(obj => obj.wafi_name === troop.name);

        // Calculate the max available level based on the building level
        let maxAvailableLevel = 1;
        if (category === 'Heroes') {
          maxAvailableLevel = troop.lvls.filter(lv => lv.lab <= base.wafi_hhLevel).length || 1;
        } else if (category === 'Pets') {
          maxAvailableLevel = troop.lvls.filter(lv => lv.lab <= base.wafi_phLevel).length || 1;
        } else if (category === 'HeroEquipments') {
          maxAvailableLevel = troop.lvls.filter(lv => lv.bs <= base.wafi_bsLevel).length || 1;
        } else {
          maxAvailableLevel = troop.lvls.filter(lv => lv.lab <= base.wafi_labLevel).length || 1;
        }

        // Create a formatted troop object
        const formattedTroop = {
          instance_id: dbObject ? `db_${dbObject.wafi_id}` : `troop_${index}`,
          wafi_id: dbObject?.wafi_id || null,
          wafi_name: troop.name,
          wafi_max_level: maxAvailableLevel,
          wafi_level: dbObject ? dbObject.wafi_level : 0, // Use DB level or 0 if not in DB
          unlockTH: troop.th,
          type: category,
          costType: troop.ct || 'elixir', // Default to elixir if not specified
          levels: troop.lvls,
          exists_in_db: !!dbObject,
          // Add indicators to help with sorting
          barrackLevel: troop.br || false,
          darkBarrackLevel: troop.dbr || false,
          factoryLevel: troop.ft || false,
          darkFactoryLevel: troop.dft || false,
          workshopLevel: troop.ws || false,
          petHouseLevel: troop.ph || false,
          heroHallLevel: troop.hh || false,
          blackSmithLevel: troop.bs || false,
          rarity: troop.rarity || false,
          hero: troop.hero || false,
        };

        // Add to the appropriate category
        groupedTroopsByCategory[category].push(formattedTroop);
      });

      // Sort each category based on the appropriate level indicator
      groupedTroopsByCategory.Troops.sort((a, b) => a.barrackLevel - b.barrackLevel);
      groupedTroopsByCategory.DarkTroops.sort((a, b) => a.darkBarrackLevel - b.darkBarrackLevel);
      groupedTroopsByCategory.Spells.sort((a, b) => a.factoryLevel - b.factoryLevel);
      groupedTroopsByCategory.DarkSpells.sort((a, b) => a.darkFactoryLevel - b.darkFactoryLevel);
      groupedTroopsByCategory.Sieges.sort((a, b) => a.workshopLevel - b.workshopLevel);
      groupedTroopsByCategory.Pets.sort((a, b) => a.petHouseLevel - b.petHouseLevel);
      groupedTroopsByCategory.Heroes.sort((a, b) => a.heroHallLevel - b.heroHallLevel);
      groupedTroopsByCategory.HeroEquipments.sort((a, b) => {
        const sortByHero = a.hero?.localeCompare(b.hero || '') || 0;
        if (sortByHero !== 0) { return sortByHero; }
        return (a.blackSmithLevel || 0) - (b.blackSmithLevel || 0);
      });

      setAvailableTroops(groupedTroopsByCategory);
    }
  }, [playerData, dbObjectData, base]); // Added base as a dependency

  // Handler for level changes (works for both buildings and troops)
  const handleLevelChange = (instanceId, newLevel) => {
    // Update the changes
    setChanges(prev => ({
      ...prev,
      [instanceId]: newLevel
    }));
  };

  // Handler for setting all levels of a specific building type
  const handleSetAllBuildingLevels = (buildingGroup, level) => {
    const newChanges = { ...changes };

    buildingGroup.instances.forEach(instance => {
      // Make sure level is within limits
      const validLevel = Math.max(0, Math.min(level, instance.wafi_max_level));
      newChanges[instance.instance_id] = validLevel;
    });

    setChanges(newChanges);
  };

  // Handler for setting all levels of a specific troop category
  const handleSetAllTroopLevels = (category, level) => {
    const newChanges = { ...changes };

    availableTroops[category].forEach(troop => {
      // Make sure level is within limits
      const validLevel = Math.max(0, Math.min(level, troop.wafi_max_level));
      newChanges[troop.instance_id] = validLevel;
    });

    setChanges(newChanges);
  };

  // Handler for setting all levels in the current tab
  const handleSetAllTabLevels = (level, useMaxForPrevTh = false) => {
    const tabType = allTabs[activeTab]?.type;

    if (tabType === 'building') {
      if (!availableBuildings || !availableBuildings[activeTab]) return;

      const newChanges = { ...changes };

      availableBuildings[activeTab].forEach(buildingGroup => {
        // Skip Wall building
        if (buildingGroup.wafi_name === "Wall" || buildingGroup.wafi_name === "Town Hall") return;

        buildingGroup.instances.forEach(instance => {
          let targetLevel = level;

          // If using max level for previous TH
          if (useMaxForPrevTh) {
            targetLevel = instance.wafi_prev_th_max_level;
          }
          // If using max level for current TH
          else if (level === 'max') {
            targetLevel = instance.wafi_max_level;
          }

          // Make sure level is within limits
          const validLevel = Math.max(0, Math.min(targetLevel, instance.wafi_max_level));
          newChanges[instance.instance_id] = validLevel;
        });
      });

      setChanges(newChanges);
    }
    else if (tabType === 'troop') {
      if (!availableTroops || !availableTroops[activeTab]) return;

      const newChanges = { ...changes };

      availableTroops[activeTab].forEach(troop => {
        let targetLevel = level;

        // If using max level for current TH
        if (level === 'max') {
          targetLevel = troop.wafi_max_level;
        }

        // Make sure level is within limits
        const validLevel = Math.max(0, Math.min(targetLevel, troop.wafi_max_level));
        newChanges[troop.instance_id] = validLevel;
      });

      setChanges(newChanges);
    }
  };

  // Handler for setting all categories
  const handleSetAllCategoriesLevels = (level, useMaxForPrevTh = false) => {
    const newChanges = { ...changes };

    // Process all building categories
    Object.values(availableBuildings).forEach(categoryBuildings => {
      categoryBuildings.forEach(buildingGroup => {
        // Skip Wall building and Town Hall
        if (buildingGroup.wafi_name === "Wall" || buildingGroup.wafi_name === "Town Hall") return;

        buildingGroup.instances.forEach(instance => {
          let targetLevel = level;

          // If using max level for previous TH
          if (useMaxForPrevTh) {
            targetLevel = instance.wafi_prev_th_max_level;
          }
          // If using max level for current TH
          else if (level === 'max') {
            targetLevel = instance.wafi_max_level;
          }

          // Make sure level is within limits
          const validLevel = Math.max(0, Math.min(targetLevel, instance.wafi_max_level));
          newChanges[instance.instance_id] = validLevel;
        });
      });
    });

    // Process all troop categories
    Object.values(availableTroops).forEach(troopCategory => {
      troopCategory.forEach(troop => {
        let targetLevel = level;

        // If using max level for current TH
        if (level === 'max') {
          targetLevel = troop.wafi_max_level;
        }

        // Make sure level is within limits
        const validLevel = Math.max(0, Math.min(targetLevel, troop.wafi_max_level));
        newChanges[troop.instance_id] = validLevel;
      });
    });

    setChanges(newChanges);
  };

  // Handler for saving changes
  const handleSaveChanges = async () => {
    setIsSaving(true);
    try {
      // Create arrays for database updates, new buildings, and objects to delete
      const updatePromises = [];
      const newObjects = [];
      const deletePromises = [];

      // Process each change
      for (const [instanceId, newLevel] of Object.entries(changes)) {
        // Check if this is a database object (starts with db_)
        if (instanceId.startsWith('db_')) {
          // Extract the database ID
          const dbId = instanceId.split('_')[1];

          // If level is set to 0, delete the object from database
          if (newLevel === 0) {
            deletePromises.push(objectAPI.deleteObject(dbId));
          } else {
            // Otherwise update the level
            updatePromises.push(objectAPI.updateObjectLevel(dbId, newLevel));
          }
        } else {
          // This is a non-database object
          // Find the instance details from availableBuildings or availableTroops
          let objectInstance = null;
          let objectName = '';

          // Check if it's a building (instanceId starts with building_)
          if (instanceId.startsWith('building_')) {
            // Search through all building categories
            for (const category of Object.keys(availableBuildings)) {
              for (const group of availableBuildings[category]) {
                const instance = group.instances.find(i => i.instance_id === instanceId);
                if (instance) {
                  objectInstance = instance;
                  objectName = instance.wafi_name;
                  break;
                }
              }
              if (objectInstance) break;
            }
          }
          // Check if it's a troop (instanceId starts with troop_)
          else if (instanceId.startsWith('troop_')) {
            // Search through all troop categories
            for (const category of Object.keys(availableTroops)) {
              const troop = availableTroops[category].find(t => t.instance_id === instanceId);
              if (troop) {
                objectInstance = troop;
                objectName = troop.wafi_name;
                break;
              }
            }
          }

          // Only add objects with level > 0 to create (skip level 0)
          if (objectInstance && newLevel > 0) {
            newObjects.push({
              name: objectName,
              level: newLevel
            });
          }
        }
      }

      // Execute all promises in parallel
      await Promise.all([
        ...updatePromises,
        ...deletePromises,
        // Only make the createOrUpdateObjects call if there are new objects to add
        ...(newObjects.length > 0 && base?.wafi_id
          ? [objectAPI.createOrUpdateObjects(base.wafi_id, newObjects)]
          : [])
      ]);

      // Reset changes
      setChanges({});
      setIsSaving(false);

      // Notify success
      alert("Changes saved successfully!");

      // Navigate back to the base view
      navigate(`/base/${id}`);
    } catch (error) {
      console.error("Error saving changes:", error);
      alert("Failed to save changes. Please try again.");
      setIsSaving(false);
    }
  };

  // Components

  // Building Card Component
  const BuildingCard = ({ buildingGroup, changes, onLevelChange }) => {
    const urlAssets = import.meta.env.VITE_ASSETS_URL || 'http://localhost:3000/assets';

    // Get building image URL for the highest level building
    const getBuildingImageUrl = (buildingName, level) => {
      const normalizedName = buildingName
        .toLowerCase()
        .replace(/[']/g, '')
        .replace(/\s+/g, '-');

      const displayLevel = level > 0 ? level : 1;
      return `${urlAssets}/${normalizedName}/${normalizedName}-${displayLevel}.png`;
    };

    // Get the highest level instance for display
    const highestLevelInstance = [...buildingGroup.instances].sort((a, b) => {
      const aLevel = changes[a.instance_id] !== undefined ? changes[a.instance_id] : a.wafi_level;
      const bLevel = changes[b.instance_id] !== undefined ? changes[b.instance_id] : b.wafi_level;
      return bLevel - aLevel;
    })[0];

    const highestLevel = changes[highestLevelInstance.instance_id] !== undefined
      ? changes[highestLevelInstance.instance_id]
      : highestLevelInstance.wafi_level;

    const buildingImageSrc = getBuildingImageUrl(buildingGroup.wafi_name, highestLevel);

    // Set all building instances to specific level
    const handleSetAll = (level) => {
      // Make sure level is within limits for this building
      const validLevel = Math.min(level, buildingGroup.wafi_max_level);

      const newChanges = {};
      buildingGroup.instances.forEach(instance => {
        newChanges[instance.instance_id] = validLevel;
      });

      // Apply all changes at once
      Object.entries(newChanges).forEach(([id, level]) => {
        onLevelChange(id, level);
      });
    };

    return (
      <div className="bg-white/5 rounded-lg border border-white/10 overflow-hidden">
        {/* Building Header */}
        <div className="flex items-center justify-between bg-white/10 p-3">
          <div className="flex items-center gap-3">
            <img src={buildingImageSrc} alt={buildingGroup.wafi_name} className="w-10 h-10" />
            <div>
              <h3 className="font-medium text-white">{buildingGroup.wafi_name}</h3>
              <div className="text-xs text-white/70">
                Max Level: {buildingGroup.wafi_max_level}
              </div>
            </div>
          </div>
          <div className="text-sm text-white/80">
            x{buildingGroup.wafi_count}
          </div>
        </div>

        {/* Building Controls */}
        <div className="p-3 bg-white/5">
          <div className="flex gap-2 mb-3">
            <button
              onClick={() => handleSetAll(0)}
              className="flex-1 bg-red-600 hover:bg-red-700 text-white text-sm py-1 px-2 rounded transition-colors"
            >
              Set All to 0
            </button>
            <button
              onClick={() => handleSetAll(buildingGroup.wafi_max_level)}
              className="flex-1 bg-green-600 hover:bg-green-700 text-white text-sm py-1 px-2 rounded transition-colors"
            >
              Max All
            </button>
          </div>
        </div>

        {/* Building Instances */}
        <div className="p-3 divide-y divide-white/10">
          {buildingGroup.instances.map((instance, idx) => {
            const currentLevel = changes[instance.instance_id] !== undefined
              ? changes[instance.instance_id]
              : instance.wafi_level;

            return (
              <div key={idx} className="py-2 flex items-center justify-between">
                <div className="text-sm">
                  {buildingGroup.wafi_count > 1 && `#${instance.wafi_instance}`}
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-center">
                    <div className="text-xs text-white/70 mb-1">Level</div>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => onLevelChange(instance.instance_id, Math.max(0, currentLevel - 1))}
                        className="bg-red-600 text-white h-6 w-6 rounded-l flex items-center justify-center hover:bg-red-700 disabled:opacity-50"
                        disabled={currentLevel <= 0}
                      >
                        -
                      </button>
                      <div className="bg-gray-800 h-6 w-10 flex items-center justify-center text-sm">
                        {currentLevel}
                      </div>
                      <button
                        onClick={() => onLevelChange(instance.instance_id, Math.min(instance.wafi_max_level, currentLevel + 1))}
                        className="bg-green-600 text-white h-6 w-6 rounded-r flex items-center justify-center hover:bg-green-700 disabled:opacity-50"
                        disabled={currentLevel >= instance.wafi_max_level}
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  // Troop Card Component
  const TroopCard = ({ troop, changes, onLevelChange }) => {
    const urlAssets = import.meta.env.VITE_ASSETS_URL || 'http://localhost:3000/assets';

    // Get troop image URL
    const getTroopImageUrl = (troopName, level) => {
      // Normalize name for URL
      const normalizedName = troopName
        .toLowerCase()
        .replace(/['\.]/g, '')
        .replace(/\s+/g, '-');

      if (troop.type === 'Heroes') {
        return `${urlAssets}/hero/${normalizedName}.png`;
      }
      else if (troop.type === 'Pets') {
        return `${urlAssets}/pet/${normalizedName}.png`;
      } else if (troop.type === 'HeroEquipments') {
        return `${urlAssets}/he/${normalizedName}.png`;
      }

      // Use level 1 as a display level if current level is 0
      const displayLevel = level > 0 ? level : 1;
      return `${urlAssets}/troop/${normalizedName}-${displayLevel}.png`;
    };

    const currentLevel = changes[troop.instance_id] !== undefined
      ? changes[troop.instance_id]
      : troop.wafi_level;

    const troopImageSrc = getTroopImageUrl(troop.wafi_name, currentLevel);

    // Check if troop is active (level > 0)
    const isActive = currentLevel > 0;

    return (
      <div className="bg-white/5 rounded-lg border border-white/10 overflow-hidden">
        {/* Troop Header */}
        <div className="flex items-center justify-between bg-white/10 p-3">
          <div className="flex items-center gap-3">
            <img src={troopImageSrc} alt={troop.wafi_name} className="w-10 h-10 rounded-full" />
            <div>
              <h3 className="font-medium text-white">{troop.wafi_name}</h3>
              <div className="text-xs text-white/70">
                Max Level: {troop.wafi_max_level}
              </div>
            </div>
          </div>
          <div className="text-sm text-white/80">
            TH {troop.unlockTH}+
          </div>
        </div>

        {/* Troop Controls */}
        <div className="p-3">
          {isActive ? (
            <>
              <div className="flex items-center justify-between mb-2">
                <div className="text-sm">Current Level</div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => onLevelChange(troop.instance_id, Math.max(0, currentLevel - 1))}
                    className="bg-red-600 text-white h-6 w-6 rounded-l flex items-center justify-center hover:bg-red-700 disabled:opacity-50"
                    disabled={currentLevel <= 0}
                  >
                    -
                  </button>
                  <div className="bg-gray-800 h-6 w-10 flex items-center justify-center text-sm">
                    {currentLevel}
                  </div>
                  <button
                    onClick={() => onLevelChange(troop.instance_id, Math.min(troop.wafi_max_level, currentLevel + 1))}
                    className="bg-green-600 text-white h-6 w-6 rounded-r flex items-center justify-center hover:bg-green-700 disabled:opacity-50"
                    disabled={currentLevel >= troop.wafi_max_level}
                  >
                    +
                  </button>
                </div>
              </div>

              <div className="flex justify-between text-xs text-white/70">
                <span>Unlocks at TH {troop.unlockTH}</span>
                <span>{currentLevel}/{troop.wafi_max_level}</span>
              </div>

              {/* Level Progress Bar */}
              <div className="w-full bg-gray-700 rounded-full h-1.5 mt-2">
                <div
                  className={`h-1.5 rounded-full ${currentLevel === troop.wafi_max_level ? 'bg-green-500' :
                    currentLevel > 0 ? 'bg-blue-500' : 'bg-gray-600'
                    }`}
                  style={{ width: `${(currentLevel / troop.wafi_max_level) * 100}%` }}
                ></div>
              </div>
            </>
          ) : (
            <div className="border-t border-white/10 pt-3 text-center">
              <p className="text-white/70 mb-3">Not unlocked yet.</p>
              <button
                className="mt-2 bg-blue-500 text-white py-2 px-4 rounded text-sm hover:bg-blue-600 transition-colors"
                onClick={() => onLevelChange(troop.instance_id, 1)}
              >
                <FontAwesomeIcon icon={faUnlock} className="mr-2" />
                Mark as Unlocked
              </button>
            </div>
          )}
        </div>
      </div>
    );
  };

  // Tab Controls Component
  const TabControls = ({ onSetAllTabLevels, onSetAllCategoriesLevels, townHallLevel }) => {
    return (
      <div className="bg-white/5 rounded-lg border border-white/10 p-3 mb-4">
        <h3 className="text-sm font-medium mb-2 text-white">Tab Controls</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          <button
            onClick={() => onSetAllTabLevels(0)}
            className="bg-red-600 hover:bg-red-700 text-white text-sm py-1 px-2 rounded transition-colors"
          >
            Set Tab to 0
          </button>
          <button
            onClick={() => onSetAllTabLevels('max')}
            className="bg-green-600 hover:bg-green-700 text-white text-sm py-1 px-2 rounded transition-colors"
          >
            Max Tab
          </button>
          {allTabs[activeTab]?.type === 'building' && (
            <button
              onClick={() => onSetAllTabLevels(null, true)}
              className="bg-blue-600 hover:bg-blue-700 text-white text-sm py-1 px-2 rounded transition-colors"
            >
              Set to TH{townHallLevel - 1} Max
            </button>
          )}
          <button
            onClick={() => onSetAllCategoriesLevels('max')}
            className="bg-purple-600 hover:bg-purple-700 text-white text-sm py-1 px-2 rounded transition-colors"
          >
            Max All Categories
          </button>
        </div>
      </div>
    );
  };

  // Header Section Component
  const HeaderSection = ({ base, onNavigateBack, onSaveChanges, hasChanges, isSaving }) => {
    return (
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6 gap-3">
        <div className="flex items-center gap-2">
          <button
            onClick={onNavigateBack}
            className="flex items-center gap-2 text-white/70 hover:text-white text-base"
          >
            <FontAwesomeIcon icon={faArrowLeft} />
            <span>Back to Base</span>
          </button>
        </div>

        <div className="flex items-center">
          <div className="mr-4">
            <h2 className="text-xl font-bold">{base?.wafi_name || "Base"}</h2>
            <p className="text-white/70">{base?.wafi_tag || "Unknown Tag"}</p>
          </div>

          <button
            onClick={onSaveChanges}
            disabled={!hasChanges || isSaving}
            className={`flex items-center gap-2 py-2 px-4 rounded-lg transition-colors ${hasChanges && !isSaving
              ? "bg-yellow-500 hover:bg-yellow-600 text-white"
              : "bg-gray-700 text-white/50 cursor-not-allowed"
              }`}
          >
            {isSaving ? (
              <>
                <FontAwesomeIcon icon={faSpinner} spin />
                <span>Saving...</span>
              </>
            ) : (
              <>
                <FontAwesomeIcon icon={faSave} />
                <span>Save Changes</span>
              </>
            )}
          </button>
        </div>
      </div>
    );
  };

  // Tab Navigation Component
  const TabNavigation = () => {
    const thLevel = playerData?.townHallLevel || 1;

    // Get available tabs based on TH level
    const availableTabs = Object.entries(allTabs)
      .filter(([, tabInfo]) => thLevel >= tabInfo.minTH)
      .map(([tabName, tabInfo]) => ({ name: tabName, ...tabInfo }));

    // Group tabs by type for better organization
    const buildingTabs = availableTabs.filter(tab => tab.type === 'building');
    const troopTabs = availableTabs.filter(tab => tab.type === 'troop');

    return (
      <div className="mb-6">
        <div className="text-sm font-medium text-white/70 mb-2">Building Categories</div>
        <div className="flex flex-wrap gap-2 mb-4">
          {buildingTabs.map(tab => (
            <button
              key={tab.name}
              onClick={() => setActiveTab(tab.name)}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-md text-sm transition-all ${activeTab === tab.name
                ? "bg-yellow-400 text-gray-900 font-medium"
                : "bg-white/10 hover:bg-white/20 text-white/70 hover:text-white"
                }`}
            >
              <FontAwesomeIcon icon={tab.icon} />
              <span>{tab.name}</span>
            </button>
          ))}
        </div>

        <div className="text-sm font-medium text-white/70 mb-2">Troop Categories</div>
        <div className="flex flex-wrap gap-2">
          {troopTabs.map(tab => (
            <button
              key={tab.name}
              onClick={() => setActiveTab(tab.name)}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-md text-sm transition-all ${activeTab === tab.name
                ? "bg-yellow-400 text-gray-900 font-medium"
                : "bg-white/10 hover:bg-white/20 text-white/70 hover:text-white"
                }`}
            >
              <FontAwesomeIcon icon={tab.icon} />
              <span>{tab.name}</span>
            </button>
          ))}
        </div>
      </div>
    );
  };

  // Get active tab content
  const getActiveTabContent = () => {
    const tabType = allTabs[activeTab]?.type;

    if (tabType === 'building') {
      if (!availableBuildings || !availableBuildings[activeTab] || availableBuildings[activeTab].length === 0) {
        return (
          <div className="text-center py-5">
            <p>No {activeTab.toLowerCase()} available for TH {playerData?.townHallLevel || "unknown"}.</p>
          </div>
        );
      }

      return (
        <div>
          {/* Global controls for the active tab */}
          <TabControls
            onSetAllTabLevels={handleSetAllTabLevels}
            onSetAllCategoriesLevels={handleSetAllCategoriesLevels}
            townHallLevel={playerData?.townHallLevel || 0}
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {availableBuildings[activeTab].map((buildingGroup) => (
              buildingGroup.wafi_name !== "Wall" && buildingGroup.wafi_name !== "Town Hall" && (
                <BuildingCard
                  key={buildingGroup.group_id}
                  buildingGroup={buildingGroup}
                  changes={changes}
                  onLevelChange={handleLevelChange}
                />
              )
            ))}
          </div>
        </div>
      );
    }
    else if (tabType === 'troop') {
      if (!availableTroops || !availableTroops[activeTab] || availableTroops[activeTab].length === 0) {
        return (
          <div className="text-center py-5">
            <p>No {activeTab.toLowerCase()} available for TH {playerData?.townHallLevel || "unknown"}.</p>
          </div>
        );
      }

      return (
        <div>
          {/* Global controls for the active tab */}
          <TabControls
            onSetAllTabLevels={handleSetAllTabLevels}
            onSetAllCategoriesLevels={handleSetAllCategoriesLevels}
            townHallLevel={playerData?.townHallLevel || 0}
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {availableTroops[activeTab].map((troop, index) => (
              <TroopCard
                key={troop.instance_id || index}
                troop={troop}
                changes={changes}
                onLevelChange={handleLevelChange}
              />
            ))}
          </div>
        </div>
      );
    }

    return null;
  };

  return (
    <div className="w-full p-4 bg-white/10 rounded-lg border border-white/20 text-white">
      {/* Header with back button, save button, and base info */}
      <HeaderSection
        base={base}
        onNavigateBack={() => navigate(`/base/${id}`)}
        onSaveChanges={handleSaveChanges}
        hasChanges={Object.keys(changes).length > 0}
        isSaving={isSaving}
      />

      {/* Tab Navigation */}
      <TabNavigation />

      {/* Content */}
      <div className="tab-content">
        {getActiveTabContent()}

        {(!availableBuildings || Object.values(availableBuildings).every(cat =>
          cat.filter(bg => bg.wafi_name !== "Wall" && bg.wafi_name !== "Town Hall").length === 0)) &&
          (!availableTroops || Object.values(availableTroops).every(cat => cat.length === 0)) && (
            <div className="text-center py-10">
              <FontAwesomeIcon icon={faExclamationTriangle} className="text-yellow-400 text-3xl mb-3" />
              <h3 className="text-xl mb-2">No data available</h3>
              <p className="text-white/70 mb-4">
                No buildings or troops found for Town Hall level {playerData?.townHallLevel || "unknown"}.
              </p>
            </div>
          )}
      </div>
    </div>
  );
};

export default BaseEdit;