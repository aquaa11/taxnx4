import React, { useState, useEffect } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
    faArrowLeft, faSpinner, faExclamationTriangle, faBuilding,
    faUser, faDragon, faStar, faShield, faHome, faBomb, faChartBar,
    faFlask, faMoon, faHorse, faTruck, faCrown, faListCheck,
    faMeteor,
    faXmarksLines
} from "@fortawesome/free-solid-svg-icons";
import { getPlayer } from "@/lib/cocAPI";
import { getPlayerDummy } from "@/helpers/dataPlayerDummy";
import { baseAPI, objectAPI } from "@/lib/dbAPI";
import dataBuildings from './dataBuildings';
import dataTroops from "./dataTroops";
import BuildingsTab from './components/Base/BuildingsTab';
import StatisticTab from './components/Base/StatisticTab';
import BaseHeader from './components/Base/BaseHeader';
import TroopsTab from "./components/Base/TroopsTab";
import ProgressTab from "./components/Base/ProgressTab";
import WallsTab from "./components/Base/WallsTab";
import { Tooltip } from "react-tooltip";

const Base = () => {
    const { id } = useParams();
    const tag = id.startsWith('#') ? id : `#${id}`;
    const navigate = useNavigate();
    const location = useLocation(); // Add this to access URL hash

    const [playerData, setPlayerData] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);
    const [isBaseExists, setIsBaseExists] = useState(false);
    const [base, setBase] = useState(null);
    const [dbObjectData, setDbObjectData] = useState([]);
    const [processedObjectData, setProcessedObjectData] = useState(null);
    const [activeTab, setActiveTab] = useState("defenses");
    const [processedTroopData, setProcessedTroopData] = useState(null);
    const [wallData, setWallData] = useState(null);

    // Map URL fragments to tab names - Use lowercase keys
    const tabMap = {
        'defenses': 'defenses',
        'traps': 'traps',
        'resources': 'resources',
        'army': 'army',
        'troops': 'troops',
        'darktroops': 'darkTroops', // Changed key to lowercase
        'spells': 'spells',
        'darkspells': 'darkSpells', // Changed key to lowercase
        'sieges': 'sieges',
        'pets': 'pets',
        'heroes': 'heroes',
        'heroequipments': 'heroEquipments', // Changed key to lowercase
        'walls': 'walls',
        'progress': 'progress',
        'statistics': 'statistics',
    };

    // Function to get tab name from URL hash
    const getTabFromHash = () => {
        // Get hash without the # symbol
        const hash = location.hash.replace('#', '').toLowerCase();

        // Return mapped tab name or default to 'defenses'
        return hash ? (tabMap[hash] || 'defenses') : 'defenses';
    };

    // Update URL hash when tab changes
    const updateUrlHash = (tabName) => {
        if (typeof window !== 'undefined') {
            window.location.hash = tabName;
        }
    };

    // Set active tab based on URL hash
    useEffect(() => {
        setActiveTab(getTabFromHash());
    }, [location.hash]);

    // Handler for tab clicks - updates active tab and URL hash
    const handleTabClick = (tabName) => {
        setActiveTab(tabName);
        updateUrlHash(tabName);
    };

    useEffect(() => {
        const getBase = async () => {
            try {
                const baseData = await baseAPI.getBaseByTag(tag);
                setBase(baseData);
                if (baseData && baseData.wafi_id) {
                    try {
                        const objectsData = await objectAPI.getObject(baseData.wafi_id);
                        setDbObjectData(objectsData);
                    } catch (err) {
                        console.error("Error fetching object data: ", err);
                        setDbObjectData([]);
                    }
                }
            } catch (err) {
                console.error("Error fetching base data: ", err);
            }
        };

        const fetchPlayerData = async () => {
            setIsLoading(true);
            try {
                // const encodedTag = encodeURIComponent(tag);
                // const response = await getPlayer(
                //     encodedTag,
                //     abortControllerRef.current.signal
                // );
                // console.log(response.data)
                const dataPlayerDummy = getPlayerDummy(1);
                setPlayerData(dataPlayerDummy);
                // setPlayerData(response.data);
                setIsBaseExists(true);
                setIsLoading(false);
            } catch (err) {
                console.error("Error fetching player data:", err);
                setError(err.response?.data?.message || "Failed to fetch player data");
                console.log("using dummy data")
                setIsBaseExists(true);
                setIsLoading(false);
            }
        };
        getBase();
        fetchPlayerData();
    }, [tag]);

    // Process data from dataBuildings when playerData is available
    useEffect(() => {
        if (playerData && playerData.townHallLevel) {
            const thLevel = playerData.townHallLevel;

            // Find Town Hall Weapon level from database if it exists
            const townHallWeaponObject = dbObjectData.find(obj => obj.wafi_name === "Town Hall Weapon");
            const weaponLevel = townHallWeaponObject ? townHallWeaponObject.wafi_level : (playerData.townHallWeaponLevel || 0);

            // Group buildings by category
            const groupedByCategory = {
                Defenses: [],
                Traps: [],
                Resources: [],
                Army: [],
                Walls: [],
            };

            // Process each building from dataBuildings
            dataBuildings.forEach((building, typeIndex) => {
                // Skip Town Hall if it's not TH 12-15 (Town Hall with weapons)
                if (building.name === "Town Hall" && (thLevel < 12 || thLevel > 15)) {
                    return;
                }

                // Find the highest level available for this TH level
                const maxLevelForTh = building.lvls
                    .filter(level => level.th <= thLevel)
                    .sort((a, b) => b.lv - a.lv)[0];

                // Find the highest level available for the previous TH level
                const prevThLevel = thLevel > 1 ? thLevel - 1 : 1;
                const maxLevelForPrevTh = building.lvls
                    .filter(level => level.th <= prevThLevel)
                    .sort((a, b) => b.lv - a.lv)[0];

                // Find availability at the current TH level or below
                const availableInfo = building.lvls
                    .sort((a, b) => b.th - a.th)
                    .find(level => level.th <= thLevel);
                const availableCount = availableInfo?.n || 0;

                // Skip if no buildings of this type are available at this TH level
                if (availableCount <= 0) return;

                // Determine category based on building name
                const listBuildingType = {
                    Defenses: ["Cannon", "Archer Tower", "Mortar", "Air Defense", "Wizard Tower", "Air Sweeper", "Hidden Tesla", "Bomb Tower", "X-Bow", "Inferno Tower", "Eagle Artillery", "Scattershot", "Builder's Hut", "Spell Tower", "Monolith", "Multi-Archer Tower", "Ricochet Cannon", "Multi-Gear Tower", "Firespitter", "Town Hall"],
                    Traps: ["Bomb", "Spring Trap", "Giant Bomb", "Air Bomb", "Seeking Air Mine", "Skeleton Trap", "Tornado Trap", "Giga Bomb"],
                    Resources: ["Gold Mine", "Elixir Collector", "Dark Elixir Drill", "Gold Storage", "Elixir Storage", "Dark Elixir Storage", "Helper Hut"],
                    Army: ["Army Camp", "Barracks", "Dark Barracks", "Clan Castle", "Spell Factory", "Dark Spell Factory", "Lab", "Hero Hall", "Blacksmith", "Workshop", "Pet House"]
                };

                let category = "Defenses";
                if (listBuildingType.Defenses.some(defense => building.name.includes(defense))) {
                    category = "Defenses";
                } else if (listBuildingType.Traps.some(trap => building.name.includes(trap))) {
                    category = "Traps";
                } else if (listBuildingType.Resources.some(resource => building.name.includes(resource))) {
                    category = "Resources";
                } else if (listBuildingType.Army.some(armyBuilding => building.name.includes(armyBuilding))) {
                    category = "Army";
                }

                // Find database objects that match this building name
                let dbObjects = dbObjectData.filter(obj => obj.wafi_name === building.name);

                // Special handling for walls
                if (building.name === "Wall") {
                    // Find the maximum wall level for this TH level
                    const maxWallLevel = building.lvls
                        .filter(level => level.th <= thLevel)
                        .sort((a, b) => b.lv - a.lv)[0]?.lv || 1;

                    // Find the total number of wall pieces available at this TH level
                    const totalWallPieces = building.lvls
                        .find(level => level.th === thLevel)?.n || 0;

                    // Create wall instances for each level
                    const wallInstances = [];
                    let currentTotalCount = 0;

                    // Create an instance for each possible wall level up to max
                    for (let level = 1; level <= maxWallLevel; level++) {
                        // Find database objects that match this wall level
                        const dbObject = dbObjectData.find(obj => obj.wafi_name === `Wall ${level}`);
                        const wallCount = dbObject ? dbObject.wafi_level : 0; // Using wafi_level to store count
                        currentTotalCount += wallCount;

                        wallInstances.push({
                            wafi_id: dbObject ? dbObject.wafi_id : null,
                            wafi_name: `Wall ${level}`,
                            wafi_level: level,
                            wafi_max_level: maxWallLevel,
                            wafi_wall_count: wallCount,
                            exists_in_db: !!dbObject
                        });
                    }

                    // Set wall data state
                    setWallData({
                        maxWallLevel,
                        totalWallPieces,
                        currentTotalCount,
                        instances: wallInstances
                    });
                }


                // Special handling for Town Hall with weapons (TH 12-15)
                if (building.name === "Town Hall" && thLevel >= 12 && thLevel <= 15) {
                    // Create individual building instances
                    const buildingInstances = [];

                    // For Town Hall, we only have one instance
                    const dbObject = dbObjects.length > 0 ? dbObjects[0] : null;

                    // Town Hall weapon has 5 levels (0-4) for TH 12-15
                    const maxWeaponLevel = 5;

                    // Use the weapon level we found earlier
                    const currentWeaponLevel = weaponLevel;

                    buildingInstances.push({
                        instance_id: dbObject ? `db_${dbObject.wafi_id}` : `building_${typeIndex}_0`,
                        building_id: `building_${typeIndex}`,
                        wafi_type_id: dbObject ? dbObject.wafi_type_id : typeIndex,
                        wafi_name: building.name,
                        wafi_max_level: thLevel, // Base level is the TH level
                        wafi_weapon_level: currentWeaponLevel, // Current weapon level
                        wafi_max_weapon_level: maxWeaponLevel, // Max weapon level is 4
                        wafi_prev_th_max_level: prevThLevel,
                        wafi_level: thLevel, // Town Hall level is fixed
                        wafi_instance: 1,
                        wafi_total_instances: 1,
                        wafi_category_name: category,
                        wafi_db_id: dbObject ? dbObject.wafi_id : null,
                        exists_in_db: !!dbObject,
                        has_weapon: true
                    });

                    // Group Town Hall building
                    const buildingGroup = {
                        group_id: `group_${typeIndex}`,
                        wafi_type_id: typeIndex,
                        wafi_name: building.name,
                        wafi_max_level: thLevel,
                        wafi_prev_th_max_level: prevThLevel,
                        wafi_count: 1,
                        wafi_db_count: dbObjects.length,
                        wafi_category_name: category,
                        instances: buildingInstances,
                        has_weapon: true,
                        weapon_level: currentWeaponLevel,
                        max_weapon_level: maxWeaponLevel
                    };

                    // Add to the Defenses category
                    groupedByCategory.Defenses.push(buildingGroup);
                } else {
                    // Regular processing for other buildings
                    // Create individual building instances
                    const buildingInstances = [];
                    for (let i = 0; i < availableCount; i++) {
                        // Check if this instance exists in the database
                        const dbObject = i < dbObjects.length ? dbObjects[i] : null;
                        buildingInstances.push({
                            instance_id: dbObject ? `db_${dbObject.wafi_id}` : `building_${typeIndex}_${i}`,
                            building_id: `building_${typeIndex}`,
                            wafi_type_id: dbObject ? dbObject.wafi_type_id : typeIndex,
                            wafi_name: building.name,
                            wafi_max_level: maxLevelForTh ? maxLevelForTh.lv : 1,
                            wafi_prev_th_max_level: maxLevelForPrevTh ? maxLevelForPrevTh.lv : 1,
                            wafi_level: dbObject ? dbObject.wafi_level : 0, // Use DB level or 0 if not in DB
                            wafi_instance: i + 1,
                            wafi_total_instances: availableCount,
                            wafi_category_name: category,
                            wafi_db_id: dbObject ? dbObject.wafi_id : null, // Store DB ID for updates
                            exists_in_db: !!dbObject // Flag if exists in database
                        });
                    }
                    // Group buildings by type for display
                    const buildingGroup = {
                        group_id: `group_${typeIndex}`,
                        wafi_type_id: typeIndex,
                        wafi_name: building.name,
                        wafi_max_level: maxLevelForTh ? maxLevelForTh.lv : 1,
                        wafi_prev_th_max_level: maxLevelForPrevTh ? maxLevelForPrevTh.lv : 1,
                        wafi_count: availableCount,
                        wafi_db_count: dbObjects.length, // Count how many exist in DB
                        wafi_category_name: category,
                        instances: buildingInstances
                    };

                    // Add to the appropriate category
                    groupedByCategory[category].push(buildingGroup);
                }
            });

            // Sort buildings within each category by wafi_type_id
            Object.keys(groupedByCategory).forEach(category => {
                groupedByCategory[category].sort((a, b) => a.wafi_type_id - b.wafi_type_id);
            });


            // Format data for tab components, organized by category
            const formattedByCategoryForTabs = {
                Defenses: {},
                Traps: {},
                Resources: {},
                Army: {}
            };

            // Process all building categories
            Object.keys(groupedByCategory).forEach(category => {
                groupedByCategory[category].forEach(buildingGroup => {
                    // Skip Wall building
                    if (buildingGroup.wafi_name === "Wall") return; // Uncommented to skip Wall processing

                    // Initialize array for this building type within its category
                    if (!formattedByCategoryForTabs[category][buildingGroup.wafi_name]) {
                        formattedByCategoryForTabs[category][buildingGroup.wafi_name] = [];
                    }

                    // Add ALL instances, not just those in the database
                    buildingGroup.instances.forEach(instance => {
                        // Create a formatted instance based on whether it's Town Hall with weapons or a regular building
                        const formattedInstance = instance.has_weapon
                            ? {
                                wafi_id: instance.wafi_db_id || instance.instance_id,
                                wafi_name: instance.wafi_name,
                                wafi_level: instance.wafi_level,
                                wafi_weapon_level: instance.wafi_weapon_level,
                                wafi_max_weapon_level: instance.wafi_max_weapon_level,
                                wafi_max_level: instance.wafi_max_level,
                                wafi_category_name: instance.wafi_category_name,
                                wafi_instance: instance.wafi_instance,
                                exists_in_db: instance.exists_in_db,
                                instance_id: instance.instance_id,
                                has_weapon: true
                            }
                            : {
                                wafi_id: instance.wafi_db_id || instance.instance_id,
                                wafi_name: instance.wafi_name,
                                wafi_level: instance.wafi_level,
                                wafi_max_level: instance.wafi_max_level,
                                wafi_category_name: instance.wafi_category_name,
                                wafi_instance: instance.wafi_instance,
                                exists_in_db: instance.exists_in_db,
                                instance_id: instance.instance_id
                            };

                        formattedByCategoryForTabs[category][buildingGroup.wafi_name].push(formattedInstance);
                    });
                });
            });

            setProcessedObjectData(formattedByCategoryForTabs);
            const newBase = {
                wafi_labLevel: formattedByCategoryForTabs.Army["Laboratory"][0]?.wafi_level,
                wafi_phLevel: formattedByCategoryForTabs.Army["Pet House"][0]?.wafi_level,
                wafi_hhLevel: formattedByCategoryForTabs.Army["Hero Hall"][0]?.wafi_level,
                wafi_brLevel: formattedByCategoryForTabs.Army["Barracks"][0]?.wafi_level,
                wafi_dbrLevel: formattedByCategoryForTabs.Army["Dark Barracks"][0]?.wafi_level,
                wafi_ftLevel: formattedByCategoryForTabs.Army["Spell Factory"][0]?.wafi_level,
                wafi_dftLevel: formattedByCategoryForTabs.Army["Dark Spell Factory"][0]?.wafi_level,
                wafi_bsLevel: formattedByCategoryForTabs.Army["Blacksmith"][0]?.wafi_level,
                wafi_wsLevel: formattedByCategoryForTabs.Army["Workshop"][0]?.wafi_level
            }
            setBase(prevBase => ({
                ...prevBase,
                ...newBase
            }))
        }
    }, [playerData, dbObjectData]);
    // Process data from dataTroops when playerData is available
    useEffect(() => {
        if (playerData && playerData.townHallLevel) {

            const thLevel = playerData.townHallLevel;

            // Process troop data
            const groupedTroopsByCategory = {
                Troops: [],
                DarkTroops: [],
                Spells: [],
                DarkSpells: [],
                Sieges: [],
                Pets: [],
                Heroes: [],
                HeroEquipments: [],
            };

            // Process each troop from dataTroops
            dataTroops.forEach((troop) => {
                // Skip troops that require a higher TH level than the player has
                if (troop.th > thLevel) {
                    return;
                }

                // Determine the max level available for this TH level
                const maxAvailableLevel = troop.lvls
                    .filter(level => level.lab <= thLevel)
                    .sort((a, b) => b.lv - a.lv)[0]?.lv || 1;


                // Determine the category based on the type indicators
                let category = "";
                if (troop.br) category = "Troops";
                else if (troop.dbr) category = "DarkTroops";
                else if (troop.ft) category = "Spells";
                else if (troop.dft) category = "DarkSpells";
                else if (troop.ws) category = "Sieges";
                else if (troop.ph) category = "Pets";
                else if (troop.hh) category = "Heroes";
                else if (troop.bs) category = "HeroEquipments"
                if (!category) return; // Skip if no category found

                // Find if this troop exists in the database
                const dbObject = dbObjectData.find(obj => obj.wafi_name === troop.name);

                // Create a formatted troop object
                const formattedTroop = {
                    name: troop.name,
                    maxLevel: troop.maxLv,
                    availableMaxLevel: maxAvailableLevel,
                    currentLevel: dbObject ? dbObject.wafi_level : 0, // Use DB level or 0 if not in DB
                    unlockTH: troop.th,
                    type: category,
                    costType: troop.ct || 'elixir', // Default to elixir if not specified
                    levels: troop.lvls,
                    // Add database info for updates
                    wafi_id: dbObject?.wafi_id || null,
                    wafi_type_id: dbObject?.wafi_type_id || null,
                    exists_in_db: !!dbObject,
                    // Add indicators to help with sorting
                    barrackLevel: troop.br || false,
                    darkBarrackLevel: troop.dbr || false,
                    factoryLevel: troop.ft || false,
                    darkFactoryLevel: troop.dft || false,
                    workshopLevel: troop.ws || false,
                    petHouseLevel: troop.ph || false,
                    heroHallLevel: troop.hh || false,
                    blackSmithLevel: troop.bs || false,
                    rarity: troop.rarity || false,
                    hero: troop.hero || false,
                };

                // Add to the appropriate category
                groupedTroopsByCategory[category].push(formattedTroop);
            });

            // Sort each category based on the appropriate level indicator
            groupedTroopsByCategory.Troops.sort((a, b) => a.barrackLevel - b.barrackLevel);
            groupedTroopsByCategory.DarkTroops.sort((a, b) => a.darkBarrackLevel - b.darkBarrackLevel);
            groupedTroopsByCategory.Spells.sort((a, b) => a.factoryLevel - b.factoryLevel);
            groupedTroopsByCategory.DarkSpells.sort((a, b) => a.darkFactoryLevel - b.darkFactoryLevel);
            groupedTroopsByCategory.Sieges.sort((a, b) => a.workshopLevel - b.workshopLevel);
            groupedTroopsByCategory.Pets.sort((a, b) => a.petHouseLevel - b.petHouseLevel);
            groupedTroopsByCategory.Heroes.sort((a, b) => a.heroHallLevel - b.heroHallLevel);
            groupedTroopsByCategory.HeroEquipments.sort((a, b) => {
                const sortByHero = a.hero.localeCompare(b.hero)
                if (sortByHero !== 0) { return sortByHero }
                return a.blackSmithLevel - b.blackSmithLevel;
            });
            setProcessedTroopData(groupedTroopsByCategory);
            // console.log("Processed troop data:", groupedTroopsByCategory);

        }
    }, [playerData, dbObjectData]);

    const handleUpdateLevel = async (objectId, newLevel, isWeaponUpgrade = false, isWall = false) => {
        console.log("Updating level for object ID:", objectId, "to new level:", newLevel,
            "isWeaponUpgrade:", isWeaponUpgrade, "isWall:", isWall);

        // If this is a wall update, use the specialized handler
        if (isWall) {
            return handleWallCountUpdate(objectId, newLevel);
        }

        try {
            // Check if this is a database object (has numeric ID)
            const isDbObject = !isNaN(parseInt(objectId));

            if (isDbObject) {
                if (newLevel === 0) {
                    // If level is set to 0, delete the object from database
                    await objectAPI.deleteObject(objectId);
                } else {
                    // Otherwise update the level
                    await objectAPI.updateObjectLevel(objectId, newLevel);
                }
            } else if (newLevel > 0) {
                // This is a non-database object that needs to be created
                // Find the instance in processedObjectData
                let buildingInstance = null;
                let buildingName = '';

                // Search through all categories
                Object.keys(processedObjectData).forEach(category => {
                    Object.keys(processedObjectData[category]).forEach(bName => {
                        const instance = processedObjectData[category][bName].find(i =>
                            i.instance_id === objectId || i.wafi_id === objectId);
                        if (instance) {
                            buildingInstance = instance;
                            buildingName = bName;
                        }
                    });
                });

                // If this is a Town Hall weapon upgrade, handle with the new type
                if (isWeaponUpgrade && buildingName === "Town Hall") {
                    console.log("Updating Town Hall weapon level to", newLevel);
                    
                    // Store the Town Hall Weapon level in database with the special name
                    const result = await objectAPI.createOrUpdateObjects(base.wafi_id, [{
                        name: "Town Hall Weapon", // Important: Use the exact name for Town Hall Weapon type
                        level: newLevel
                    }]);
                    
                    // Update local state for immediate UI feedback
                    setPlayerData(prevData => ({
                        ...prevData,
                        townHallWeaponLevel: newLevel
                    }));
                } else {
                    // For regular buildings, create/update them in the database
                    const result = await objectAPI.createOrUpdateObjects(base.wafi_id, [{
                        name: buildingName || objectId,
                        level: newLevel
                    }]);
                    // Get the created object ID from the response
                    const createdObjectId = result.results.find(r => r.status === 'created')?.objectId;
                    if (createdObjectId && buildingInstance) {
                        buildingInstance.wafi_id = createdObjectId;
                        buildingInstance.exists_in_db = true;
                    }
                }
            }

            // Refresh the object data
            if (base?.wafi_id) {
                const refreshedObjectData = await objectAPI.getObject(base.wafi_id);
                setDbObjectData(refreshedObjectData);
            }
        } catch (error) {
            console.error("Failed to update object level:", error);
        }
    };

    // Add a new handler specifically for updating wall counts
    const handleWallCountUpdate = async (wallName, newCount) => {
        console.log("Updating wall count:", wallName, "to:", newCount);

        try {
            // Find existing wall object in database
            const dbObject = dbObjectData.find(obj => obj.wafi_name === wallName);

            if (dbObject) {
                if (newCount === 0) {
                    // Delete the wall object if count is 0
                    await objectAPI.deleteObject(dbObject.wafi_id);
                } else {
                    // Update the count (stored in wafi_level field)
                    await objectAPI.updateObjectLevel(dbObject.wafi_id, newCount);
                }
            } else if (newCount > 0) {
                // Create new wall object with the count
                const result = await objectAPI.createOrUpdateObjects(base.wafi_id, [{
                    name: wallName, // Important: This must include the level "Wall X"
                    level: newCount // The count is stored in the level field
                }]);
            }

            // Refresh object data
            if (base?.wafi_id) {
                const refreshedObjectData = await objectAPI.getObject(base.wafi_id);
                setDbObjectData(refreshedObjectData);
            }
        } catch (error) {
            console.error("Failed to update wall count:", error);
        }
    };

    // Handle TH upgrade (placeholder function)
    const handleStartTHUpgrade = () => {
        alert("Town Hall upgrade started! (This is a placeholder function)");
    };

    if (!isBaseExists) {
        return (
            <div className="p-4 bg-white/10 backdrop-blur-md rounded-lg border border-white/20 text-white">
                <div className="flex items-center justify-between mb-6">
                    <button
                        onClick={() => navigate("/base")}
                        className="flex items-center gap-2 text-white/70 hover:text-white"
                    >
                        <FontAwesomeIcon icon={faArrowLeft} />
                        <span>Kembali</span>
                    </button>
                </div>
                <div className="text-center py-10">
                    <FontAwesomeIcon icon={faExclamationTriangle} className="text-yellow-400 text-4xl mb-4" />
                    <h2 className="text-xl font-bold">Base tidak ditemukan</h2>
                    <p className="text-white/70 mt-2">Base dengan tag {tag} tidak terdaftar di sistem.</p>
                </div>
            </div>
        );
    }

    if (isLoading) {
        return (
            <div className="p-4 bg-white/10 backdrop-blur-md rounded-lg border border-white/20 text-white">
                <div className="flex items-center justify-between mb-6">
                    <button
                        onClick={() => navigate("/base")}
                        className="flex items-center gap-2 text-white/70 hover:text-white"
                    >
                        <FontAwesomeIcon icon={faArrowLeft} />
                        <span>Kembali</span>
                    </button>
                </div>
                <div className="text-center py-10">
                    <FontAwesomeIcon icon={faSpinner} spin className="text-white text-4xl mb-4" />
                    <p>Memuat data pemain...</p>
                </div>
            </div>
        );
    }

    // Return section with tabs
    return (
        <div className="w-full p-4 bg-white/10 rounded-lg border border-white/20 text-white">
            {/* Back Button */}
            <div className="flex items-center justify-between mb-6">
                <button
                    onClick={() => navigate("/base")}
                    className="flex items-center gap-2 text-white/70 hover:text-white text-base"
                >
                    <FontAwesomeIcon icon={faArrowLeft} />
                    <span>Kembali</span>
                </button>
            </div>

            {/* Base Header with upgrade progress */}
            <BaseHeader
                playerData={playerData}
                base={base}
                processedObjectData={processedObjectData}
                processedTroopData={processedTroopData}
                wallData={wallData}
            />

            {/* Tab Navigation - Modified to use handleTabClick */}
            <div className="flex space-x-1 mb-6 bg-white/5 p-1 rounded-lg overflow-x-auto">
                <button
                    onClick={() => handleTabClick("defenses")}
                    className={`flex items-center justify-center px-3 py-2 rounded-md transition-all ${activeTab === "defenses"
                        ? "bg-yellow-400 text-gray-900 font-medium"
                        : "hover:bg-white/10 text-white/70 hover:text-white"
                        }`}
                    data-tooltip-id="tab-tooltip"
                    data-tooltip-content="Defenses"
                >
                    <FontAwesomeIcon icon={faShield} className="text-lg" />
                </button>

                {/* Show Traps tab only for TH 3+ */}
                {playerData && playerData.townHallLevel >= 3 && (
                    <button
                        onClick={() => handleTabClick("traps")}
                        className={`flex items-center justify-center px-3 py-2 rounded-md transition-all ${activeTab === "traps"
                            ? "bg-yellow-400 text-gray-900 font-medium"
                            : "hover:bg-white/10 text-white/70 hover:text-white"
                            }`}
                        data-tooltip-id="tab-tooltip"
                        data-tooltip-content="Traps"
                    >
                        <FontAwesomeIcon icon={faBomb} className="text-lg" />
                    </button>
                )}

                <button
                    onClick={() => handleTabClick("resources")}
                    className={`flex items-center justify-center px-3 py-2 rounded-md transition-all ${activeTab === "resources"
                        ? "bg-yellow-400 text-gray-900 font-medium"
                        : "hover:bg-white/10 text-white/70 hover:text-white"
                        }`}
                    data-tooltip-id="tab-tooltip"
                    data-tooltip-content="Resources"
                >
                    <FontAwesomeIcon icon={faHome} className="text-lg" />
                </button>

                <button
                    onClick={() => handleTabClick("army")}
                    className={`flex items-center justify-center px-3 py-2 rounded-md transition-all ${activeTab === "army"
                        ? "bg-yellow-400 text-gray-900 font-medium"
                        : "hover:bg-white/10 text-white/70 hover:text-white"
                        }`}
                    data-tooltip-id="tab-tooltip"
                    data-tooltip-content="Army Buildings"
                >
                    <FontAwesomeIcon icon={faBuilding} className="text-lg" />
                </button>

                {/* Regular Troops tab always visible */}
                <button
                    onClick={() => handleTabClick("troops")}
                    className={`flex items-center justify-center px-3 py-2 rounded-md transition-all ${activeTab === "troops"
                        ? "bg-yellow-400 text-gray-900 font-medium"
                        : "hover:bg-white/10 text-white/70 hover:text-white"
                        }`}
                    data-tooltip-id="tab-tooltip"
                    data-tooltip-content="Troops"
                >
                    <FontAwesomeIcon icon={faDragon} className="text-lg" />
                </button>

                {/* Show Dark Troops tab only for TH 7+ */}
                {playerData && playerData.townHallLevel >= 7 && (
                    <button
                        onClick={() => handleTabClick("darkTroops")}
                        className={`flex items-center justify-center px-3 py-2 rounded-md transition-all ${activeTab === "darkTroops"
                            ? "bg-yellow-400 text-gray-900 font-medium"
                            : "hover:bg-white/10 text-white/70 hover:text-white"
                            }`}
                        data-tooltip-id="tab-tooltip"
                        data-tooltip-content="Dark Troops"
                    >
                        <FontAwesomeIcon icon={faMoon} className="text-lg" />
                    </button>
                )}

                {/* Spells tab */}
                <button
                    onClick={() => handleTabClick("spells")}
                    className={`flex items-center justify-center px-3 py-2 rounded-md transition-all ${activeTab === "spells"
                        ? "bg-yellow-400 text-gray-900 font-medium"
                        : "hover:bg-white/10 text-white/70 hover:text-white"
                        }`}
                    data-tooltip-id="tab-tooltip"
                    data-tooltip-content="Spells"
                >
                    <FontAwesomeIcon icon={faFlask} className="text-lg" />
                </button>

                {/* Show Dark Spells tab only for TH 7+ */}
                {playerData && playerData.townHallLevel >= 7 && (
                    <button
                        onClick={() => handleTabClick("darkSpells")}
                        className={`flex items-center justify-center px-3 py-2 rounded-md transition-all ${activeTab === "darkSpells"
                            ? "bg-yellow-400 text-gray-900 font-medium"
                            : "hover:bg-white/10 text-white/70 hover:text-white"
                            }`}
                        data-tooltip-id="tab-tooltip"
                        data-tooltip-content="Dark Spells"
                    >
                        <FontAwesomeIcon icon={faMoon} className="text-lg" />
                    </button>
                )}

                {/* Show Siege Machines tab only for TH 12+ */}
                {playerData && playerData.townHallLevel >= 12 && (
                    <button
                        onClick={() => handleTabClick("sieges")}
                        className={`flex items-center justify-center px-3 py-2 rounded-md transition-all ${activeTab === "sieges"
                            ? "bg-yellow-400 text-gray-900 font-medium"
                            : "hover:bg-white/10 text-white/70 hover:text-white"
                            }`}
                        data-tooltip-id="tab-tooltip"
                        data-tooltip-content="Siege Machines"
                    >
                        <FontAwesomeIcon icon={faTruck} className="text-lg" />
                    </button>
                )}

                {/* Show Pets tab only for TH 14+ */}
                {playerData && playerData.townHallLevel >= 14 && (
                    <button
                        onClick={() => handleTabClick("pets")}
                        className={`flex items-center justify-center px-3 py-2 rounded-md transition-all ${activeTab === "pets"
                            ? "bg-yellow-400 text-gray-900 font-medium"
                            : "hover:bg-white/10 text-white/70 hover:text-white"
                            }`}
                        data-tooltip-id="tab-tooltip"
                        data-tooltip-content="Pets"
                    >
                        <FontAwesomeIcon icon={faHorse} className="text-lg" />
                    </button>
                )}

                {/* Show Heroes tab only for TH 7+ (same as dark troops) */}
                {playerData && playerData.townHallLevel >= 7 && (
                    <button
                        onClick={() => handleTabClick("heroes")}
                        className={`flex items-center justify-center px-3 py-2 rounded-md transition-all ${activeTab === "heroes"
                            ? "bg-yellow-400 text-gray-900 font-medium"
                            : "hover:bg-white/10 text-white/70 hover:text-white"
                            }`}
                        data-tooltip-id="tab-tooltip"
                        data-tooltip-content="Heroes"
                    >
                        <FontAwesomeIcon icon={faCrown} className="text-lg" />
                    </button>
                )}
                {playerData && playerData.townHallLevel >= 7 && (
                    <button
                        onClick={() => handleTabClick("heroEquipments")}
                        className={`flex items-center justify-center px-3 py-2 rounded-md transition-all ${activeTab === "heroEquipments"
                            ? "bg-yellow-400 text-gray-900 font-medium"
                            : "hover:bg-white/10 text-white/70 hover:text-white"
                            }`}
                        data-tooltip-id="tab-tooltip"
                        data-tooltip-content="Hero Equipments"
                    >
                        <FontAwesomeIcon icon={faMeteor} className="text-lg" />
                    </button>
                )}
                {playerData && playerData.townHallLevel >= 1 && (
                    <button
                        onClick={() => handleTabClick("walls")}
                        className={`flex items-center justify-center px-3 py-2 rounded-md transition-all ${activeTab === "walls"
                            ? "bg-yellow-400 text-gray-900 font-medium"
                            : "hover:bg-white/10 text-white/70 hover:text-white"
                            }`}
                        data-tooltip-id="tab-tooltip"
                        data-tooltip-content="Walls"
                    >
                        <FontAwesomeIcon icon={faXmarksLines} className="text-lg" />
                    </button>
                )}

                {/* Add new Progress tab button */}
                <button
                    onClick={() => handleTabClick("progress")}
                    className={`flex items-center justify-center px-3 py-2 rounded-md transition-all ${activeTab === "progress"
                        ? "bg-yellow-400 text-gray-900 font-medium"
                        : "hover:bg-white/10 text-white/70 hover:text-white"
                        }`}
                    data-tooltip-id="tab-tooltip"
                    data-tooltip-content="Progress Summary"
                >
                    <FontAwesomeIcon icon={faListCheck} className="text-lg" />
                </button>

                {/* Statistics Tab */}
                <button
                    onClick={() => handleTabClick("statistics")}
                    className={`flex items-center justify-center px-3 py-2 rounded-md transition-all ${activeTab === "statistics"
                        ? "bg-yellow-400 text-gray-900 font-medium"
                        : "hover:bg-white/10 text-white/70 hover:text-white"
                        }`}
                    data-tooltip-id="tab-tooltip"
                    data-tooltip-content="Statistics"
                >
                    <FontAwesomeIcon icon={faChartBar} className="text-lg" />
                </button>

                {/* Add tooltip component */}
                <Tooltip id="tab-tooltip" className="z-50" />
            </div>

            {/* Tab Content */}
            <div className="tab-content">
                {activeTab === "defenses" && processedObjectData &&
                    <BuildingsTab
                        playerData={playerData}
                        onUpdateLevel={handleUpdateLevel}
                        objectData={processedObjectData.Defenses}
                        tabTitle="Defenses"
                        icon={faShield}
                    />
                }
                {activeTab === "traps" && processedObjectData && playerData && playerData.townHallLevel >= 3 &&
                    <BuildingsTab
                        playerData={playerData}
                        onUpdateLevel={handleUpdateLevel}
                        objectData={processedObjectData.Traps}
                        tabTitle="Traps"
                        icon={faBomb}
                    />
                }
                {activeTab === "resources" && processedObjectData &&
                    <BuildingsTab
                        playerData={playerData}
                        onUpdateLevel={handleUpdateLevel}
                        objectData={processedObjectData.Resources}
                        tabTitle="Resources"
                        icon={faHome}
                    />
                }
                {activeTab === "army" && processedObjectData &&
                    <BuildingsTab
                        playerData={playerData}
                        onUpdateLevel={handleUpdateLevel}
                        objectData={processedObjectData.Army}
                        tabTitle="Army Buildings"
                        icon={faBuilding}
                    />
                }

                {/* Modified TroopsTab component rendering with TH level checks */}
                {activeTab === "troops" && processedTroopData &&
                    <TroopsTab
                        troopData={processedTroopData.Troops}
                        playerData={playerData}
                        onUpdateLevel={handleUpdateLevel}
                        tabTitle="Troops"
                        base={base}
                        icon={faDragon}
                    />
                }
                {activeTab === "darkTroops" && processedTroopData && playerData && playerData.townHallLevel >= 7 &&
                    <TroopsTab
                        troopData={processedTroopData.DarkTroops}
                        playerData={playerData}
                        onUpdateLevel={handleUpdateLevel}
                        tabTitle="Dark Troops"
                        base={base}
                        icon={faMoon}
                    />
                }
                {activeTab === "spells" && processedTroopData &&
                    <TroopsTab
                        troopData={processedTroopData.Spells}
                        playerData={playerData}
                        onUpdateLevel={handleUpdateLevel}
                        tabTitle="Spells"
                        base={base}

                        icon={faFlask}
                    />
                }
                {activeTab === "darkSpells" && processedTroopData && playerData && playerData.townHallLevel >= 7 &&
                    <TroopsTab
                        troopData={processedTroopData.DarkSpells}
                        playerData={playerData}
                        onUpdateLevel={handleUpdateLevel}
                        tabTitle="Dark Spells"
                        base={base}
                        icon={faMoon}
                    />
                }
                {activeTab === "sieges" && processedTroopData && playerData && playerData.townHallLevel >= 12 &&
                    <TroopsTab
                        troopData={processedTroopData.Sieges}
                        playerData={playerData}
                        onUpdateLevel={handleUpdateLevel}
                        tabTitle="Siege Machines"
                        base={base}
                        icon={faTruck}
                    />
                }
                {activeTab === "pets" && processedTroopData && playerData && playerData.townHallLevel >= 14 &&
                    <TroopsTab
                        troopData={processedTroopData.Pets}
                        playerData={playerData}
                        onUpdateLevel={handleUpdateLevel}
                        tabTitle="Pets"
                        base={base}
                        icon={faHorse}
                    />
                }
                {activeTab === "heroes" && processedTroopData && playerData && playerData.townHallLevel >= 7 &&
                    <TroopsTab
                        troopData={processedTroopData.Heroes}
                        playerData={playerData}
                        onUpdateLevel={handleUpdateLevel}
                        tabTitle="Heroes"
                        base={base}
                        icon={faCrown}
                    />
                }
                {activeTab === "heroEquipments" && processedTroopData && playerData && playerData.townHallLevel >= 7 &&
                    <TroopsTab
                        troopData={processedTroopData.HeroEquipments}
                        playerData={playerData}
                        onUpdateLevel={handleUpdateLevel}
                        tabTitle="Hero Equipments"
                        base={base}
                        icon={faCrown}
                    />
                }
                {activeTab === "walls" && wallData && playerData && playerData.townHallLevel >= 2 &&
                    <WallsTab
                        wallData={wallData}
                        playerData={playerData}
                        onUpdateCount={handleUpdateLevel}
                        tabTitle="Walls"
                        icon={faXmarksLines}
                    />
                }
                {/* Add the Progress Tab content */}
                {activeTab === "progress" && processedObjectData && processedTroopData &&
                    <ProgressTab
                        processedObjectData={processedObjectData}
                        processedTroopData={processedTroopData}
                        base={base}
                        playerData={playerData}
                        wallData={wallData}
                    />
                }

                {activeTab === "statistics" && <StatisticTab playerData={playerData} />}
            </div>
        </div>
    );
};

export default Base;
