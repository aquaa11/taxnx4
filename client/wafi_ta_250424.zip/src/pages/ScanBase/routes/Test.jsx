import { useLocation } from 'react-router-dom'
import React, { useState, useEffect, useRef } from "react";
import { Sortable, Plugins } from "@shopify/draggable";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEdit, faRotateLeft, faXmark, faGripVertical, faUpDownLeftRight, faPlus, faMinus } from "@fortawesome/free-solid-svg-icons";
import { BuildingIdToName } from '../../../helpers/buildingIdToName';

const Results = () => {
    const location = useLocation();

    // Handle both single item and array formats from different sources
    const processResults = () => {
        // If location.state.results is an array (from BuildingsTab)
        if (Array.isArray(location.state.results)) {
            return location.state.results.reduce((acc, item) => {
                if (!acc[item.building_id]) {
                    acc[item.building_id] = [];
                }
                acc[item.building_id].push(item);
                return acc;
            }, {});
        }
        // If it's a single item (from edit button elsewhere)
        else {
            const item = location.state.results;
            return {
                [item.building_id]: [item]
            };
        }
    };

    const results = processResults();
    const [data, setData] = useState(results);
    const containerRefs = useRef([]);
    const sortableRef = useRef(null);
    const [editMode, setEditMode] = useState(false);

    useEffect(() => {
        // Clean up function to remove the previous sortable instance
        if (sortableRef.current) {
            sortableRef.current.destroy();
            sortableRef.current = null;
        }

        // Only set up sortable if in edit mode
        if (editMode) {
            const containers = containerRefs.current.filter((el) => el !== null);

            if (containers.length > 0) {
                sortableRef.current = new Sortable(containers, {
                    draggable: ".dragItem",
                    mirror: { constrainDimensions: true },
                    plugins: [Plugins.ResizeMirror],
                    swapAnimation: {
                        duration: 200,
                        easingFunction: "ease-in-out",
                        horizontal: true,
                    },
                });

                // Use a flag to prevent duplicate event handling
                let isHandlingEvent = false;

                sortableRef.current.on("sortable:stop", (event) => {
                    // Prevent double event handling
                    if (isHandlingEvent) return;
                    isHandlingEvent = true;

                    try {
                        const { oldContainer, newContainer, oldIndex, newIndex, dragEvent } = event;
                        if (!oldContainer || !newContainer) {
                            isHandlingEvent = false;
                            return;
                        }

                        const oldContainerColumnId = oldContainer.dataset.columnId;
                        const newContainerColumnId = newContainer.dataset.columnId;
                        const { source } = dragEvent;
                        const sourceImg = source.querySelector("img").src;
                        const sourceLevel = source.querySelector("img").alt;
                        const newSource = {
                            image: sourceImg,
                            building_id: oldContainerColumnId,
                            level: sourceLevel
                        };

                        setData(prevData => {
                            const newData = JSON.parse(JSON.stringify(prevData)); // Deep clone

                            newData[oldContainerColumnId].splice(oldIndex, 1);
                            newData[newContainerColumnId].splice(newIndex, 0, newSource);
                            console.log(newData);
                            return newData;
                        });
                    } finally {
                        // Make sure to reset the flag even if there's an error
                        setTimeout(() => {
                            isHandlingEvent = false;
                        }, 100);
                    }
                });
            }
        }

        // Clean up on unmount or when dependencies change
        return () => {
            if (sortableRef.current) {
                sortableRef.current.destroy();
                sortableRef.current = null;
            }
        };
    }, [editMode]); // Only recreate when edit mode changes

    const handleEditItems = () => {
        setEditMode((prev) => !prev);
    }
    const handleChangeLevel = (e, index, columnId) => {
        // Get the input value and ensure it's a valid number
        let value = parseInt(e.target.value);

        // Validate input - if not a number or less than 1, set to 1
        if (isNaN(value) || value < 1) {
            value = 1;
        }
        setData((prevData) => {
            const newData = { ...prevData };
            newData[columnId][index].level = value.toString();
            return newData;
        });
    }

    const handleLevelButton = (index, columnId, operation) => {
        setData((prevData) => {
            console.log(columnId, index, value);
            const newData = { ...prevData };
            const currentLevel = parseInt(newData[columnId][index].level);
            if (operation === 'increase') {
                newData[columnId][index].level = (currentLevel + 1).toString();
            } else if (operation === 'decrease' && currentLevel > 1) {
                newData[columnId][index].level = (currentLevel - 1).toString();
            }
            return newData;
        });
    }

    return (
        <div className={`bg-white/10 p-4 rounded-lg transition-all duration-300 ${editMode ? 'border-2 border-yellow-400 shadow-[0_0_15px_rgba(250,204,21,0.5)] animate-pulse-border' : 'border border-white/50'
            }`}>
            <style>{`
                @keyframes pulse-border {
                    0%, 100% {
                        border-color: rgba(250, 204, 21, 0.8);
                        box-shadow: 0 0 15px rgba(250, 204, 21, 0.5);
                    }
                    50% {
                        border-color: rgba(250, 204, 21, 0.3);
                        box-shadow: 0 0 25px rgba(250, 204, 21, 0.2);
                    }
                }
                .animate-pulse-border {
                    animation: pulse-border 2s infinite;
                }
            `}</style>

            <div className="flex justify-center items-center mb-4">
                <h1 className="text-center text-xl flex-1 font-bold text-white">Hasil Proses Gambar</h1>
                <div className='flex flex-row gap-1'>
                    {editMode &&
                        <button className="float-right bg-red-400 hover:bg-red-500 transition-colors px-2 py-1 rounded-md w-8 h-8 mx-auto">
                            <FontAwesomeIcon icon={faRotateLeft} className="text-white" />
                        </button>}
                    <button
                        onClick={handleEditItems}
                        className={`float-right transition-all duration-300 px-2 py-1 w-8 h-8 mx-auto rounded-md ${editMode ? 'bg-gray-600 hover:bg-gray-700' : 'bg-yellow-400 hover:bg-yellow-500'
                            }`}
                    >
                        <FontAwesomeIcon icon={!editMode ? faEdit : faXmark} className="text-white" />
                    </button>
                </div>
            </div>

            {/* Edit Mode Banner - Slides in from top when edit mode is active */}
            <div className={`transition-all duration-500 overflow-hidden ${editMode ? 'max-h-20 opacity-100 mb-4' : 'max-h-0 opacity-0'
                }`}>
                <div className="flex items-center bg-yellow-500/20 border border-yellow-500/50 rounded-lg p-3 text-yellow-100">
                    <div className="mr-3 h-6 w-6 rounded-full bg-yellow-500/30 flex items-center justify-center animate-pulse">
                        <FontAwesomeIcon icon={faEdit} className="text-yellow-200 text-sm" />
                    </div>
                    <div>
                        <p className="font-medium">Edit Mode Aktif</p>
                        <p className="text-sm opacity-80">Anda dapat mendrag dan drop item antar kelompok</p>
                    </div>
                </div>
            </div>

            <div className="container flex flex-row flex-wrap gap-3">
                {Object.entries(results).map(([columnId, items], index) => (
                    <div
                        key={columnId}
                        className={`sortable-container rounded-lg p-3 h-fit transition-all duration-300 ${editMode
                            ? 'bg-gray-700/30 border-2 border-yellow-400/30'
                            : 'border border-white/50'
                            }`}
                    >
                        <h2 className="text-white mb-2">{BuildingIdToName(columnId)}</h2>
                        <div
                            ref={(el) => (containerRefs.current[index] = el)}
                            className={`sortable flex flex-wrap gap-2 overflow-hidden min-h-24 min-w-24 rounded-xl transition-all duration-300 ${editMode ? 'bg-gray-800/50 p-2' : ''
                                }`}
                            data-column-id={columnId}
                        >
                            {items.length === 0 ? (
                                <div className={`empty-placeholder overflow-hidden text-gray-400 p-4 text-center border border-dashed transition-colors duration-300 rounded-lg ${editMode ? 'border-yellow-500/50 bg-yellow-500/5' : 'border-gray-500'
                                    }`}>
                                    {editMode ? "Letakkan item di sini" : "Drop here"}
                                </div>
                            ) : (
                                items.map((item, i) => (
                                    <div
                                        className={`relative rounded-lg overflow-hidden ${editMode
                                            ? "dragItem cursor-move bg-neutral-700 border-2 border-yellow-400/50 shadow-[0_0_10px_rgba(250,204,21,0.3)]"
                                            : "bg-neutral-700"
                                            }`}
                                        style={{ height: '6rem', width: '6rem' }}
                                        data-index={i}
                                        key={`${columnId}-${item.building_id}-${i}`}
                                    >
                                        {editMode && (
                                            <div className="absolute top-1 right-1 bg-yellow-500 bg-opacity-70 text-white text-sm p-1 rounded flex justify-center items-center">
                                                <FontAwesomeIcon icon={faUpDownLeftRight} />
                                            </div>
                                        )}
                                        <img
                                            src={item.image}
                                            alt={item.level}
                                            className="w-full h-auto object-cover"
                                        />
                                        {editMode ? (
                                            <div className="absolute bottom-1 left-1 bg-black bg-opacity-60 text-white text-sm px-2 py-1 rounded">
                                                {parseInt(item.level)}
                                            </div>
                                        ) : (
                                            <div className='absolute bottom-1 left-1 text-white text-sm px-2 py-1 rounded z-50 flex items-center gap-1'>
                                                <button
                                                    onClick={() => handleLevelButton(i, columnId, 'decrease')}
                                                    className="hover:bg-gray-700 transition-colors"
                                                >
                                                    <FontAwesomeIcon icon={faMinus} className='rounded bg-black p-1' />
                                                </button>
                                                <input
                                                    type="text"
                                                    value={parseInt(item.level)}
                                                    onChange={(e) => handleChangeLevel(e, i, columnId)}
                                                    className="max-w-6 rounded bg-black text-center p-1"
                                                    min="1"
                                                />
                                                <button
                                                    onClick={() => handleLevelButton(i, columnId, 'increase')}
                                                    className="hover:bg-gray-700 transition-colors"
                                                >
                                                    <FontAwesomeIcon icon={faPlus} className='rounded bg-black p-1' />
                                                </button>
                                            </div>
                                        )}

                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default Results