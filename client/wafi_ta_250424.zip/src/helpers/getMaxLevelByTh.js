import defensiveBuildingData from './defensive-building.json';

function getMaxLevelByTh(name, th) {
  try {
    const building = defensiveBuildingData.find(b => b.name === name);

    if (!building) {
      console.warn(`Building '${name}' not found in data`);
      return getDefaultMaxLevel(name);
    }

    // Filter levels available at or below the current TH level
    const maxLevel = building.levels
      .filter(level => level.th <= th)
      .reduce((max, level) => Math.max(max, level.level), 0);

    return maxLevel > 0 ? maxLevel : getDefaultMaxLevel(name);
  } catch (error) {
    console.error("Error getting max level:", error);
    return getDefaultMaxLevel(name);
  }
}


export default getMaxLevelByTh;
