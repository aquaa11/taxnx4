const BUILDINGS=["Cannon","Archer Tower","Mortar","Air Defense","Wizard Tower","Air Sweeper","Hidden Tesla","Bomb Tower","X-Bow","Inferno Tower","Eagle Artillery","Scattershot","Builder's Hut","Spell Tower","Monolith","Multi-Archer Tower","Ricochet Cannon","Multi-Gear Tower","Firespitter","Wall","Bomb","Spring Trap","Giant Bomb","Air Bomb","Seeking Air Mine","Skeleton Trap","Tornado Trap","Giga Bomb"];

export function BuildingIdToName(originalId) {
    const id = parseInt(originalId.split("_")[1]);
    const building = BUILDINGS[id];
    if (building) {
        return building;
    } else {
        return originalId;
    }
}
