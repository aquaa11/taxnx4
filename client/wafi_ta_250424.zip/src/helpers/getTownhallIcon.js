const getTownhallIcon = (th) => {
    if (th == 17) return "http://localhost:3000/assets/th/th-17.png";
    if (th == 16) return "http://localhost:3000/assets/th/th-16.png";
    if (th == 15) return "http://localhost:3000/assets/th/th-15.png";
    if (th == 14) return "http://localhost:3000/assets/th/th-14.png";
    if (th == 13) return "http://localhost:3000/assets/th/th-13.png";
    if (th == 12) return "http://localhost:3000/assets/th/th-12.png";
    if (th == 11) return "http://localhost:3000/assets/th/th-11.png";
    if (th == 10) return "http://localhost:3000/assets/th/th-10.png";
    if (th == 9) return "http://localhost:3000/assets/th/th-9.png";
    if (th == 8) return "http://localhost:3000/assets/th/th-8.png";
    if (th == 7) return "http://localhost:3000/assets/th/th-7.png";
    if (th == 6) return "http://localhost:3000/assets/th/th-6.png";
    if (th == 5) return "http://localhost:3000/assets/th/th-5.png";
    if (th == 4) return "http://localhost:3000/assets/th/th-4.png";
    if (th == 3) return "http://localhost:3000/assets/th/th-3.png";
    if (th == 2) return "http://localhost:3000/assets/th/th-2.png";
    return "http://localhost:3000/assets/th/th-1.png";
};

export default getTownhallIcon;